import { createServer, Server } from 'http';
import { parse } from 'url';
import { spawn } from 'child_process';
import { findAvailablePort } from '../utils/port-finder';

/**
 * OAuth Callback Server
 * Handles OAuth redirects from platform
 */
export class OAuthServer {
  private server: Server | null = null;
  private port: number = 0; // Will be set when finding available port
  private readonly localHost = '127.0.0.1';

  constructor(private baseUrl: string) {}

  async authenticate(provider: 'google' | 'github'): Promise<string> {
    return new Promise(async (resolve, reject) => {
      // Find an available port automatically
      try {
        this.port = await findAvailablePort(49152); // Start from dynamic port range
      } catch (error) {
        reject(new Error('Could not find an available port for OAuth callback server'));
        return;
      }

      this.server = createServer((req, res) => {
        const { pathname, query } = parse(req.url || '', true);
        
        // Serve redirect page that opens OAuth
        if (pathname === '/auth') {
          const authUrl = `${this.baseUrl}/api/auth/cli/${provider}?port=${this.port}`;
          this.sendRedirectPage(res, authUrl);
          return;
        }
        
        // Handle OAuth callback
        if (pathname === '/callback') {
          const { token, error } = query;
          
          if (error) {
            this.sendErrorPage(res, error as string);
            this.close();
            reject(new Error(error as string));
            return;
          }
          
          if (token) {
            this.sendSuccessPage(res);
            this.close();
            resolve(token as string);
          }
        }
      });
      
      this.server.listen(this.port, this.localHost, () => {
        // Open our local redirect page instead of OAuth directly.
        // Keep a manual fallback URL in terminal in case auto-open fails.
        const authBridgeUrl = `http://${this.localHost}:${this.port}/auth`;
        this.openBrowser('auth');
        console.log(`\nIf your browser did not open, visit:\n  ${authBridgeUrl}\n`);
      });
    });
  }

  private openBrowser(path: string): void {
    const url = `http://${this.localHost}:${this.port}/${path}`;
    let cmd: string;
    let args: string[];
    if (process.platform === 'darwin') {
      cmd = 'open';
      args = [url];
    } else if (process.platform === 'win32') {
      cmd = 'cmd';
      args = ['/c', 'start', '', url];
    } else {
      cmd = 'xdg-open';
      args = [url];
    }
    const child = spawn(cmd, args, { stdio: 'ignore', detached: true });
    child.on('error', () => {
      console.log(`Could not auto-open browser. Open manually:\n  ${url}\n`);
    });
    child.unref();
  }

  private sendRedirectPage(res: any, authUrl: string): void {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <title>Redirecting to Authentication</title>
          <style>
            @keyframes spin {
              to { transform: rotate(360deg); }
            }
          </style>
        </head>
        <body style="margin: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica', 'Arial', sans-serif; background: #f8fafc; display: flex; align-items: center; justify-content: center; min-height: 100vh;">
          <div style="background: white; padding: 48px 40px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); max-width: 400px; text-align: center;">
            <div style="width: 48px; height: 48px; margin: 0 auto 24px; border: 3px solid #e5e7eb; border-top-color: #3b82f6; border-radius: 50%; animation: spin 1s linear infinite;"></div>
            <h1 style="margin: 0 0 16px; font-size: 24px; font-weight: 600; color: #0f172a;">Redirecting</h1>
            <p style="margin: 0; font-size: 15px; color: #64748b; line-height: 1.6;">Opening authentication page...</p>
          </div>
          <script>
            // Navigate to OAuth
            window.location.href = '${authUrl}';
          </script>
        </body>
      </html>
    `);
  }

  private sendSuccessPage(res: any): void {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <title>Authentication Successful</title>
        </head>
        <body style="margin: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica', 'Arial', sans-serif; background: #f8fafc; display: flex; align-items: center; justify-content: center; min-height: 100vh;">
          <div style="background: white; padding: 48px 40px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); max-width: 400px; text-align: center;">
            <svg style="width: 64px; height: 64px; margin: 0 auto 24px;" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="20 6 9 17 4 12"></polyline>
            </svg>
            <h1 style="margin: 0 0 16px; font-size: 24px; font-weight: 600; color: #0f172a;">Authentication Successful</h1>
            <p style="margin: 0 0 8px; font-size: 15px; color: #64748b; line-height: 1.6;">You have successfully authenticated with ClikDeploy.</p>
            <p style="margin: 0; font-size: 14px; color: #94a3b8;">You can close this window and return to your terminal.</p>
          </div>
        </body>
      </html>
    `);
  }

  private sendErrorPage(res: any, error: string): void {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <title>Authentication Failed</title>
        </head>
        <body style="margin: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica', 'Arial', sans-serif; background: #f8fafc; display: flex; align-items: center; justify-content: center; min-height: 100vh;">
          <div style="background: white; padding: 48px 40px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); max-width: 400px; text-align: center;">
            <svg style="width: 64px; height: 64px; margin: 0 auto 24px;" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="10"></circle>
              <line x1="15" y1="9" x2="9" y2="15"></line>
              <line x1="9" y1="9" x2="15" y2="15"></line>
            </svg>
            <h1 style="margin: 0 0 16px; font-size: 24px; font-weight: 600; color: #0f172a;">Authentication Failed</h1>
            <p style="margin: 0 0 8px; font-size: 15px; color: #64748b; line-height: 1.6;">${error}</p>
            <p style="margin: 0; font-size: 14px; color: #94a3b8;">You can close this window and try again.</p>
          </div>
        </body>
      </html>
    `);
  }

  private close(): void {
    if (this.server) {
      this.server.close();
      this.server = null;
    }
  }
}
