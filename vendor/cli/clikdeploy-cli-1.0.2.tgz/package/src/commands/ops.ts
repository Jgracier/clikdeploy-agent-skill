import chalk from 'chalk';
import ora from 'ora';
import Conf from 'conf';
import { getApiClient, requireAuth } from '../utils/api';
import { resolveTarget } from '../utils/universal-resolver';
import { Formatters } from '../ui/formatters';

export async function restart(config: Conf, identifier: string) {
    requireAuth(config);
    const api = getApiClient(config);
    const spinner = ora(`Restarting ${identifier}...`).start();

    try {
        const resolved = await resolveTarget(api, identifier);
        if (!resolved) {
            spinner.fail(`Target "${identifier}" not found`);
            return;
        }

        if (resolved.type === 'server') {
            spinner.fail('Cannot restart a server directly. Try "clikdeploy servers reconnect"');
            return;
        }

        await api.getClient().post(`/api/apps/${resolved.app.id}/restart`);
        spinner.succeed(`App ${chalk.cyan(resolved.app.name)} restarted`);
    } catch (error: any) {
        spinner.fail('Restart failed');
        Formatters.error(error.response?.data?.error || error.message);
    }
}

export async function stop(config: Conf, identifier: string) {
    requireAuth(config);
    const api = getApiClient(config);
    const spinner = ora(`Stopping ${identifier}...`).start();

    try {
        const resolved = await resolveTarget(api, identifier);
        if (!resolved || resolved.type !== 'app') {
            spinner.fail(`App "${identifier}" not found`);
            return;
        }

        await api.getClient().post(`/api/apps/${resolved.app.id}/actions`, { action: 'stop' });
        spinner.succeed(`App ${chalk.cyan(resolved.app.name)} stopped`);
    } catch (error: any) {
        spinner.fail('Stop failed');
        Formatters.error(error.response?.data?.error || error.message);
    }
}

export async function start(config: Conf, identifier: string) {
    requireAuth(config);
    const api = getApiClient(config);
    const spinner = ora(`Starting ${identifier}...`).start();

    try {
        const resolved = await resolveTarget(api, identifier);
        if (!resolved || resolved.type !== 'app') {
            spinner.fail(`App "${identifier}" not found`);
            return;
        }

        await api.getClient().post(`/api/apps/${resolved.app.id}/actions`, { action: 'start' });
        spinner.succeed(`App ${chalk.cyan(resolved.app.name)} started`);
    } catch (error: any) {
        spinner.fail('Start failed');
        Formatters.error(error.response?.data?.error || error.message);
    }
}

export async function deleteCommand(config: Conf, identifier: string, options: { yes?: boolean }) {
    requireAuth(config);
    const api = getApiClient(config);

    const resolved = await resolveTarget(api, identifier);
    if (!resolved) {
        Formatters.error(`Target "${identifier}" not found`);
        return;
    }

    if (resolved.type === 'app') {
        const { deleteAppCommand } = await import('./app');
        return deleteAppCommand(config, identifier, !options.yes);
    } else {
        const { deleteServer } = await import('./server');
        return deleteServer(config, identifier, !options.yes);
    }
}
