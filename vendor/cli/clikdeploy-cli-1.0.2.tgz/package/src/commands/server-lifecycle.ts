import ora from 'ora';
import Conf from 'conf';
import { getApiClient, requireAuth } from '../utils/api';
import { Formatters } from '../ui/formatters';
import chalk from 'chalk';
import { Prompts } from '../ui/prompts';
import { getServerById, resolveServer, resolveServerFromList } from '../utils/server-resolver';

const POLL_INTERVAL_MS = 3000;
const RECONNECT_POLL_TIMEOUT_MS = 180000; // 3 min
const LIFECYCLE_POLL_MS = 2000;
const LIFECYCLE_TIMEOUT_MS = 90000; // 90 s

async function listServersAndPromptForName(config: Conf): Promise<string> {
  const api = getApiClient(config);
  const servers = (await api.getServers()) || [];
  if (!servers.length) {
    Formatters.error('No servers found. Add a server first.');
    throw new Error('No servers found');
  }
  console.log(chalk.bold('\n🖥️  Servers\n'));
  const statusColor: Record<string, typeof chalk.green> = {
    CONNECTED: chalk.green,
    SCANNING: chalk.yellow,
    ERROR: chalk.red,
    DISCONNECTED: chalk.gray,
    CONNECTING: chalk.yellow,
  };
  for (const s of servers) {
    const color = statusColor[s.status] || chalk.gray;
    console.log(chalk.cyan(`  ${s.name}`) + `  ${color(s.status)}  ${s.ipAddress}`);
  }
  console.log();
  return Prompts.askForInput('Server name or ID:');
}

export async function testServerLifecycle(config: Conf, serverNameOrId?: string) {
  requireAuth(config);
  let nameOrId = serverNameOrId;
  if (!nameOrId) {
    try {
      nameOrId = await listServersAndPromptForName(config);
    } catch {
      return;
    }
  }
  const api = getApiClient(config, 60000);
  const spinner = ora('Resolving server...').start();
  try {
    const servers = (await api.getServers()) || [];
    spinner.stop();
    const server = resolveServerFromList(servers, nameOrId!);
    if (!server) {
      Formatters.error(`Server "${nameOrId}" not found`);
      Formatters.gray('Use: clikdeploy servers list');
      return;
    }
    const fetchServer = async (): Promise<any> => {
      return getServerById(api, server.id);
    };

    console.log(chalk.bold(`\n🔄 Server lifecycle test: ${server.name}\n`));
    let s = await fetchServer();
    console.log(chalk.cyan(`  Initial: ${s?.status ?? 'UNKNOWN'}${s?.healthError ? ` — ${s.healthError}` : ''}\n`));

    spinner.start('Running connection test (triggers discovery if not connected)...');
    const testRes = await api.getClient().post(`/api/servers/${server.id}/test`).catch((e: any) => ({ data: e.response?.data, status: e.response?.status }));
    spinner.stop();
    const testOk = testRes?.data?.success === true;
    if (!testOk) {
      console.log(chalk.red('  Test failed: ' + ((testRes?.data?.message) || testRes?.data?.error || 'Unknown')));
      return;
    }
    console.log(chalk.gray('  Test OK. Polling status (SCANNING → CONNECTED or ERROR)...\n'));

    const pollStart = Date.now();
    let lastStatus: string | null = null;
    while (Date.now() - pollStart < LIFECYCLE_TIMEOUT_MS) {
      await new Promise((r) => setTimeout(r, LIFECYCLE_POLL_MS));
      s = await fetchServer();
      if (!s) continue;
      const status = s.status || 'UNKNOWN';
      const err = s.healthError ? ` — ${s.healthError}` : '';
      if (status !== lastStatus || err) {
        const color = status === 'CONNECTED' ? chalk.green : status === 'ERROR' ? chalk.red : chalk.yellow;
        console.log(chalk.cyan(`  [${new Date().toISOString()}] ${color(status)}${err}`));
        lastStatus = status;
      }
      if (status === 'CONNECTED') {
        console.log(chalk.green('\n✅ Lifecycle OK: server reached CONNECTED.\n'));
        return;
      }
      if (status === 'ERROR') {
        console.log(chalk.red('\n❌ Lifecycle failed: server went to ERROR.' + (s.healthError ? `\n   Error: ${s.healthError}` : '') + '\n'));
        return;
      }
    }
    console.log(chalk.yellow(`\n⏱ Timeout after ${LIFECYCLE_TIMEOUT_MS / 1000}s. Last status: ${lastStatus ?? 'UNKNOWN'}\n`));
  } catch (error: any) {
    spinner.fail('Lifecycle test failed');
    Formatters.error(error.response?.data?.error || error.message);
  }
}

export async function testServerAppLifecycle(config: Conf, serverNameOrId?: string) {
  requireAuth(config);
  let nameOrId = serverNameOrId;
  if (!nameOrId) {
    try {
      nameOrId = await listServersAndPromptForName(config);
    } catch {
      return;
    }
  }
  const api = getApiClient(config, 60000);
  const spinner = ora('Resolving server...').start();
  try {
    const server = await resolveServer(api, nameOrId!);
    spinner.stop();
    if (!server) {
      Formatters.error(`Server "${nameOrId}" not found`);
      Formatters.gray('Use: clikdeploy servers list');
      return;
    }

    console.log(chalk.bold(`\n🔄 Server–app lifecycle: ${server.name}\n`));
    console.log(chalk.gray('  1. Running discovery (reconcile app status with containers on server)...\n'));

    const discoverRes = await api.getClient().post(`/api/servers/${server.id}/discover`).catch((e: any) => ({ data: e.response?.data, status: e.response?.status }));
    if (discoverRes?.status !== 200 || !discoverRes?.data?.success) {
      const msg = discoverRes?.data?.error || discoverRes?.data?.message || 'Discovery failed';
      console.log(chalk.red('  Discovery failed: ' + msg + '\n'));
      return;
    }
    const containerCount = discoverRes?.data?.containerCount ?? 0;
    const appsReconciled = discoverRes?.data?.appsReconciled ?? 0;
    console.log(chalk.green('  Discovery OK.') + chalk.gray(` Containers on server: ${containerCount}, DB apps updated: ${appsReconciled}\n`));

    let apps: any[] = [];
    try {
      apps = (await api.getApps()) || [];
    } catch {
      console.log(chalk.yellow('  Could not load app list (API timeout or error). Discovery and reconciliation already ran.\n'));
      return;
    }
    const serverApps = apps.filter((a: any) => a.serverId === server.id);

    console.log(chalk.cyan(`  2. Apps on this server (${serverApps.length}):\n`));
    if (serverApps.length === 0) {
      console.log(chalk.gray('  No apps on this server. Deploy with: clikdeploy marketplace deploy <app> -s ' + server.name + '\n'));
      return;
    }

    const statusColor: Record<string, typeof chalk.green> = {
      RUNNING: chalk.green,
      NOT_FOUND: chalk.yellow,
      STOPPED: chalk.gray,
      DEPLOYING: chalk.yellow,
      ERROR: chalk.red,
      RESTARTING: chalk.yellow,
    };
    console.log(chalk.gray('  ') + 'Name'.padEnd(24) + 'Status'.padEnd(14) + 'Note');
    console.log(chalk.gray('  ' + '─'.repeat(70)));
    for (const app of serverApps) {
      const status = app.status || 'UNKNOWN';
      const color = statusColor[status] || chalk.gray;
      const noteStr = (app.status as string) === 'NOT_FOUND' ? 'Container missing on server' : (app.healthError || '');
      const note = noteStr ? chalk.yellow(noteStr.slice(0, 40)) : '';
      console.log(chalk.gray('  ') + app.name.slice(0, 22).padEnd(24) + color(status.padEnd(12)) + ' ' + note);
    }
    console.log(chalk.gray('\n  Run discovery again after changing containers on the server.'));
    console.log(chalk.green('\n✅ Server–app lifecycle OK: discovery ran, app status reconciled with server.\n'));
  } catch (error: any) {
    spinner.fail('Server–app lifecycle failed');
    Formatters.error(error.response?.data?.error || error.message);
  }
}

export async function discoverServer(config: Conf, serverNameOrId?: string) {
  requireAuth(config);
  let nameOrId = serverNameOrId;
  if (!nameOrId) {
    try {
      nameOrId = await listServersAndPromptForName(config);
    } catch {
      return;
    }
  }
  const api = getApiClient(config, 120000);
  const spinner = ora('Resolving server...').start();
  try {
    const server = await resolveServer(api, nameOrId!);
    if (!server) {
      spinner.fail(`Server "${nameOrId}" not found`);
      return;
    }
    if (server.status !== 'CONNECTED') {
      spinner.fail(`Server "${server.name}" is not connected. Run: clikdeploy servers reconnect ${server.name}`);
      return;
    }
    spinner.text = 'Running discovery (Docker install/rootless if needed)...';
    const discoverRes = await api.getClient().post(`/api/servers/${server.id}/discover`).catch((e: any) => ({
      data: e.response?.data,
      status: e.response?.status,
    }));
    if (discoverRes?.status !== 200 || !discoverRes?.data?.success) {
      spinner.fail('Discovery failed');
      Formatters.error(discoverRes?.data?.error || discoverRes?.data?.message || 'Discovery failed');
      return;
    }
    spinner.succeed('Discovery complete');
    const d = discoverRes?.data?.discovery?.docker;
    if (d) {
      console.log(chalk.bold('\n🐳 Docker:\n'));
      Formatters.info('Version: ', d.version || '-');
      Formatters.info('Rootless:', d.rootless ? chalk.green('yes') : chalk.gray('no'));
      if (d.rootless && d.socketPath) Formatters.info('Socket:  ', d.socketPath);
      if (d.warning) console.log(chalk.yellow('  Warning: ' + d.warning));
    }
    console.log();
  } catch (error: any) {
    spinner.fail('Discovery failed');
    Formatters.error(error.response?.data?.error || error.message);
  }
}

export async function reconnectServer(config: Conf, serverNameOrId?: string, keyPath?: string, username?: string) {
  requireAuth(config);
  let nameOrId = serverNameOrId;
  if (!nameOrId) {
    try {
      nameOrId = await listServersAndPromptForName(config);
    } catch {
      return;
    }
  }
  const api = getApiClient(config, 60000);
  const spinner = ora('Resolving server...').start();
  try {
    const server = await resolveServer(api, nameOrId!);
    if (!server) {
      spinner.fail(`Server "${nameOrId}" not found`);
      return;
    }

    const fetchServer = async (): Promise<any> => {
      return getServerById(api, server.id);
    };

    if (server.cloudProvider === 'GCP') {
      if (keyPath) {
        spinner.warn('--key is ignored for GCP servers (reconnect uses OAuth).');
      }
      spinner.text = 'Starting reconnect in background...';
      const { data } = await api.getClient().post(`/api/servers/${server.id}/reconnect`);
      spinner.succeed('Reconnect started');
      console.log(chalk.gray(data?.message || 'Polling status (output below)...\n'));
    } else {
      if (keyPath) {
        const fs = await import('fs');
        const path = await import('path');
        const os = await import('os');
        const expanded = keyPath.replace(/^~/, os.homedir());
        const fullPath = path.resolve(expanded);
        if (!fs.existsSync(fullPath)) {
          spinner.fail(`SSH key not found: ${fullPath}`);
          return;
        }
        spinner.text = 'Updating server credentials with new SSH key...';
        const keyContent = fs.readFileSync(fullPath, 'utf8');
        const sshUser = username ?? 'ubuntu';
        await api.getClient().put(`/api/servers/${server.id}`, {
          credentials: {
            privateKey: keyContent,
            username: sshUser,
            host: server.ipAddress,
            port: 22,
          },
        });
      }
      spinner.text = 'Testing connection...';
      const testRes = await api.getClient().post(`/api/servers/${server.id}/test`).catch((e: any) => ({ data: e.response?.data, status: e.response?.status }));
      const testOk = testRes?.data?.success === true;
      if (!testOk) {
        spinner.fail('Connection test failed');
        const msg =
          testRes?.data?.message ||
          testRes?.data?.error ||
          'Server unreachable. Check IP, SSH key, and that the VM is running (e.g. multipass start <vm>).';
        Formatters.error(msg);
        return;
      }
      spinner.text = 'Running discovery...';
      await api.getClient().post(`/api/servers/${server.id}/discover`).catch(() => {});
      spinner.succeed('Reconnect started');
      console.log(chalk.gray('Polling status (output below)...\n'));
    }

    const pollStart = Date.now();
    while (Date.now() - pollStart < RECONNECT_POLL_TIMEOUT_MS) {
      await new Promise((r) => setTimeout(r, POLL_INTERVAL_MS));
      const s = await fetchServer();
      if (!s) continue;
      const status = s.status || 'UNKNOWN';
      const err = s.healthError ? ` — ${s.healthError}` : '';
      console.log(chalk.cyan(`  [${new Date().toISOString()}] Status: ${status}${err}`));
      if (status === 'CONNECTED') {
        console.log(chalk.green('\nServer connected successfully.\n'));
        return;
      }
      if (status === 'ERROR') {
        console.log(chalk.red('\nConnection failed.' + (s.healthError ? ` ${s.healthError}` : '') + '\n'));
        return;
      }
    }
    console.log(chalk.yellow('\nPolling timed out. Check dashboard or run: clikdeploy servers list\n'));
  } catch (error: any) {
    spinner.fail('Reconnect failed');
    Formatters.error(error.response?.data?.error || error.message);
  }
}
