import ora from 'ora';
import Conf from 'conf';
import { getApiClient, requireAuth } from '../utils/api';
import { Formatters } from '../ui/formatters';
import chalk from 'chalk';
import { Prompts } from '../ui/prompts';
import { resolveServer } from '../utils/server-resolver';
export {
  discoverServer,
  reconnectServer,
  testServerAppLifecycle,
  testServerLifecycle,
} from './server-lifecycle';

const PROVISION_TIMEOUT_MS = 300_000; // 5 min for create + poll + connect

/**
 * Server Management Commands
 * Full server inspection and management
 */

export async function addServer(
  config: Conf,
  name: string,
  ipAddress: string,
  sshKey?: string,
  usernameOverride?: string
) {
  requireAuth(config);

  if (!name || !ipAddress) {
    Formatters.error('Please specify server name and IP address');
    Formatters.gray('Example: clikdeploy servers add "My Server" "192.168.1.100"');
    Formatters.gray('         clikdeploy servers add "My Server" "192.168.1.100" "~/.ssh/id_rsa"');
    return;
  }

  const api = getApiClient(config);
  const spinner = ora('Adding server...').start();

  try {
    // If no SSH key provided, prompt for it
    let sshKeyPath = sshKey;
    if (!sshKeyPath) {
      spinner.stop();
      sshKeyPath = await Prompts.askForInput('SSH key path:', '~/.ssh/id_rsa');
      spinner.start('Adding server...');
    }

    // Read SSH key from file
    const fs = await import('fs');
    const path = await import('path');
    const os = await import('os');
    const { execFileSync } = await import('child_process');
    
    const expandedPath = sshKeyPath.replace(/^~/, os.homedir());
    const fullPath = path.resolve(expandedPath);
    
    if (!fs.existsSync(fullPath)) {
      spinner.fail(`SSH key not found: ${fullPath}`);
      return;
    }
    
    const sshKeyContent = fs.readFileSync(fullPath, 'utf8');
    const pubKeyPath = `${fullPath}.pub`;

    const inferUsernameFromPublicKey = (): string | null => {
      if (!fs.existsSync(pubKeyPath)) return null;
      const content = fs.readFileSync(pubKeyPath, 'utf8').trim();
      const parts = content.split(/\s+/);
      if (parts.length < 3) return null;
      const comment = parts.slice(2).join(' ').trim();
      if (!comment) return null;

      // For GCP/OS Login keys, sanitized full email comment is often the SSH username.
      if (comment.includes('@')) {
        const sanitizedEmail = comment
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '_')
          .replace(/^_+|_+$/g, '');
        if (sanitizedEmail) return sanitizedEmail;
        const localPart = comment.split('@')[0]?.trim();
        return localPart || null;
      }

      return comment;
    };

    const inferGcpUsernameViaGcloud = (): string | null => {
      try {
        const instanceLine = execFileSync(
          'gcloud',
          [
            'compute',
            'instances',
            'list',
            `--filter=networkInterfaces[0].accessConfigs[0].natIP=('${ipAddress}')`,
            '--format=value(name,zone)',
          ],
          { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }
        ).trim();

        if (!instanceLine) return null;

        const [instanceName, zone] = instanceLine.split(/\s+/);
        if (!instanceName || !zone) return null;

        const dryRun = execFileSync(
          'gcloud',
          ['compute', 'ssh', instanceName, '--zone', zone, '--dry-run'],
          { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }
        );

        const escapedIp = ipAddress.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const usernameMatch = dryRun.match(
          new RegExp(`\\s([A-Za-z0-9._-]+)@${escapedIp}\\b`)
        );

        return usernameMatch?.[1] || null;
      } catch {
        return null;
      }
    };

    const autoDetectedUsername = (() => {
      const keyLooksLikeGcp = fullPath.includes('google_compute_engine');
      if (keyLooksLikeGcp) {
        const fromGcloud = inferGcpUsernameViaGcloud();
        if (fromGcloud) return fromGcloud;
      }
      return inferUsernameFromPublicKey();
    })();
    const sshUsername = (usernameOverride || autoDetectedUsername || 'ubuntu').trim();

    const server = await api.createServer({
      name,
      ipAddress,
      cloudProvider: 'OTHER',
      connectionType: 'SSH',
      credentials: {
        sshKey: sshKeyContent,
        sshUsername: sshUsername || 'ubuntu',
      },
    });

    spinner.succeed(`Server "${name}" added successfully`);

    console.log(chalk.bold('\n🖥️  Server Details:\n'));
    Formatters.info('Name:   ', server.name);
    Formatters.info('IP:     ', server.ipAddress);
    Formatters.info('Status: ', server.status);
    console.log();
  } catch (error: any) {
    spinner.fail('Failed to add server');
    Formatters.error(error.response?.data?.error || error.message);
  }
}

export type ProvisionProvider = 'GCP' | 'HETZNER' | 'DIGITALOCEAN';
export type ProvisionSize = 'SMALL' | 'MEDIUM' | 'LARGE';

export async function provisionServer(
  config: Conf,
  name: string,
  provider: ProvisionProvider,
  sizeTier: ProvisionSize,
  region?: string,
  apiCredentials?: Record<string, string>
) {
  requireAuth(config);

  const api = getApiClient(config, PROVISION_TIMEOUT_MS);
  const spinner = ora('Provisioning server (create → connect → register)...').start();

  try {
    const body: Record<string, unknown> = {
      name,
      provider,
      sizeTier,
      apiCredentials: apiCredentials || {},
    };
    if (region) body.region = region;

    const res = await api.getClient().post('/api/servers/provision', body);
    const server = res.data?.data ?? res.data;

    spinner.succeed(`Server "${name}" provisioned successfully`);

    console.log(chalk.bold('\n🖥️  Server Details:\n'));
    Formatters.info('Name:   ', server.name);
    Formatters.info('IP:     ', server.ipAddress);
    Formatters.info('Status: ', server.status);
    Formatters.info('Provider:', server.cloudProvider);
    console.log();
    Formatters.gray('Deploy an app: clikdeploy deploy -s ' + server.name);
    console.log();
  } catch (error: any) {
    spinner.fail('Provisioning failed');
    Formatters.error(error.response?.data?.error || error.message);
  }
}

/** Run provision flow: prompt for missing name/provider/size/region/credentials, then call provision API */
export async function runProvision(
  config: Conf,
  nameArg?: string,
  providerArg?: string,
  sizeArg?: string,
  regionArg?: string
) {
  requireAuth(config);

  const inquirer = (await import('inquirer')).default;
  const api = getApiClient(config, 15000);

  let name = nameArg?.trim();
  let provider = (providerArg?.toUpperCase() || '') as ProvisionProvider | '';
  let sizeTier = (sizeArg?.toUpperCase() || '') as ProvisionSize | '';
  let region = regionArg?.trim();

  const validProviders: ProvisionProvider[] = ['GCP', 'HETZNER', 'DIGITALOCEAN'];
  const validSizes: ProvisionSize[] = ['SMALL', 'MEDIUM', 'LARGE'];

  if (!name) {
    const { nameInput } = await inquirer.prompt([{ type: 'input', name: 'nameInput', message: 'Server name:', default: 'my-server' }]);
    name = nameInput?.trim() || 'my-server';
  }
  if (!provider || !validProviders.includes(provider)) {
    const { providerChoice } = await inquirer.prompt([
      { type: 'list', name: 'providerChoice', message: 'Provider:', choices: validProviders.map((p) => ({ name: p, value: p })) },
    ]);
    provider = providerChoice;
  }
  if (!sizeTier || !validSizes.includes(sizeTier)) {
    const { sizeChoice } = await inquirer.prompt([
      { type: 'list', name: 'sizeChoice', message: 'Size:', choices: validSizes.map((s) => ({ name: s, value: s })) },
    ]);
    sizeTier = sizeChoice;
  }

  // Optional: fetch default region from API
  if (!region) {
    try {
      const { data } = await api.getClient().get(`/api/servers/provision?provider=${provider}`);
      if (data?.data?.defaultRegion) {
        const { useDefault } = await inquirer.prompt([
          {
            type: 'confirm',
            name: 'useDefault',
            message: `Use default region ${data.data.defaultRegion}?`,
            default: true,
          },
        ]);
        if (useDefault) region = data.data.defaultRegion;
      }
    } catch {
      // ignore
    }
  }
  if (!region) {
    const { regionInput } = await inquirer.prompt([
      { type: 'input', name: 'regionInput', message: 'Region (e.g. fsn1, nyc1, us-central1-a):', default: '' },
    ]);
    region = regionInput?.trim() || undefined;
  }

  const apiCredentials: Record<string, string> = {};

  if (provider === 'GCP') {
    const accessToken = process.env.CLICKDEPLOY_GCP_ACCESS_TOKEN || process.env.GCP_ACCESS_TOKEN;
    const projectId = process.env.CLICKDEPLOY_GCP_PROJECT_ID || process.env.GCP_PROJECT_ID;
    if (!accessToken || !projectId) {
      console.log(chalk.gray('GCP: Use dashboard to provision (OAuth), or set CLICKDEPLOY_GCP_ACCESS_TOKEN and CLICKDEPLOY_GCP_PROJECT_ID'));
      const { tokenInput } = await inquirer.prompt([{ type: 'password', name: 'tokenInput', message: 'GCP access token (or leave empty to abort):' }]);
      if (tokenInput) apiCredentials.accessToken = tokenInput;
      const { projectInput } = await inquirer.prompt([{ type: 'input', name: 'projectInput', message: 'GCP project ID:' }]);
      if (projectInput) apiCredentials.projectId = projectInput;
    } else {
      apiCredentials.accessToken = accessToken;
      apiCredentials.projectId = projectId;
    }
  } else if (provider === 'HETZNER') {
    const token = process.env.CLICKDEPLOY_HETZNER_API_TOKEN || process.env.HETZNER_API_TOKEN;
    if (token) {
      apiCredentials.apiToken = token;
    } else {
      const { tokenInput } = await inquirer.prompt([{ type: 'password', name: 'tokenInput', message: 'Hetzner API token:' }]);
      if (tokenInput) apiCredentials.apiToken = tokenInput;
    }
  } else if (provider === 'DIGITALOCEAN') {
    const token = process.env.CLICKDEPLOY_DIGITALOCEAN_API_TOKEN || process.env.DIGITALOCEAN_API_TOKEN;
    if (token) {
      apiCredentials.apiToken = token;
    } else {
      const { tokenInput } = await inquirer.prompt([{ type: 'password', name: 'tokenInput', message: 'DigitalOcean API token:' }]);
      if (tokenInput) apiCredentials.apiToken = tokenInput;
    }
  }

  if (Object.keys(apiCredentials).length === 0 && (provider === 'HETZNER' || provider === 'DIGITALOCEAN')) {
    Formatters.error('API token required. Set env or enter when prompted.');
    return;
  }
  if (provider === 'GCP' && (!apiCredentials.accessToken || !apiCredentials.projectId)) {
    Formatters.error('GCP requires access token and project ID.');
    return;
  }

  await provisionServer(config, name!, provider as ProvisionProvider, sizeTier as ProvisionSize, region, apiCredentials);
}

export async function deleteServer(config: Conf, serverName: string, skipConfirm?: boolean) {
  requireAuth(config);

  if (!serverName) {
    Formatters.error('Please specify a server name or ID');
    Formatters.gray('Example: clikdeploy servers delete "Custom Server"');
    return;
  }

  const api = getApiClient(config);
  let spinner = ora('Finding server...').start();

  try {
    const server = await resolveServer(api, serverName);

    if (!server) {
      spinner.fail(`Server "${serverName}" not found`);
      return;
    }

    spinner.stop();

    // SIMPLIFIED: Only confirm if --confirm flag is set (opt-in safety)
    if (skipConfirm) {
      const confirmed = await Prompts.confirm(`Delete server "${server.name}"?`);
      if (!confirmed) {
        console.log(chalk.gray('Cancelled'));
        return;
      }
    }

    spinner = ora('Deleting server...').start();

    await api.deleteServer(server.id);

    spinner.succeed(`Server "${server.name}" deleted`);
    console.log();
  } catch (error: any) {
    spinner.fail('Failed to delete server');
    Formatters.error(error.response?.data?.error || error.message);
  }
}

export async function inspectServer(config: Conf, serverName: string) {
  requireAuth(config);

  if (!serverName) {
    Formatters.error('Please specify a server name or ID');
    Formatters.gray('Example: clikdeploy servers inspect "Custom Server"');
    return;
  }

  const api = getApiClient(config);
  const spinner = ora('Inspecting server...').start();

  try {
    const server = await resolveServer(api, serverName);

    if (!server) {
      spinner.fail(`Server "${serverName}" not found`);
      return;
    }

    spinner.stop();

    console.log(chalk.bold(`\n🖥️  ${server.name}\n`));
    Formatters.info('Status:   ', server.status);
    Formatters.info('IP:       ', server.ipAddress);
    Formatters.info('Provider: ', server.cloudProvider || 'SSH');

    // GCP: show instance metadata so user can verify in GCP console (instance IP vs server IP, ssh-keys)
    if (server.cloudProvider === 'GCP' && server.metadata) {
      const meta = server.metadata as Record<string, unknown>;
      const projectId = meta.projectId ?? (server.metadata as any)?.projectId;
      const instanceId = meta.instanceId ?? (server.metadata as any)?.instanceId;
      const zone = meta.zone ?? (server.metadata as any)?.zone ?? server.region;
      if (projectId || instanceId || zone) {
        console.log(chalk.bold('\n☁️  GCP instance (for console check):\n'));
        if (projectId) Formatters.info('Project:  ', String(projectId));
        if (instanceId) Formatters.info('Instance: ', String(instanceId));
        if (zone) Formatters.info('Zone:     ', String(zone));
        console.log(chalk.gray('  → In GCP Console: Compute → VM instances → check this instance\'s external IP matches server IP above'));
        console.log(chalk.gray('  → We use OS Login: VM must have "Enable OS Login" ON (Edit → Security). Your Google account needs role "Compute OS Login User" in IAM.\n'));
      }
    }

    // Show why the server is not connected (healthError from connection test, discovery, or universal connection)
    if (server.healthError) {
      const label = server.status === 'ERROR' ? '\n❌ Error details (why not connected):\n' : '\n⚠️  Last error / status message:\n';
      console.log(chalk.bold(label));
      Formatters.error(server.healthError);
      console.log();
    }
    
    if (server.metadata?.discovery) {
      const discovery = server.metadata.discovery;

      if (discovery.docker) {
        const d = discovery.docker;
        console.log(chalk.bold('\n🐳 Docker:\n'));
        Formatters.info('Version: ', d.version || '-');
        Formatters.info('Rootless:', d.rootless ? chalk.green('yes') : chalk.gray('no'));
        if (d.rootless && d.socketPath) Formatters.info('Socket:  ', d.socketPath);
        if (d.warning) {
          console.log(chalk.yellow('  Warning: ' + d.warning));
        }
      }

      if (discovery.docker?.images) {
        console.log(chalk.bold('\n📦 Docker Images:\n'));
        discovery.docker.images.slice(0, 10).forEach((img: any) => {
          console.log(`  ${chalk.cyan(img.repository)}:${img.tag} (${img.size})`);
        });
        if (discovery.docker.images.length > 10) {
          console.log(chalk.gray(`  ... and ${discovery.docker.images.length - 10} more`));
        }
      }

      if (discovery.docker?.containers) {
        console.log(chalk.bold('\n🐳 Running Containers:\n'));
        discovery.docker.containers.slice(0, 10).forEach((container: any) => {
          console.log(`  ${chalk.cyan(container.name)} (${container.status})`);
        });
        if (discovery.docker.containers.length > 10) {
          console.log(chalk.gray(`  ... and ${discovery.docker.containers.length - 10} more`));
        }
      }

      if (discovery.docker?.volumes) {
        console.log(chalk.bold('\n💾 Volumes:\n'));
        console.log(`  ${discovery.docker.volumes.length} volumes`);
      }

      if (discovery.docker?.networks) {
        console.log(chalk.bold('\n🌐 Networks:\n'));
        console.log(`  ${discovery.docker.networks.length} networks`);
      }

      if (discovery.reverseProxy) {
        console.log(chalk.bold('\n🔀 Reverse Proxy:\n'));
        Formatters.info('Type:   ', discovery.reverseProxy.type);
        Formatters.info('Running:', discovery.reverseProxy.running ? 'yes' : 'no');
        if (discovery.reverseProxy.version) Formatters.info('Version:', discovery.reverseProxy.version);
      }
    }

    console.log();
  } catch (error: any) {
    spinner.fail('Failed to inspect server');
    Formatters.error(error.response?.data?.error || error.message);
  }
}

export async function execOnServer(config: Conf, serverName: string, command: string) {
  requireAuth(config);

  if (!serverName || !command) {
    Formatters.error('Please specify server and command');
    Formatters.gray('Example: clikdeploy servers exec "Custom Server" "docker ps"');
    return;
  }

  const api = getApiClient(config);
  const spinner = ora('Executing command...').start();

  try {
    const server = await resolveServer(api, serverName);

    if (!server) {
      spinner.fail(`Server "${serverName}" not found`);
      return;
    }

    const { data } = await api.getClient().post(`/api/servers/${server.id}/exec`, { command });

    spinner.stop();

    console.log(chalk.bold('\n📤 Output:\n'));
    console.log(data?.data?.stdout || data?.data?.stderr || '(no output)');
    console.log();
  } catch (error: any) {
    spinner.fail('Command execution failed');
    Formatters.error(error.response?.data?.error || error.message);
  }
}

export async function cleanupServer(config: Conf, serverName: string) {
  requireAuth(config);

  if (!serverName) {
    Formatters.error('Please specify a server name or ID');
    Formatters.gray('Example: clikdeploy servers cleanup "Custom Server"');
    return;
  }

  const api = getApiClient(config);
  const spinner = ora('Cleaning up server...').start();

  try {
    const server = await resolveServer(api, serverName);

    if (!server) {
      spinner.fail(`Server "${serverName}" not found`);
      return;
    }

    const { data } = await api.getClient().post(`/api/servers/${server.id}/cleanup`);

    spinner.succeed('Server cleaned up');

    if (data?.data?.cleaned) {
      const { volumes, networks, containers } = data.data.cleaned;
      console.log(chalk.bold('\n🧹 Cleanup Summary:\n'));
      if (volumes) Formatters.info('Volumes:   ', volumes.toString());
      if (networks) Formatters.info('Networks:  ', networks.toString());
      if (containers) Formatters.info('Containers:', containers.toString());
    }
    console.log();
  } catch (error: any) {
    spinner.fail('Cleanup failed');
    Formatters.error(error.response?.data?.error || error.message);
  }
}

/** Get the stored private key (and username) for a server. OAuth-created servers have keys stored here. */
export async function getServerKey(config: Conf, serverNameOrId: string, savePath?: string) {
  requireAuth(config);

  if (!serverNameOrId) {
    Formatters.error('Please specify a server name or ID');
    Formatters.gray('Example: clikdeploy servers key "gcp-34-174-203-154"');
    Formatters.gray('         clikdeploy servers key "gcp-34-174-203-154" --save ~/.ssh/clikdeploy_gcp');
    return;
  }

  const api = getApiClient(config);
  const spinner = ora('Resolving server...').start();

  try {
    const server = await resolveServer(api, serverNameOrId);

    if (!server) {
      spinner.fail(`Server "${serverNameOrId}" not found`);
      return;
    }

    spinner.text = 'Fetching credentials...';
    const { data } = await api.getClient().get(`/api/servers/${server.id}/credentials`);

    if (!data?.success || !data?.data?.privateKey) {
      spinner.fail('No stored private key for this server');
      Formatters.gray('OAuth-connected servers store the key after the first connect. If you just connected, wait a moment and try again.');
      return;
    }

    spinner.succeed('Credentials retrieved');

    const { privateKey, username } = data.data;

    if (savePath) {
      const fs = await import('fs');
      const path = await import('path');
      const os = await import('os');
      const expanded = savePath.replace(/^~/, os.homedir());
      const full = path.resolve(expanded);
      fs.writeFileSync(full, privateKey, { mode: 0o600 });
      console.log(chalk.bold('\n🔑 Private key saved:\n'));
      Formatters.info('File:    ', full);
      if (username) Formatters.info('Username:', username ?? '—');
      console.log(chalk.gray('\nUse: ssh -i ' + full + (username ? ` ${username}@<host>` : ' <user>@<host>') + '\n'));
    } else {
      console.log(chalk.bold('\n🔑 Private key (paste into ~/.ssh/ or use --save <path>):\n'));
      console.log(privateKey);
      if (username) {
        console.log(chalk.bold('\nUsername: '), username);
      }
      console.log();
    }
  } catch (error: any) {
    spinner.fail('Failed to get server key');
    Formatters.error(error.response?.data?.error || error.message);
  }
}
