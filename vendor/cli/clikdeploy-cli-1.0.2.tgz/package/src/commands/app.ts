import ora from 'ora';
import Conf from 'conf';
import { getApiClient, requireAuth } from '../utils/api';
import { Formatters } from '../ui/formatters';
import chalk from 'chalk';
import { Prompts } from '../ui/prompts';
import { streamLogs } from './status';
import { resolveApp, resolveApps, showDisambiguationHint } from '../utils/app-resolver';
import { shouldSuppressContainerLine } from '../utils/deploy-log-shaper';
import { displayId } from '../utils/id-format';

/** Container name slug from app name (matches platform slugForContainer). */
function slugForContainer(name: string): string {
  return (name ?? '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');
}

/**
 * App Management Commands
 * Delete, restart, update domain/SSL, manage environment variables
 */

// SIMPLIFIED: Default autonomous - no confirmations unless --confirm flag
export async function deleteAppCommand(
  config: Conf,
  appNames: string | string[],
  requireConfirm: boolean = false,
  deleteAll: boolean = false
) {
  requireAuth(config);

  const api = getApiClient(config, 120_000);
  const allApps = await api.getApps();
  const appsByIdOrName = new Map<string, any>();
  for (const app of allApps) {
    if (app?.id) appsByIdOrName.set(String(app.id), app);
    if (app?.name) appsByIdOrName.set(String(app.name), app);
  }

  let appsToDelete: any[];
  if (deleteAll) {
    appsToDelete = allApps;
    if (!appsToDelete.length) {
      console.log(chalk.gray('No apps to delete'));
      return;
    }
  } else {
    const apps = Array.isArray(appNames) ? appNames : [appNames];
    if (!apps.length) {
      Formatters.error('Please specify at least one app name or use --all');
      Formatters.gray('Example: clikdeploy apps delete n8n ghost vaultwarden');
      Formatters.gray('Example: clikdeploy apps delete --all');
      return;
    }
    appsToDelete = apps
      .map((name) => appsByIdOrName.get(name))
      .filter(Boolean);
  }

  if (appsToDelete.length === 0 && !deleteAll) {
    Formatters.error(`No apps found matching: ${(Array.isArray(appNames) ? appNames : [appNames]).join(', ')}`);
    return;
  }

  // Only prompt if --confirm flag is set (opt-in safety)
  if (requireConfirm) {
    const names = appsToDelete.map((a: any) => a.name).join(', ');
    try {
      const confirmed = await Prompts.confirm(`Delete ${chalk.cyan(names)}? This cannot be undone.`);
      if (!confirmed) {
        console.log(chalk.gray('Cancelled'));
        return;
      }
    } catch (err) {
      // Non-interactive mode - proceed
    }
  }

  // Bounded parallel delete workers (fast under load, without stampeding API/server).
  const configuredDeleteConcurrency = parseInt(
    process.env.CLIKDEPLOY_DELETE_CONCURRENCY || '',
    10
  );
  const deleteConcurrency = Number.isFinite(configuredDeleteConcurrency) && configuredDeleteConcurrency > 0
    ? configuredDeleteConcurrency
    : appsToDelete.length;
  const spinner = ora(
    `Deleting ${appsToDelete.length} app(s) with concurrency ${deleteConcurrency}...`
  ).start();
  const appIds = appsToDelete.map((app: any) => app.id);
  const targetAppNames = appsToDelete.map((app: any) => app.name);

  type DeleteResult = {
    appId: string;
    appName: string;
    status: 'deleted' | 'already_deleted' | 'failed';
    error?: string;
  };

  const streamDeleteApp = async (app: any): Promise<void> => {
    const response = await api.getClient().request({
      method: 'delete',
      url: `/api/apps/${app.id}?stream=1`,
      responseType: 'stream',
      timeout: 0,
      headers: { Accept: 'text/event-stream' },
    });
    const stream = response.data as NodeJS.ReadableStream;
    let buffer = '';
    let failedMessage = '';
    let completed = false;

    const parseFrame = (raw: string) => {
      let eventName = 'message';
      let data = '';
      for (const line of raw.split('\n')) {
        if (line.startsWith('event:')) eventName = line.slice(6).trim();
        else if (line.startsWith('data:')) data += line.slice(5).trim();
      }
      if (!data) return;
      let payload: any = data;
      try {
        payload = JSON.parse(data);
      } catch {
        // Keep raw string
      }

      if (eventName === 'progress') {
        const msg = payload?.message || 'Deleting...';
        spinner.text = `Deleting ${appsToDelete.length} app(s)... ${msg}`;
      } else if (eventName === 'failed') {
        failedMessage = payload?.message || payload?.error || 'Delete failed';
      } else if (eventName === 'completed') {
        completed = true;
      }
    };

    await new Promise<void>((resolve, reject) => {
      stream.on('data', (chunk: Buffer | string) => {
        buffer += chunk.toString();
        let boundary = buffer.indexOf('\n\n');
        while (boundary >= 0) {
          const frame = buffer.slice(0, boundary);
          buffer = buffer.slice(boundary + 2);
          if (frame.trim()) parseFrame(frame);
          boundary = buffer.indexOf('\n\n');
        }
      });
      stream.on('end', resolve);
      stream.on('error', reject);
    });

    if (failedMessage) throw new Error(failedMessage);
    if (!completed) throw new Error('Delete stream ended without completion event');
  };

  const deleteOne = async (app: any): Promise<DeleteResult> => {
    try {
      await streamDeleteApp(app);
      return { appId: app.id, appName: app.name, status: 'deleted' };
    } catch (err: any) {
      if (err?.response?.status === 404) {
        return { appId: app.id, appName: app.name, status: 'already_deleted' };
      }
      return {
        appId: app.id,
        appName: app.name,
        status: 'failed',
        error: err?.response?.data?.error || err?.message || 'Unknown error',
      };
    }
  };

  const pending = [...appsToDelete];
  const deleteResults: DeleteResult[] = [];
  const workers = Array.from({ length: Math.min(deleteConcurrency, pending.length) }, async () => {
    while (pending.length > 0) {
      const app = pending.shift();
      if (!app) return;
      const result = await deleteOne(app);
      deleteResults.push(result);
      const done = deleteResults.length;
      const failedCount = deleteResults.filter((r) => r.status === 'failed').length;
      spinner.text = `Deleting ${appsToDelete.length} app(s)... (${done}/${appsToDelete.length}, failed: ${failedCount})`;
    }
  });

  await Promise.all(workers);

  const deletedCount = deleteResults.filter((r) => r.status === 'deleted').length;
  const alreadyDeletedCount = deleteResults.filter((r) => r.status === 'already_deleted').length;
  const failedResults = deleteResults.filter((r) => r.status === 'failed');

  if (failedResults.length > 0) {
    spinner.warn(
      `Deleted ${deletedCount}, already deleted ${alreadyDeletedCount}, failed ${failedResults.length}`
    );
    for (const result of failedResults) {
      Formatters.error(`Failed to delete ${result.appName}: ${result.error || 'Unknown error'}`);
    }
  } else {
    spinner.succeed(
      `Deleted ${deletedCount} app(s)${
        alreadyDeletedCount ? ` (${alreadyDeletedCount} already deleted)` : ''
      }`
    );
  }

  // Single definitive verification check after stream completions.
  const verifySpinner = ora('Verifying final state...').start();
  try {
    const currentApps = await api.getApps();
    const remaining = currentApps.filter(
      (app: any) => appIds.includes(app.id) || targetAppNames.includes(app.name)
    );
    if (remaining.length === 0) {
      verifySpinner.succeed('All targeted apps are removed');
    } else {
      verifySpinner.warn(`Deletion completed but ${remaining.length} targeted app(s) still exist`);
    }
  } catch {
    verifySpinner.warn('Could not verify final state (delete stream did complete)');
  }

  if (failedResults.length > 0) throw new Error(`Failed to delete ${failedResults.length} app(s)`);
}

export async function restartApp(config: Conf, appIdentifier: string) {
  requireAuth(config);

  if (!appIdentifier) {
    Formatters.error('Please specify an app name or ID');
    Formatters.gray('Example: clikdeploy apps restart n8n');
    Formatters.gray('Example: clikdeploy apps restart gcp-server n8n');
    return;
  }

  const api = getApiClient(config);
  const spinner = ora('Restarting app...').start();

  try {
    const resolved = await resolveApp(api, appIdentifier);
    
    if (!resolved) {
      spinner.fail(`App "${appIdentifier}" not found`);
      const allApps = await api.getApps();
      showDisambiguationHint(appIdentifier, allApps);
      return;
    }

    const { app } = resolved;
    await api.getClient().post(`/api/apps/${app.id}/restart`);

    spinner.succeed(`App ${chalk.cyan(app.name)} restarted`);
  } catch (error: any) {
    spinner.fail('Failed to restart app');
    Formatters.error(error.response?.data?.error || error.message);
  }
}

/** Trigger a new deployment for existing app(s) by name or ID (fetch latest, rebuild, restart). */
export async function deployApp(
  config: Conf,
  appIdentifiers: string | string[],
  options: { wait?: boolean } = {}
) {
  requireAuth(config);

  const ids = Array.isArray(appIdentifiers) ? appIdentifiers : [appIdentifiers];
  if (!ids.length) {
    Formatters.error('Please specify at least one app name or ID');
    Formatters.gray('Example: clikdeploy apps redeploy openclaw');
    Formatters.gray('Example: clikdeploy apps redeploy gcp-server n8n');
    Formatters.gray('Example: clikdeploy apps redeploy <id1> <id2>');
    return;
  }

  const api = getApiClient(config, 120000);

  try {
    const resolved = await resolveApps(api, ids, { allowPartial: false });
    
    if (resolved.length === 0) {
      Formatters.error(`No apps found for: ${ids.join(', ')}`);
      return;
    }
    
    const toRedeploy = resolved.map(r => r.app);
    const startSpinner = ora(`Starting ${toRedeploy.length} redeployments in parallel...`).start();

    const started = await Promise.all(
      toRedeploy.map(async (app) => {
        try {
          const deployment = await api.deployApp(app.id, {});
          const deploymentId = deployment?.id ?? deployment?.data?.id;
          if (!deploymentId) {
            return { app, ok: false as const, error: 'no deployment id returned' };
          }
          return { app, ok: true as const, deploymentId };
        } catch (err: any) {
          return {
            app,
            ok: false as const,
            error: err?.response?.data?.error || err?.message || 'Unknown error',
          };
        }
      })
    );

    const startFailures = started.filter((x) => !x.ok);
    const startedOk = started.filter((x) => x.ok) as Array<{
      app: any;
      ok: true;
      deploymentId: string;
    }>;

    if (startFailures.length > 0) {
      startSpinner.warn(
        `Started ${startedOk.length}/${toRedeploy.length} deployments (${startFailures.length} failed to start)`
      );
      for (const failure of startFailures) {
        Formatters.error(`Failed to start ${failure.app.name}: ${failure.error}`);
      }
    } else {
      startSpinner.succeed(`Started ${startedOk.length} deployment(s) in parallel`);
    }

    for (const startedDeployment of startedOk) {
      console.log(
        chalk.green('✔'),
        `${startedDeployment.app.name}: ${chalk.cyan(displayId(startedDeployment.deploymentId))}`
      );
    }

    if (options.wait === false) {
      if (toRedeploy.length === 1) {
        console.log(
          chalk.gray('Run'),
          chalk.cyan(`clikdeploy status ${toRedeploy[0].name}`),
          chalk.gray('to check progress')
        );
      }
      return;
    }

    const pollMs = 3000;
    const maxWaitMs = 600000;
    const waitSpinner = ora(`Waiting for ${startedOk.length} deployment(s)...`).start();

    const waitResults = await Promise.all(
      startedOk.map(async (startedDeployment) => {
        const { app, deploymentId } = startedDeployment;
        const start = Date.now();
        while (Date.now() - start < maxWaitMs) {
          await new Promise((r) => setTimeout(r, pollMs));
          const deployments = await api.getAppDeployments(app.id);
          const dep = deployments.find((d: any) => d.id === deploymentId);
          if (!dep) continue;
          if (dep.status === 'SUCCESS') {
            return { app, status: 'SUCCESS' as const, dep };
          }
          if (dep.status === 'FAILED') {
            return { app, status: 'FAILED' as const, dep };
          }
        }
        return { app, status: 'TIMEOUT' as const, dep: null };
      })
    );

    const success = waitResults.filter((r) => r.status === 'SUCCESS');
    const failed = waitResults.filter((r) => r.status === 'FAILED');
    const timedOut = waitResults.filter((r) => r.status === 'TIMEOUT');

    if (failed.length > 0 || timedOut.length > 0) {
      waitSpinner.warn(
        `Completed with issues: success ${success.length}, failed ${failed.length}, timeout ${timedOut.length}`
      );
    } else {
      waitSpinner.succeed(`All ${success.length} deployment(s) completed successfully`);
    }

    for (const result of success) {
      if (result.dep?.metadata?.url) {
        console.log(chalk.green('  URL:'), chalk.cyan(result.dep.metadata.url));
      }
    }
    for (const result of failed) {
      console.log(chalk.red(`${result.app.name}: deployment failed`));
      if (result.dep?.error) console.log(chalk.red(result.dep.error));
    }
    for (const result of timedOut) {
      console.log(chalk.yellow(`${result.app.name}: timeout waiting for deployment status`));
    }
  } catch (error: any) {
    Formatters.error(error.response?.data?.error || error.message);
  }
}

export async function viewContainerLogs(config: Conf, appIdentifiers: string | string[], options: { lines?: number; follow?: boolean } = {}) {
  requireAuth(config);

  const identifiers = Array.isArray(appIdentifiers) ? appIdentifiers : [appIdentifiers];
  const lines = options.lines || 100;
  const follow = options.follow || false;

  if (!identifiers.length) {
    Formatters.error('Please specify at least one app name');
    Formatters.gray('Example: clikdeploy apps logs n8n ghost vaultwarden');
    Formatters.gray('Example: clikdeploy apps logs gcp-server n8n');
    return;
  }

  const api = getApiClient(config);

  // Resolve apps with server filtering
  let resolved = await resolveApps(api, identifiers, { allowPartial: true });

  // Support multi-word app names passed as split tokens in variadic args.
  if (resolved.length === 0 && identifiers.length > 1) {
    const joinedIdentifier = identifiers.join(' ').trim();
    if (joinedIdentifier) {
      resolved = await resolveApps(api, [joinedIdentifier], { allowPartial: true });
    }
  }

  if (resolved.length === 0) {
    Formatters.error(`No apps found matching: ${identifiers.join(', ')}`);
    return;
  }
  
  const appsToView = resolved.map(r => r.app);

  // Follow mode: only for single app; delegate to streaming
  if (follow && appsToView.length === 1) {
    console.log(chalk.bold(`\n📋 Streaming Logs: ${chalk.cyan(appsToView[0].name)}`) + chalk.gray(' (Ctrl+C to stop)\n'));
    await streamLogs(api, appsToView[0].id);
    return;
  }

  if (follow && appsToView.length > 1) {
    console.log(chalk.yellow(`Follow (-f) only supported for a single app. Showing last ${lines} lines for each.\n`));
  }

  // Fetch logs for each app
  for (const app of appsToView) {
    try {
      console.log(chalk.bold(`\n📋 Container Logs: ${chalk.cyan(app.name)} (${app.id})\n`));

      const res = await api.getClient().get(`/api/apps/${app.id}/logs`, { params: { limit: lines } });
      const raw = res?.data?.data;

      // API can return array (deployment logs) or legacy string (raw Docker logs)
      if (Array.isArray(raw) && raw.length > 0) {
        const levelColor: Record<string, (s: string) => string> = {
          DEBUG: chalk.gray,
          INFO: chalk.blue,
          WARN: chalk.yellow,
          ERROR: chalk.red,
          FATAL: chalk.bgRed.white,
        };
        raw.forEach((log: { timestamp?: string; level?: string; message?: string }) => {
          const time = log.timestamp ? new Date(log.timestamp).toLocaleTimeString() : '';
          const level = (log.level || 'INFO').toUpperCase();
          const color = levelColor[level] || chalk.white;
          console.log(`${chalk.gray(time)} ${color((level).padEnd(5))} ${log.message ?? ''}`);
        });
      } else if (typeof raw === 'string' && raw.trim().length > 0) {
        const logLines = raw
          .split('\n')
          .filter((line: string) => line.trim().length > 0)
          .filter((line: string) => !shouldSuppressContainerLine(line));
        logLines.forEach((line: string) => {
          let lineColor = chalk.white;
          if (line.toLowerCase().includes('error') || line.toLowerCase().includes('failed')) lineColor = chalk.red;
          else if (line.toLowerCase().includes('warn') || line.toLowerCase().includes('warning')) lineColor = chalk.yellow;
          else if (line.toLowerCase().includes('info') || line.toLowerCase().includes('success')) lineColor = chalk.green;
          console.log(lineColor(line));
        });
      } else {
        console.log(chalk.gray('No logs available'));
      }
    } catch (error: any) {
      Formatters.error(`Failed to fetch logs for ${app.name}: ${error.response?.data?.error || error.message}`);
    }
  }

  console.log(); // Empty line at end
}

export async function updateDomain(config: Conf, appIdentifier: string, domain?: string) {
  requireAuth(config);

  if (!appIdentifier) {
    Formatters.error('Please specify an app name');
    Formatters.gray('Example: clikdeploy apps domain n8n my-n8n.example.com');
    Formatters.gray('Example: clikdeploy apps domain gcp-server n8n my-n8n.example.com');
    return;
  }

  const api = getApiClient(config);

  try {
    const resolved = await resolveApp(api, appIdentifier);
    
    if (!resolved) {
      Formatters.error(`App "${appIdentifier}" not found`);
      const allApps = await api.getApps();
      showDisambiguationHint(appIdentifier, allApps);
      return;
    }

    const { app } = resolved;

    // SIMPLIFIED: If domain not provided, show error (no prompts)
    if (!domain) {
      Formatters.error('Domain is required');
      Formatters.gray('Example: clikdeploy apps domain n8n my-n8n.example.com');
      Formatters.gray('Example: clikdeploy apps domain gcp-server n8n my-n8n.example.com');
      return;
    }

    const spinner = ora('Updating domain...').start();

    await api.getClient().patch(`/api/apps/${app.id}`, { domain });

    spinner.succeed(`Domain updated to ${chalk.cyan(domain)}`);
  } catch (error: any) {
    Formatters.error('Failed to update domain');
    Formatters.gray(error.response?.data?.error || error.message);
  }
}

export async function toggleSSL(config: Conf, appIdentifier: string) {
  requireAuth(config);

  if (!appIdentifier) {
    Formatters.error('Please specify an app name');
    Formatters.gray('Example: clikdeploy apps ssl n8n');
    Formatters.gray('Example: clikdeploy apps ssl gcp-server n8n');
    return;
  }

  const api = getApiClient(config);

  try {
    const resolved = await resolveApp(api, appIdentifier);
    
    if (!resolved) {
      Formatters.error(`App "${appIdentifier}" not found`);
      const allApps = await api.getApps();
      showDisambiguationHint(appIdentifier, allApps);
      return;
    }

    const { app } = resolved;

    const newState = !app.sslEnabled;
    const spinner = ora(`${newState ? 'Enabling' : 'Disabling'} SSL...`).start();

    await api.getClient().patch(`/api/apps/${app.id}`, { sslEnabled: newState });

    spinner.succeed(`SSL ${newState ? 'enabled' : 'disabled'}`);
  } catch (error: any) {
    Formatters.error('Failed to toggle SSL');
    Formatters.gray(error.response?.data?.error || error.message);
  }
}

export async function setEnvVar(config: Conf, appIdentifier: string, key?: string, value?: string) {
  requireAuth(config);

  if (!appIdentifier) {
    Formatters.error('Please specify an app name');
    Formatters.gray('Example: clikdeploy apps env n8n KEY VALUE');
    Formatters.gray('Example: clikdeploy apps env gcp-server n8n KEY VALUE');
    return;
  }

  const api = getApiClient(config);

  try {
    const resolved = await resolveApp(api, appIdentifier);
    
    if (!resolved) {
      Formatters.error(`App "${appIdentifier}" not found`);
      const allApps = await api.getApps();
      showDisambiguationHint(appIdentifier, allApps);
      return;
    }

    const { app } = resolved;

    // SIMPLIFIED: Key and value must be provided (no prompts)
    if (!key || !value) {
      Formatters.error('Both key and value are required');
      Formatters.gray('Example: clikdeploy apps env n8n DATABASE_URL postgres://...');
      return;
    }

    const spinner = ora('Setting environment variable...').start();

    // Use dedicated env endpoint so env vars are stored in the canonical env repository.
    const currentRes = await api.getClient().get(`/api/apps/${app.id}/env`);
    const currentEnv =
      currentRes?.data?.data && typeof currentRes.data.data === 'object'
        ? currentRes.data.data
        : {};
    const updatedEnv = { ...currentEnv, [key]: value };

    await api.getClient().put(`/api/apps/${app.id}/env`, updatedEnv);

    spinner.succeed(`Set ${chalk.cyan(key)}=${value}`);
    Formatters.gray('\n⚠️  Restart the app for changes to take effect');
  } catch (error: any) {
    Formatters.error('Failed to set environment variable');
    Formatters.gray(error.response?.data?.error || error.message);
  }
}

export async function listEnvVars(config: Conf, appIdentifier: string) {
  requireAuth(config);

  if (!appIdentifier) {
    Formatters.error('Please specify an app name');
    Formatters.gray('Example: clikdeploy apps env n8n');
    Formatters.gray('Example: clikdeploy apps env gcp-server n8n');
    return;
  }

  const api = getApiClient(config);

  try {
    const resolved = await resolveApp(api, appIdentifier);
    
    if (!resolved) {
      Formatters.error(`App "${appIdentifier}" not found`);
      const allApps = await api.getApps();
      showDisambiguationHint(appIdentifier, allApps);
      return;
    }

    const { app } = resolved;

    // Read from dedicated env endpoint (source of truth).
    const res = await api.getClient().get(`/api/apps/${app.id}/env`);
    const envVars =
      res?.data?.data && typeof res.data.data === 'object' ? res.data.data : {};
    const keys = Object.keys(envVars);

    if (keys.length === 0) {
      console.log(chalk.yellow('\nNo environment variables set'));
      return;
    }

    console.log(chalk.bold(`\n🔐 Environment Variables (${keys.length})\n`));

    for (const key of keys) {
      const value = envVars[key];
      const displayValue = value.length > 50 ? `${value.slice(0, 47)}...` : value;
      console.log(`  ${chalk.cyan(key.padEnd(30))} ${chalk.gray(displayValue)}`);
    }

    console.log();
  } catch (error: any) {
    Formatters.error('Failed to list environment variables');
    Formatters.gray(error.response?.data?.error || error.message);
  }
}

/**
 * Run a command inside a deployed app's container (for testing CLI apps, e.g. Claude Code).
 * Resolves app by name or ID, then runs the command via the server exec API.
 */
export async function execInApp(config: Conf, appIdentifier: string, command: string) {
  requireAuth(config);

  if (!appIdentifier || !command) {
    Formatters.error('Please specify app and command');
    Formatters.gray('Example: clikdeploy apps exec claude-code "claude --help"');
    Formatters.gray('Example: clikdeploy apps exec gcp-server n8n "n8n --version"');
    return;
  }

  const api = getApiClient(config);
  const spinner = ora('Running command in app...').start();

  try {
    const resolved = await resolveApp(api, appIdentifier);
    
    if (!resolved) {
      spinner.fail(`App "${appIdentifier}" not found`);
      const allApps = await api.getApps();
      showDisambiguationHint(appIdentifier, allApps);
      return;
    }

    const { app } = resolved;

    const serverId = app.serverId ?? app.server?.id;
    if (!serverId) {
      spinner.fail(`App "${app.name}" has no server`);
      return;
    }

    const slug = slugForContainer(app.name);
    const escaped = command.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    const serverCmd = `docker exec $(docker ps -q -f name=${slug}) sh -c "${escaped}"`;

    const { data } = await api.getClient().post(`/api/servers/${serverId}/exec`, {
      command: serverCmd,
    });

    spinner.stop();
    console.log(chalk.bold(`\n📤 ${app.name}\n`));
    console.log(data?.data?.stdout ?? '');
    if (data?.data?.stderr) {
      console.log(chalk.red(data.data.stderr));
    }
    console.log();
  } catch (error: any) {
    spinner.fail('Command failed');
    Formatters.error(error.response?.data?.error || error.message);
  }
}
