import Conf from 'conf';
import chalk from 'chalk';
import { ApiClient } from '../api/client';
import { DEFAULT_API_URL, normalizeApiUrl } from '../constants';

const API_URL_KEY = 'apiUrl';
const ASSISTANT_AUTO_EXECUTE_KEY = 'assistantAutoExecute';
/**
 * Config command: get/set api-url.
 * Default API URL is clikdeploy.com (override with env/config for local testing).
 */
function parseAssistantMode(value: string): boolean | null {
  const normalized = value.trim().toLowerCase();
  if (['on', 'auto', 'true', '1', 'yes'].includes(normalized)) return true;
  if (['off', 'confirm', 'false', '0', 'no'].includes(normalized)) return false;
  return null;
}

export async function configCommand(config: Conf, subcommand: string | undefined, value?: string) {
  if (subcommand === 'api-url' || subcommand === 'apiUrl') {
    if (value !== undefined) {
      const url = normalizeApiUrl(value);
      config.set(API_URL_KEY, url);
      console.log(chalk.green('API URL set to:'), chalk.cyan(url));
      console.log(chalk.gray('Auth is stored per URL. Run clikdeploy login if this URL is new.'));
      return;
    }
    const saved = config.get(API_URL_KEY) as string | undefined;
    const effective = ApiClient.getApiUrl(config);
    console.log(chalk.bold('API URL (effective):'), chalk.cyan(effective));
    console.log(
      chalk.bold('API URL (saved):'),
      saved ? chalk.cyan(saved) : chalk.gray(DEFAULT_API_URL + ' (default)')
    );
    console.log(chalk.gray('To change:'), chalk.cyan('clikdeploy config api-url <url>'));
    console.log(
      chalk.gray('One-off override:'),
      chalk.cyan('clikdeploy --api-url <url> <command>')
    );
    return;
  }

  if (!subcommand || subcommand === 'get') {
    const apiUrl = ApiClient.getApiUrl(config);
    const assistantAutoExecute = Boolean(config.get(ASSISTANT_AUTO_EXECUTE_KEY));
    console.log(chalk.bold('\nConfig\n'));
    console.log('  api-url:', chalk.cyan(apiUrl));
    console.log(
      '  assistant-mode:',
      assistantAutoExecute ? chalk.cyan('auto') : chalk.yellow('confirm')
    );
    console.log(chalk.gray('\nSet with: clikdeploy config api-url <url>\n'));
    console.log(chalk.gray('One-off override: clikdeploy --api-url <url> <command>\n'));
    console.log(chalk.gray('          clikdeploy config assistant-mode <auto|confirm>\n'));
    return;
  }

  if (
    subcommand === 'assistant-mode' ||
    subcommand === 'assistantMode' ||
    subcommand === 'assistant-auto-execute'
  ) {
    const apiKey = config.get('apiKey') as string | undefined;
    const api = new ApiClient(config);
    if (value === undefined) {
      if (apiKey) {
        try {
          const prefs = await api.getUserPreferences();
          const mode = prefs.assistantAutoExecute ? 'auto' : 'confirm';
          config.set(ASSISTANT_AUTO_EXECUTE_KEY, Boolean(prefs.assistantAutoExecute));
          console.log(chalk.bold('Assistant mode:'), chalk.cyan(mode));
          console.log(chalk.gray('Set with:'), chalk.cyan('clikdeploy config assistant-mode <auto|confirm>'));
          return;
        } catch {
          // Fall back to local cached mode below
        }
      }
      const localMode = Boolean(config.get(ASSISTANT_AUTO_EXECUTE_KEY)) ? 'auto' : 'confirm';
      console.log(chalk.bold('Assistant mode (local):'), chalk.cyan(localMode));
      console.log(
        chalk.gray('Tip: log in to sync this preference to your account across web/CLI/MCP.')
      );
      return;
    }

    const parsed = parseAssistantMode(value);
    if (parsed === null) {
      console.log(chalk.red('Invalid value. Use: auto | confirm'));
      return;
    }

    config.set(ASSISTANT_AUTO_EXECUTE_KEY, parsed);
    if (apiKey) {
      try {
        await api.updateUserPreferences({ assistantAutoExecute: parsed });
        console.log(
          chalk.green('Assistant mode saved:'),
          parsed ? chalk.cyan('auto') : chalk.yellow('confirm')
        );
        return;
      } catch (error) {
        console.log(
          chalk.yellow('Saved locally, but failed to sync to server:'),
          error instanceof Error ? error.message : String(error)
        );
        return;
      }
    }

    console.log(
      chalk.green('Assistant mode saved locally:'),
      parsed ? chalk.cyan('auto') : chalk.yellow('confirm')
    );
    console.log(chalk.gray('Log in to sync this preference to your account.'));
    return;
  }

  console.log(chalk.red('Unknown config key. Use: config api-url [url] | assistant-mode [auto|confirm]\n'));
}
