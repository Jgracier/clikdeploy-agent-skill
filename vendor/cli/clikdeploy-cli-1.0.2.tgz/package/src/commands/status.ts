import fs from 'fs';
import path from 'path';
import chalk from 'chalk';
import ora from 'ora';
import Conf from 'conf';
import { getApiClient, requireAuth } from '../utils/api';
import { resolveApp, showDisambiguationHint } from '../utils/app-resolver';
import { displayId } from '../utils/id-format';

import { resolveTarget } from '../utils/universal-resolver';

export async function status(config: Conf, identifier?: string) {
  requireAuth(config);
  const api = getApiClient(config);

  if (!identifier) {
    const [apps, servers, discovery] = await Promise.all([
      api.getControlPlaneApps() || [],
      api.getControlPlaneServers() || [],
      api.getDiscovery() || {},
    ]);
    console.log(JSON.stringify({
      apps,
      servers,
      discovery,
    }, null, 2));
    return;
  }

  const spinner = ora(`Loading status for ${identifier}...`).start();

  try {
    const resolved = await resolveTarget(api, identifier);
    if (!resolved) {
      spinner.fail(`Target "${identifier}" not found`);
      return;
    }

    spinner.stop();

    if (resolved.type === 'server') {
      const server = resolved.server;
      console.log(chalk.bold(`\n🖥️  Server: ${server.name}\n`));
      const statusColor = {
        CONNECTED: chalk.green,
        SCANNING: chalk.yellow,
        ERROR: chalk.red,
        DISCONNECTED: chalk.gray,
      }[server.status as string] || chalk.gray;

      console.log(`   ${chalk.gray('Status:')}     ${statusColor(server.status)}`);
      console.log(`   ${chalk.gray('IP Address:')} ${server.ipAddress}`);
      if (server.healthError) {
        console.log(`   ${chalk.gray('Error:')}      ${chalk.red(server.healthError)}`);
      }
      console.log();
      return;
    }

    // App Status (Original logic)
    const app = resolved.app;
    const deployments = await api.getAppDeployments(app.id);
    const lastDeploy = deployments[0];

    console.log(chalk.bold(`\n📦 App: ${app.name}\n`));
    const statusColor = {
      RUNNING: chalk.green,
      STOPPED: chalk.gray,
      DEPLOYING: chalk.yellow,
      ERROR: chalk.red,
    }[app.status as string] || chalk.gray;

    console.log(`   ${chalk.gray('Status:')}     ${statusColor(app.status)}`);
    if (app.status === 'ERROR' && app.healthError) {
      console.log(`   ${chalk.gray('Error:')}      ${chalk.red(app.healthError)}`);
    }
    console.log(`   ${chalk.gray('Server:')}     ${resolved.server?.name || 'Unknown'}`);

    if (app.domain) {
      console.log(`   ${chalk.gray('URL:')}        ${chalk.cyan(`https://${app.domain}`)}`);
    }

    if (lastDeploy) {
      console.log();
      console.log(chalk.bold('   Last Deployment'));
      console.log(`   ${chalk.gray('ID:')}         ${displayId(lastDeploy.id)}`);
      console.log(`   ${chalk.gray('Status:')}     ${lastDeploy.status}`);
      console.log(`   ${chalk.gray('Time:')}       ${new Date(lastDeploy.createdAt).toLocaleString()}`);
    }
    console.log();
  } catch (error: any) {
    spinner.fail('Failed to get status');
    console.log(chalk.red(error.response?.data?.error || error.message));
  }
}

export async function logs(config: Conf, appIdentifier?: string, options: any = {}) {
  requireAuth(config);

  const api = getApiClient(config);
  const spinner = ora('Loading logs...').start();

  try {
    const appId = await resolveAppId(api, appIdentifier);
    if (!appId) {
      spinner.fail('App not found');
      if (appIdentifier) {
        const allApps = await api.getApps();
        showDisambiguationHint(appIdentifier, allApps);
      }
      return;
    }

    spinner.stop();

    if (options.follow) {
      await streamLogs(api, appId);
    } else {
      await fetchLogs(api, appId, parseInt(options.lines) || 100);
    }
  } catch (error: any) {
    spinner.fail('Failed to get logs');
    console.log(chalk.red(error.response?.data?.error || error.message));
  }
}

async function resolveAppId(api: import('../api/client').ApiClient, identifier?: string): Promise<string | null> {
  const configPath = path.join(process.cwd(), 'clikdeploy.json');
  let projectName: string | undefined;
  if (fs.existsSync(configPath)) {
    const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    projectName = config.name;
  }

  const name = identifier || projectName;
  if (!name) {
    console.log(chalk.yellow('No app specified'));
    console.log(chalk.gray('Run from a project directory or specify app name'));
    console.log(chalk.gray('Example: clikdeploy status n8n'));
    console.log(chalk.gray('Example: clikdeploy status gcp-server n8n'));
    return null;
  }

  // Use the new resolver for server-filtered resolution
  const resolved = await resolveApp(api, name);
  if (resolved) {
    return resolved.app.id;
  }

  // Fallback: try partial ID match (for backwards compatibility)
  if (name.length >= 8) {
    const apps = await api.getApps();
    const app = apps.find((a: any) => a.id && String(a.id).startsWith(name));
    if (app) {
      return app.id;
    }
  }

  return null;
}

async function fetchLogs(api: import('../api/client').ApiClient, appId: string, lines: number) {
  const { data } = await api.getClient().get(`/api/apps/${appId}/logs`, {
    params: { limit: lines },
  });

  const logs = Array.isArray(data?.data) ? data.data : [];
  if (logs.length === 0) {
    console.log(chalk.gray('No logs available'));
    return;
  }

  console.log(chalk.bold('\n📋 Application Logs\n'));

  for (const log of logs) {
    const time = new Date(log.timestamp).toLocaleTimeString();
    const levelColor = {
      DEBUG: chalk.gray,
      INFO: chalk.blue,
      WARN: chalk.yellow,
      ERROR: chalk.red,
      FATAL: chalk.bgRed.white,
    }[log.level] || chalk.white;

    console.log(`${chalk.gray(time)} ${levelColor(log.level.padEnd(5))} ${log.message}`);
  }
}

export async function streamLogs(api: import('../api/client').ApiClient, appId: string) {
  console.log(chalk.bold('\n📋 Streaming Logs') + chalk.gray(' (Ctrl+C to stop)\n'));

  let lastTimestamp = new Date().toISOString();
  let inFlight = false;

  const poll = async () => {
    if (inFlight) return;
    inFlight = true;
    try {
      const res = await api.getClient().get(`/api/apps/${appId}/logs`, {
        params: { since: lastTimestamp, limit: 50 },
      });
      const logs = Array.isArray(res?.data?.data) ? res.data.data : [];
      for (const log of logs) {
        const time = new Date(log.timestamp).toLocaleTimeString();
        const levelColor = {
          DEBUG: chalk.gray,
          INFO: chalk.blue,
          WARN: chalk.yellow,
          ERROR: chalk.red,
          FATAL: chalk.bgRed.white,
        }[log.level] || chalk.white;

        console.log(`${chalk.gray(time)} ${levelColor(log.level.padEnd(5))} ${log.message}`);
        lastTimestamp = log.timestamp;
      }
    } catch (error) {
      // Silently retry on errors
    } finally {
      inFlight = false;
    }
  };

  // Poll every 2 seconds
  const interval = setInterval(poll, 2000);
  poll(); // Initial fetch

  // Handle Ctrl+C
  process.on('SIGINT', () => {
    clearInterval(interval);
    console.log(chalk.gray('\n\nStopped streaming.'));
    process.exit(0);
  });

  // Keep process alive
  await new Promise(() => { });
}
