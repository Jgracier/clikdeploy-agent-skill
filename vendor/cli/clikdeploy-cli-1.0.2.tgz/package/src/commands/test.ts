import fs from 'fs';
import path from 'path';
import chalk from 'chalk';
import ora from 'ora';
import Conf from 'conf';
import { spawnSync } from 'child_process';
import { getApiClient, requireAuth } from '../utils/api';

type RuntimeMode = 'all' | 'docker';

interface TestOptions {
  scale?: string | number;
  concurrency?: string | number;
  seed?: string | number;
  variants?: string | number;
  runtime?: RuntimeMode;
  failures?: string;
  strict?: boolean;
  verbose?: boolean;
  json?: boolean;
  output?: string;
}

function parseNumber(value: string | number | undefined, fallback: number, min: number, max: number) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, Math.floor(parsed)));
}

function parseFailures(raw: string | undefined): string[] | undefined {
  if (!raw) return undefined;
  const values = raw
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  return values.length > 0 ? values : undefined;
}

function resolveRuntimes(mode: RuntimeMode | undefined): Array<'docker'> {
  if (mode === 'docker') return ['docker'];
  return ['docker'];
}

async function assertAdmin(config: Conf): Promise<void> {
  const api = getApiClient(config);
  // Server-side admin check is source of truth (role or ADMIN_EMAILS allowlist).
  await api.getClient().get('/api/admin/overview');
}

const LOCAL_SIM_ALLOWED_ADMIN_EMAILS = new Set(['gracierdigital@gmail.com']);

async function assertLocalSimulationAdmin(config: Conf): Promise<void> {
  const api = getApiClient(config);
  try {
    // Prefer server-side admin authorization when available.
    await api.getClient().get('/api/admin/overview');
    return;
  } catch {
    // Fallback to explicit CLI-authenticated admin email allowlist.
    const user = await api.getCurrentUser();
    const email = String(user?.email || '')
      .trim()
      .toLowerCase();
    if (LOCAL_SIM_ALLOWED_ADMIN_EMAILS.has(email)) return;
    throw new Error('Admin access required for local simulation commands');
  }
}

export async function runTestingFramework(
  config: Conf,
  mode: 'run' | 'recovery',
  options: TestOptions
) {
  requireAuth(config);

  const scale = parseNumber(options.scale, 1000, 1, 10000);
  const concurrency = parseNumber(options.concurrency, 50, 1, 500);
  const seed =
    options.seed === undefined ? Date.now() : parseNumber(options.seed, Date.now(), 1, 2147483647);
  const appVariants = parseNumber(options.variants, Math.min(500, scale), 1, 10000);
  const failureTypes = parseFailures(options.failures);
  const runtimes = resolveRuntimes(options.runtime);

  const spinner = ora('Verifying admin access...').start();
  try {
    await assertAdmin(config);
    spinner.text = 'Running mass-scale platform simulation...';

    const api = getApiClient(config, 180_000);
    const { data } = await api.getClient().post('/api/admin/testing/simulate', {
      focus: mode === 'recovery' ? 'recovery' : 'platform',
      scale,
      concurrency,
      seed,
      appVariants,
      verbose: options.verbose === true,
      runtimes,
      failureTypes,
      strict: options.strict === true,
    });

    spinner.stop();

    if (options.json) {
      console.log(JSON.stringify(data, null, 2));
    } else {
      const summary = data?.summary || {};
      console.log(chalk.bold('\n🧪 ClikDeploy Test Framework (Admin)\n'));
      console.log(chalk.gray(`Focus:       ${data?.focus || mode}`));
      console.log(chalk.gray(`Scale:       ${summary.total ?? 0}`));
      console.log(chalk.gray(`Variants:    ${summary.appVariants ?? appVariants}`));
      console.log(chalk.gray(`Passed:      ${summary.passed ?? 0}`));
      console.log(chalk.gray(`Failed:      ${summary.failed ?? 0}`));
      console.log(chalk.gray(`Recovered:   ${summary.recovered ?? 0}`));
      console.log(chalk.gray(`With fixes:  ${summary.withFixes ?? 0}`));
      console.log(chalk.gray(`Avg ms:      ${summary.avgDurationMs ?? 0}`));
      console.log(chalk.gray(`Seed:        ${data?.seed ?? seed}`));
      console.log();

      const byFailure = summary.byFailure || {};
      const failureKeys = Object.keys(byFailure);
      if (failureKeys.length > 0) {
        console.log(chalk.bold('By Failure Type'));
        for (const key of failureKeys) {
          const v = byFailure[key];
          console.log(
            `${chalk.cyan(key.padEnd(24))} total=${String(v.total).padEnd(6)} pass=${String(v.passed).padEnd(6)} fail=${v.failed}`
          );
        }
        console.log();
      }

      const samples = data?.sampleFailures || [];
      if (samples.length > 0) {
        console.log(chalk.bold('Sample Failures'));
        for (const s of samples.slice(0, 15)) {
          console.log(
            `${chalk.red('x')} ${s.id} ${chalk.gray(`[${s.runtime}/${s.failureType}]`)} ${s.message}`
          );
        }
        console.log();
      }
    }

    if (options.output) {
      const outPath = path.resolve(options.output);
      fs.mkdirSync(path.dirname(outPath), { recursive: true });
      fs.writeFileSync(outPath, JSON.stringify(data, null, 2));
      console.log(chalk.green(`Saved simulation report: ${outPath}`));
    }

    if (data?.success === false || (data?.summary?.failed ?? 0) > 0) {
      process.exitCode = 1;
    }
  } catch (error: any) {
    spinner.fail('Testing framework failed');
    console.log(chalk.red(error?.response?.data?.error || error.message || 'Unknown error'));
    if (error?.response?.status === 403) {
      console.log(
        chalk.gray('This command is admin-only. Ensure your account role is ADMIN and allowed by ADMIN_EMAILS.')
      );
    }
    process.exitCode = 1;
  }
}

function resolveRepoRoot(): string {
  const envPath = process.env.CLIKDEPLOY_PLATFORM_PATH;
  if (envPath && fs.existsSync(envPath)) {
    const resolved = path.resolve(envPath);
    return path.dirname(resolved);
  }

  const candidates = [process.cwd(), path.resolve(__dirname, '../../..')];
  for (const start of candidates) {
    let current = path.resolve(start);
    while (true) {
      const webPkg = path.join(current, 'apps', 'web', 'package.json');
      if (fs.existsSync(webPkg)) return current;
      const parent = path.dirname(current);
      if (parent === current) break;
      current = parent;
    }
  }
  return path.resolve(__dirname, '../../..');
}

export async function runDockerSimulationSuite(_config: Conf, options: TestOptions = {}) {
  const spinner = ora('Running docker simulation suite locally...').start();
  try {
    requireAuth(_config);
    await assertLocalSimulationAdmin(_config);

    const repoRoot = resolveRepoRoot();
    const webDir = path.join(repoRoot, 'apps', 'web');
    const webPkg = path.join(webDir, 'package.json');
    if (!fs.existsSync(webPkg)) {
      throw new Error(
        `Could not find apps/web/package.json (repoRoot=${repoRoot}). Run from repo root or set CLIKDEPLOY_PLATFORM_PATH=.../apps/web`
      );
    }

    const simArgs = ['-C', webDir, 'exec', 'tsx', 'scripts/docker-simulate.ts'];
    if (options.scale !== undefined) simArgs.push('--scale', String(options.scale));
    if (options.concurrency !== undefined) simArgs.push('--concurrency', String(options.concurrency));
    if (options.seed !== undefined) simArgs.push('--seed', String(options.seed));
    if (options.variants !== undefined) simArgs.push('--variants', String(options.variants));
    if (options.failures) simArgs.push('--failures', String(options.failures));
    if (options.strict === true) simArgs.push('--strict');
    if (options.verbose === true) simArgs.push('--verbose');
    if (options.json === true) simArgs.push('--json');
    if (options.output) simArgs.push('--output', String(options.output));

    spinner.stop();
    const simResult = spawnSync('pnpm', simArgs, {
      cwd: repoRoot,
      stdio: 'inherit',
      env: { ...process.env },
    });
    if (simResult.status !== 0) {
      process.exitCode = simResult.status || 1;
      return;
    }

    const testArgs = [
      '-C',
      webDir,
      'exec',
      'vitest',
      'run',
      'src/domains/deployment/docker/__tests__/docker-run-command.test.ts',
      'src/domains/deployment/docker/__tests__/docker-cache.test.ts',
      'src/domains/deployment/core/__tests__/pre-flight-detection.test.ts',
      'src/domains/deployment/routing/__tests__/port-allocator-static.test.ts',
      'src/domains/deployment/routing/__tests__/port-allocator.test.ts',
      'src/domains/deployment/routing/__tests__/port-detection.test.ts',
      'src/domains/deployment/cleanup/__tests__/cleanup-docker-resources.test.ts',
      'src/domains/deployment/detection/__tests__/learned-dependency-inference.test.ts',
    ];
    const testResult = spawnSync('pnpm', testArgs, {
      cwd: repoRoot,
      stdio: 'inherit',
      env: { ...process.env },
    });
    if (testResult.status !== 0) {
      process.exitCode = testResult.status || 1;
      return;
    }

    console.log(chalk.green('\n✅ Docker simulation suite passed\n'));
  } catch (error: any) {
    spinner.fail('Docker simulation suite failed');
    console.log(chalk.red(error?.message || 'Unknown error'));
    process.exitCode = 1;
  }
}
