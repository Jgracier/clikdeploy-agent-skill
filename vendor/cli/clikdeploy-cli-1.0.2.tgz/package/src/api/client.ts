import axios, { AxiosInstance } from 'axios';
import Conf from 'conf';
import {
  CLI_API_URL_OVERRIDE_ENV,
  CONFIG_KEYS,
  DEFAULT_API_URL,
  normalizeApiUrl,
} from '../constants';
import { readCanonicalAuth } from '../utils/local-auth';

/** Auth per API URL so localhost and clikdeploy.com can each have a session. */
type AuthByUrl = Record<string, { apiKey: string; user: unknown }>;

function toSlug(value: string): string {
  return String(value || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function isLearnedImageMarketplaceId(id: string): boolean {
  return /^image-[a-z0-9-]+$/i.test(String(id || '').trim());
}

function resolveMarketplaceSelection(
  requestedRaw: string,
  marketplaceApps: any[]
): { marketplaceId: string; appName: string; learnedOnlyMatch: boolean } {
  const requested = String(requestedRaw || '').trim();
  const requestedLower = requested.toLowerCase();
  const requestedSlug = toSlug(requested);
  const apps = Array.isArray(marketplaceApps) ? marketplaceApps : [];

  const exactId = apps.find((app: any) => String(app?.id || '').trim().toLowerCase() === requestedLower);
  if (exactId) {
    return {
      marketplaceId: String(exactId.id || '').trim() || requestedSlug || requestedLower,
      appName: String(exactId.name || '').trim() || requested,
      learnedOnlyMatch: false,
    };
  }

  const exactName = apps.find((app: any) => String(app?.name || '').trim().toLowerCase() === requestedLower);
  if (exactName) {
    const id = String(exactName?.id || '').trim();
    const safeId = isLearnedImageMarketplaceId(id) ? requestedSlug || requestedLower : id;
    return {
      marketplaceId: safeId || requestedSlug || requestedLower,
      appName: String(exactName.name || '').trim() || requested,
      learnedOnlyMatch: isLearnedImageMarketplaceId(id),
    };
  }

  const slugMatched = apps.filter((app: any) => {
    const id = String(app?.id || '').trim();
    const appName = String(app?.name || '').trim();
    return toSlug(id) === requestedSlug || toSlug(appName) === requestedSlug;
  });

  const preferred =
    slugMatched.find((app: any) => !isLearnedImageMarketplaceId(String(app?.id || ''))) ||
    slugMatched[0];
  if (preferred) {
    const preferredId = String(preferred?.id || '').trim();
    const learnedOnlyMatch = isLearnedImageMarketplaceId(preferredId);
    return {
      marketplaceId:
        (learnedOnlyMatch ? requestedSlug || requestedLower : preferredId) ||
        requestedSlug ||
        requestedLower,
      appName: String(preferred?.name || '').trim() || requested,
      learnedOnlyMatch,
    };
  }

  return {
    marketplaceId: requestedSlug || requestedLower,
    appName: requested,
    learnedOnlyMatch: false,
  };
}

export function getApiKeyForUrl(config: Conf, url: string): string | undefined {
  const normalized = normalizeApiUrl(url);
  const canonical = readCanonicalAuth();
  if (canonical?.apiKey) {
    const canonicalUrl = normalizeApiUrl(String(canonical.apiUrl || '').trim());
    if (!canonicalUrl || canonicalUrl === normalized) return canonical.apiKey;
  }
  const authByUrl = config.get(CONFIG_KEYS.AUTH_BY_URL) as AuthByUrl | undefined;
  const key = authByUrl?.[normalized]?.apiKey;
  if (key) return key;
  return config.get(CONFIG_KEYS.API_KEY) as string | undefined;
}

/**
 * Comprehensive API Client
 * Centralized API communication for all ClikDeploy operations
 */
export class ApiClient {
  private client: AxiosInstance;
  private config: Conf;
  public baseUrl: string;

  constructor(config: Conf, timeout?: number) {
    this.config = config;
    this.baseUrl = ApiClient.getApiUrl(config);
    this.baseUrl = normalizeApiUrl(this.baseUrl);
    const apiKey = getApiKeyForUrl(config, this.baseUrl);

    this.client = axios.create({
      baseURL: this.baseUrl,
      headers: {
        'Authorization': apiKey ? `Bearer ${apiKey}` : '',
        'Content-Type': 'application/json',
        'User-Agent': 'ClikDeploy-CLI/1.0.0',
      },
      withCredentials: true, // Include cookies for session auth
      timeout: timeout || 30000, // Default 30s, but allow override for long operations
    });

    // Ensure API key is sent on every request (use key for current api URL)
    const configRef = config;
    this.client.interceptors.request.use((reqConfig) => {
      const auth = reqConfig.headers?.['Authorization'];
      if (auth) return reqConfig;
      const key = getApiKeyForUrl(
        configRef,
        ApiClient.getApiUrl(configRef)
      );
      if (key) {
        reqConfig.headers.Authorization = `Bearer ${key}`;
      }
      return reqConfig;
    });
  }

  /** Expose axios instance for requests that need it; Bearer is set by interceptor */
  getClient(): AxiosInstance {
    return this.client;
  }

  async verifyToken(token: string): Promise<any> {
    const { data } = await this.client.get('/api/auth/me', {
      headers: { 'Authorization': `Bearer ${token}` },
    });
    return data.user;
  }

  async verifyApiKey(apiKey: string): Promise<any> {
    const { data } = await this.client.get('/api/auth/me', {
      headers: { 'Authorization': `Bearer ${apiKey}` },
    });
    return data.user;
  }

  async getCurrentUser(): Promise<any> {
    const { data } = await this.client.get('/api/auth/me');
    return data?.user ?? data?.data?.user ?? data?.data ?? data;
  }

  async getServers(): Promise<any[]> {
    const { data } = await this.client.get('/api/servers');
    return data.data;
  }

  async getApps(): Promise<any[]> {
    const { data } = await this.client.get('/api/apps');
    return data.data;
  }

  async getApp(appId: string): Promise<any> {
    const { data } = await this.client.get(`/api/apps/${appId}`);
    return data.data;
  }

  /** GET /api/apps/:id/logs - Raw container (Docker) logs from server */
  async getAppContainerLogs(appId: string, limit = 500): Promise<string> {
    try {
      const { data } = await this.client.get(`/api/apps/${appId}/logs`, {
        params: { limit },
      });
      const raw = data?.data ?? data;
      return typeof raw === 'string' ? raw : '';
    } catch {
      return '';
    }
  }

  async getDeployment(deploymentId: string): Promise<any> {
    const { data } = await this.client.get(`/api/deployments/${deploymentId}`);
    return data.data;
  }

  /** GET /api/deployments/:id/logs - Full deployment logs from server (build, pull, health, etc.) */
  async getDeploymentLogs(deploymentId: string): Promise<{
    logs: Array<{ timestamp?: string; level?: string; message?: string }>;
    status?: string;
    error?: string;
  }> {
    const { data } = await this.client.get(`/api/deployments/${deploymentId}/logs`);
    const payload = data.data ?? data;
    return {
      logs: Array.isArray(payload.logs) ? payload.logs : [],
      status: payload.status,
      error: payload.error,
    };
  }

  async getAppDeployments(appId: string): Promise<any[]> {
    const { data } = await this.client.get(`/api/apps/${appId}/deployments`);
    return data.data;
  }

  async deployMarketplaceApp(name: string, serverId: string): Promise<any> {
    try {
      const marketplaceApps = await this.getMarketplaceApps();
      const { marketplaceId, appName, learnedOnlyMatch } = resolveMarketplaceSelection(
        name,
        marketplaceApps
      );
      if (learnedOnlyMatch) {
        throw new Error(
          `Marketplace entry "${name}" is learned-only and not deployable by catalog id. Use a catalog app name or deploy a custom Docker image instead.`
        );
      }

      const { data } = await this.client.post('/api/apps', {
        name: appName,
        marketplaceAppId: marketplaceId,
        serverId,
      });
      return data.data?.app || data.data;
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || error.message || 'Unknown error';
      const errorDetails = error.response?.data;
      throw new Error(`Deployment failed: ${errorMessage}${errorDetails ? ` (${JSON.stringify(errorDetails)})` : ''}`);
    }
  }

  async deleteApp(appId: string): Promise<any> {
    const { data } = await this.client.delete(`/api/gate/apps/${appId}`);
    return data;
  }

  /** POST /api/apps - create app (for deploy from repo) */
  async createApp(body: Record<string, unknown>): Promise<any> {
    const { data } = await this.client.post('/api/apps', body);
    return data.data?.app ?? data.data;
  }

  /** POST /api/apps/:id/deploy - start deployment */
  async deployApp(appId: string, body: Record<string, unknown>): Promise<any> {
    const { data } = await this.client.post(`/api/apps/${appId}/deploy`, body);
    return data.data;
  }

  /** POST /api/servers - create server */
  async createServer(body: Record<string, unknown>): Promise<any> {
    const { data } = await this.client.post('/api/servers', body);
    return data.data;
  }

  /** POST /api/agents/pairing-code - create pairing code for self host agent (requires auth) */
  async createAgentPairingCode(name = 'Self Host'): Promise<{
    agentId: string;
    pairingCode: string;
    expiresAt: string;
  }> {
    const { data } = await this.client.post('/api/agents/pairing-code', { name });
    if (!data?.success || !data?.data) throw new Error(data?.error || 'Failed to create pairing code');
    return data.data;
  }

  /**
   * POST /api/agents/provision
   * Authenticated CLI path: provisions an agent + server + token in one shot.
   * No pairing code needed — the CLI already carries user credentials.
   */
  async provisionAgent(
    name = 'Self Host',
    options: { waitForHealthy?: boolean; waitTimeoutMs?: number } = {}
  ): Promise<{ agentId: string; serverId: string; token: string; shouldUpdateAgentCode: boolean }> {
    const { data } = await this.client.post('/api/gate/connect', { name, ...options });
    if (!data?.success || !data?.data) throw new Error(data?.error || 'Failed to provision agent');
    return {
      agentId: data.data.agentId,
      serverId: data.data.serverId,
      token: data.data.agentToken,
      shouldUpdateAgentCode: Boolean(data.data.shouldUpdateAgentCode),
    };
  }

  async getServer(serverId: string): Promise<any> {
    const { data } = await this.client.get(`/api/servers/${serverId}`);
    return data.data;
  }

  async deleteServer(serverId: string): Promise<any> {
    const { data } = await this.client.delete(`/api/gate/servers/${serverId}`);
    return data;
  }

  async getControlPlaneApps(): Promise<any[]> {
    const { data } = await this.client.get('/api/gate/apps');
    return data?.data?.apps || [];
  }

  async getControlPlaneServers(): Promise<any[]> {
    const { data } = await this.client.get('/api/gate/servers');
    return data?.data?.servers || [];
  }

  async getWorkerStatus(): Promise<any> {
    const { data } = await this.client.get('/api/workers/status');
    return data;
  }

  async clearWorkerQueue(includeActive = false): Promise<any> {
    const url = includeActive ? '/api/workers/queue/clear?active=1' : '/api/workers/queue/clear';
    const { data } = await this.client.post(url, {});
    return data;
  }

  async getMarketplaceApps(): Promise<any[]> {
    const { data } = await this.client.get('/api/marketplace');
    return data.data;
  }

  /** GET /api/servers/oauth?provider= - list GCP instances; always sends API key */
  async getOAuthInstances(provider: string): Promise<any> {
    const key = this.config.get('apiKey') as string;
    const { data } = await this.client.get(`/api/servers/oauth?provider=${encodeURIComponent(provider)}`, {
      headers: key ? { Authorization: `Bearer ${key}` } : {},
    });
    return data;
  }

  async loginWithEmail(email: string, password: string): Promise<{ apiKey: string }> {
    const { data } = await this.client.post('/api/auth/cli/login', {
      email,
      password,
    });
    return data.data;
  }

  async signup(email: string, password: string, name?: string): Promise<{ apiKey: string }> {
    const { data } = await this.client.post('/api/auth/cli/signup', {
      email,
      password,
      name,
    });
    return data.data;
  }

  async getUserPreferences(): Promise<{ keepImageVersions?: boolean; assistantAutoExecute?: boolean }> {
    const { data } = await this.client.get('/api/user/preferences');
    return data;
  }

  async updateUserPreferences(
    preferences: Partial<{ keepImageVersions: boolean; assistantAutoExecute: boolean }>
  ): Promise<any> {
    const { data } = await this.client.put('/api/user/preferences', preferences);
    return data;
  }

  /** POST /api/gate/auth/device/init — start device/agent OAuth flow via Gate. */
  async deviceFlowInit(provider: 'google' | 'github'): Promise<{ flowId: string; authUrl: string }> {
    const { data } = await this.client.post('/api/gate/auth/device/init', {
      provider,
    });
    const payload = data.data ?? data;
    return {
      flowId: payload.flowId || '',
      authUrl: payload.authUrl || '',
    };
  }

  /** POST /api/gate/auth/device/exchange — trade one-time code for apiKey + optional server provision. */
  async deviceFlowExchange(
    code: string
  ): Promise<{ apiKey: string; auth_method: string; serverId?: string; agentId?: string; agentToken?: string }> {
    const { data } = await this.client.post('/api/gate/auth/device/exchange', {
      code,
    });
    const payload = data.data ?? data;
    return {
      apiKey: payload.apiKey,
      auth_method: payload.auth_method,
      serverId: payload.serverId,
      agentId: payload.agentId,
      agentToken: payload.agentToken,
    };
  }

  /** Event-driven wait for self-host readiness using short-lived agent token. */
  async waitForSelfHostReadyByAgentToken(
    agentToken: string
  ): Promise<{ connected: boolean; serverStatus: string }> {
    const { data } = await this.client.get('/api/agents/install-report?wait=1', {
      headers: { Authorization: `Bearer ${agentToken}` },
      timeout: 190000,
    });
    const payload = data?.data ?? {};
    const connected = Boolean(payload?.online) && Boolean(payload?.confirmed);
    const serverStatus = String(payload?.serverStatus || (connected ? 'CONNECTED' : 'CONNECTING'));
    return { connected, serverStatus };
  }

  /** GET /api/gate/discovery - list platform capabilities and schemas. */
  async getDiscovery(): Promise<any> {
    const { data } = await this.client.get('/api/gate/discovery');
    return data?.discovery;
  }

  // Utility methods (static)
  static getApiUrl(config: Conf): string {
    const url =
      process.env[CLI_API_URL_OVERRIDE_ENV] ||
      (config.get(CONFIG_KEYS.API_URL) as string) ||
      process.env.CLICKDEPLOY_API_URL ||
      DEFAULT_API_URL;
    return normalizeApiUrl(url);
  }

  static getApiKeyForUrl(config: Conf, url?: string): string | undefined {
    return getApiKeyForUrl(config, url ?? ApiClient.getApiUrl(config));
  }

  static requireAuth(config: Conf): void {
    const apiUrl = ApiClient.getApiUrl(config);
    const apiKey = getApiKeyForUrl(config, apiUrl);

    if (!apiKey) {
      console.log('\n✗ Not logged in for this API URL');
      console.log('  Current API URL:', apiUrl);
      console.log('  Run clikdeploy login first (or switch: clikdeploy config api-url <url>)');
      process.exit(1);
    }
  }

  static setApiUrl(config: Conf, url: string): void {
    config.set('apiUrl', url);
  }
}
