#!/usr/bin/env node

/**
 * ClikDeploy CLI
 * Philosophy: Dead simple. Autonomous by default. No prompts, no confirmations.
 * 
 * Commands:
 *   login              - Authenticate with ClikDeploy
 *   deploy [target]    - Universal Deploy (Folder, GitHub URL, Image, or App Name)
 *   apps list/delete   - Manage your deployed applications
 *   servers list/add   - Manage your server infrastructure
 */

import { Command } from 'commander';
import chalk from 'chalk';
import Conf from 'conf';
import { login, loginUrl, logout, whoami, signup } from './commands/auth';
import { listNotifications, clearNotifications } from './commands/notifications';
import { init } from './commands/init';
import { deploy } from './commands/deploy';
import { status, logs } from './commands/status';
import { watchDeployments } from './commands/watch';
import { listApps, listServers, showApp, showServersStatus } from './commands/list';
import { deployMarketplace, deleteApp, listMarketplace, checkStatus } from './commands/marketplace';
import { inspectServer, execOnServer, cleanupServer, addServer, deleteServer, getServerKey, reconnectServer, discoverServer, runProvision, testServerLifecycle, testServerAppLifecycle } from './commands/server';
import { listProviders, listMethods, connectOAuth, connectAPI, connectHome, wiringTest, runConnect } from './commands/server-connect';
import { deleteAppCommand, restartApp, deployApp, updateDomain, toggleSSL, setEnvVar, listEnvVars, viewContainerLogs, execInApp } from './commands/app';
import { transferAppCommand } from './commands/app-transfer';
import { openAppTerminal } from './commands/terminal';
import { deployDockerImage, listDockerImages } from './commands/docker';
import { deployFromUrl, deployFromUrlBatch } from './commands/github';
import { workerStatus, workerStart, workerRestart, workerLogs, workerClear } from './commands/worker';
import { configCommand } from './commands/config';
import { runTestingFramework, runDockerSimulationSuite } from './commands/test';
import { restart, stop, start, deleteCommand } from './commands/ops';
import { CLI_API_URL_OVERRIDE_ENV, normalizeApiUrl } from './constants';

const config = new Conf({ projectName: 'clikdeploy' });
const program = new Command();

// ASCII Art Banner
const banner = `
${chalk.cyan('╔═══════════════════════════════════════╗')}
${chalk.cyan('║')}  ${chalk.bold.white('⚡ ClikDeploy CLI')}               ${chalk.cyan('║')}
${chalk.cyan('║')}  ${chalk.gray('Deploy First, Configure Later')}      ${chalk.cyan('║')}
${chalk.cyan('╚═══════════════════════════════════════╝')}
`;

program
  .name('clikdeploy')
  .description('Deploy apps with one command - autonomous by default, simple by design')
  .version('1.0.0')
  .option('--api-url <url>', 'Use API URL for this command only (does not save config)')
  .hook('preAction', () => {
    // Show banner on first use
    if (!config.get('seenBanner')) {
      console.log(banner);
      config.set('seenBanner', true);
    }

    const runtimeApiUrl = program.opts().apiUrl as string | undefined;
    if (runtimeApiUrl) {
      process.env[CLI_API_URL_OVERRIDE_ENV] = normalizeApiUrl(runtimeApiUrl);
    } else {
      delete process.env[CLI_API_URL_OVERRIDE_ENV];
    }
  });

// Auth commands
program
  .command('login')
  .description('Authenticate with ClikDeploy')
  .option('--google', 'Use Google OAuth')
  .option('--github', 'Use GitHub OAuth')
  .option('--return-url', 'Print auth URL instead of opening browser (device flow for agents/skills)')
  .option('--exchange <code\>', 'Exchange one-time code for API key')
  .action((options) => login(config, options));

program
  .command('login-url')
  .description('Return OAuth URL JSON for Google or GitHub (no browser launch)')
  .option('--google', 'Use Google OAuth (default)')
  .option('--github', 'Use GitHub OAuth')
  .action((options) => loginUrl(config, options));

program
  .command('signup')
  .description('Create a new account')
  .action(() => signup(config));

program
  .command('logout')
  .description('Log out of ClikDeploy')
  .action(() => logout(config));

program
  .command('whoami')
  .description('Show current authenticated user')
  .option('--json', 'Output results as JSON')
  .action((options) => whoami(config, options));

program
  .command('config [key] [value]')
  .description(
    'Get or set config (e.g. config api-url https://clikdeploy.com, config assistant-mode auto)'
  )
  .action((key, value) => configCommand(config, key, value));

// Init command
program
  .command('init')
  .description('Initialize a new project in current directory')
  .action(() => init(config));

// Deploy command (the star of the show)
program
  .command('deploy [appName]')
  .description('Deploy from GitHub URL, Docker image, or Docker Hub app-name lookup (or current directory if no name given)')
  .option('-s, --server <id>', 'Deploy to specific server')
  .option('-b, --branch <branch>', 'Deploy specific branch')
  .option('-m, --message <msg>', 'Deployment message')
  .option('--no-wait', 'Don\'t wait for deployment to complete')
  .action((appName, options) => deploy(config, appName, options));

program
  .command('list')
  .description('Return a structured JSON list of all apps and servers')
  .action(() => status(config));

// Status commands
program
  .command('status')
  .description('Check status of an app or server')
  .argument('[target]', 'App or server name/ID')
  .action((target) => status(config, target));

program
  .command('logs')
  .description('View app logs')
  .argument('[app]', 'App name or ID')
  .option('-f, --follow', 'Follow log output')
  .option('-n, --lines <n>', 'Number of lines to show', '100')
  .action((app, options) => logs(config, app, options));

program
  .command('restart')
  .description('Restart an app')
  .argument('<app>', 'App name or ID')
  .action((app) => restart(config, app));

program
  .command('stop')
  .description('Stop an app')
  .argument('<app>', 'App name or ID')
  .action((app) => stop(config, app));

program
  .command('start')
  .description('Start an app')
  .argument('<app>', 'App name or ID')
  .action((app) => start(config, app));

program
  .command('delete')
  .description('Delete an app or server')
  .argument('<target>', 'Name or ID to delete')
  .option('--yes', 'Skip confirmation')
  .action((target, options) => deleteCommand(config, target, options));

program
  .command('connect')
  .description('Connect a new server or device (returns available methods as JSON by default)')
  .option('-i, --interactive', 'Run the interactive connection wizard')
  .action((options) => runConnect(config, options));

program
  .command('watch')
  .description('Watch deployments in real-time')
  .option('-i, --interval <ms>', 'Refresh interval in milliseconds', '3000')
  .option('-f, --filter <status>', 'Filter by status (deploying, error, running)')
  .action((options) => watchDeployments(config, {
    interval: options.interval ? parseInt(options.interval) : undefined,
    filter: options.filter
  }));

// Apps commands - simplified, autonomous by default
program
  .command('apps [subcommand] [args...]')
  .description('Manage apps (list, show <app>, redeploy <app>, clone <app> <server>, move <app> <server>, delete <apps...>, restart <app>, logs <apps...>, exec <app> <command>, terminal <app>, domain <app> <domain>, ssl <app>, env <app> [key] [value])')
  .option('--confirm', 'Require confirmation for destructive operations')
  .option('--all', 'Delete all apps (use with delete subcommand)')
  .option('--no-wait', 'Do not wait for deployment to complete (for redeploy command)')
  .option('-n, --lines <n>', 'Number of log lines to show (for logs command)', '100')
  .option('-f, --follow', 'Follow log output (for logs command)')
  .option('--debug', 'Log each terminal WS message (for terminal command)')
  .action(async (...cmdArgs: any[]) => {
    const options = (cmdArgs[cmdArgs.length - 1] ?? {}) as any;
    const subcommand = cmdArgs[0] as string | undefined;
    const positionalArgs: string[] = cmdArgs
      .slice(1, -1)
      .flatMap((value) => (Array.isArray(value) ? value : [value]))
      .filter((value) => typeof value === 'string' && value.trim().length > 0)
      .map((value) => String(value));
    const joinedIdentifier = positionalArgs.join(' ').trim();

    if (subcommand === 'show' && joinedIdentifier) {
      await showApp(config, joinedIdentifier);
    } else if (subcommand === 'delete') {
      const deleteAll = options?.all === true;
      const appsToDelete = positionalArgs;
      await deleteAppCommand(config, appsToDelete, options?.confirm || false, deleteAll);
    } else if (subcommand === 'restart' && joinedIdentifier) {
      await restartApp(config, joinedIdentifier);
    } else if (subcommand === 'redeploy' && positionalArgs[0]) {
      const appsToRedeploy = positionalArgs;
      await deployApp(config, appsToRedeploy, { wait: options?.wait !== false });
    } else if (subcommand === 'clone' && positionalArgs[0] && positionalArgs[1]) {
      await transferAppCommand(config, positionalArgs[0], positionalArgs[1], 'clone');
    } else if (subcommand === 'move' && positionalArgs[0] && positionalArgs[1]) {
      await transferAppCommand(config, positionalArgs[0], positionalArgs[1], 'move');
    } else if (subcommand === 'logs') {
      const appsToView = positionalArgs;
      await viewContainerLogs(config, appsToView, {
        lines: parseInt(options?.lines || '100'),
        follow: options?.follow || false,
      });
    } else if (subcommand === 'domain' && positionalArgs[0]) {
      await updateDomain(config, positionalArgs[0], positionalArgs[1]);
    } else if (subcommand === 'ssl' && joinedIdentifier) {
      await toggleSSL(config, joinedIdentifier);
    } else if (subcommand === 'env' && positionalArgs[0]) {
      const appName = positionalArgs[0];
      const key = positionalArgs[1];
      if (key) {
        const value = positionalArgs.slice(2).join(' ');
        await setEnvVar(config, appName, key, value);
      } else {
        await listEnvVars(config, appName);
      }
    } else if (subcommand === 'exec' && positionalArgs[0] && positionalArgs[1]) {
      const appName = positionalArgs[0];
      const command = positionalArgs.slice(1).join(' ');
      await execInApp(config, appName, command);
    } else if (subcommand === 'terminal' && joinedIdentifier) {
      await openAppTerminal(config, joinedIdentifier, options?.debug === true);
    } else if (!subcommand || subcommand === 'list') {
      await listApps(config);
    } else {
      console.log(chalk.red(`Unknown subcommand or missing arguments`));
      console.log(chalk.gray('Available: list, show <app>, redeploy <app>, clone <app> <server>, move <app> <server>, delete <app>, restart <app>, logs <apps...>, exec <app> <command>, terminal <app>, domain <app> <domain>, ssl <app>, env <app> [key] [value]'));
    }
  });

// Servers commands - simplified, autonomous by default
program
  .command('servers [subcommand] [arg1] [arg2] [arg3] [arg4]')
  .description('Manage servers (list, status, add, delete, inspect, exec, cleanup, key, reconnect, provision, providers, methods, connect, wiring-test [admin], ...)')
  .option('--confirm', 'Require confirmation for destructive operations')
  .option('--save <path>', 'Save output to path (e.g. key --save /tmp/key)')
  .option('--key <path>', 'SSH key path for reconnect (non-GCP only); updates server credentials then tests')
  .option('--username <user>', 'SSH username when using --key (default: ubuntu, e.g. for Multipass)')
  .action(async (subcommand, arg1, arg2, arg3, arg4, options) => {
    if (subcommand === 'add' && arg1 && arg2) {
      addServer(config, arg1, arg2, arg3, options?.username);
    } else if (subcommand === 'delete' && arg1) {
      deleteServer(config, arg1, options?.confirm || false);
    } else if (subcommand === 'provision') {
      await runProvision(config, arg1, arg2, arg3, arg4);
    } else if (subcommand === 'inspect' && arg1) {
      inspectServer(config, arg1);
    } else if (subcommand === 'exec' && arg1 && arg2) {
      execOnServer(config, arg1, arg2);
    } else if (subcommand === 'cleanup' && arg1) {
      cleanupServer(config, arg1);
    } else if (subcommand === 'providers') {
      listProviders(config);
    } else if (subcommand === 'methods' && arg1) {
      listMethods(config, arg1);
    } else if (subcommand === 'connect' && arg1) {
      // connect <method> [provider] [serverIndex|ip] [apiKey]
      // connect self-host [name]
      // connect oauth GCP [serverIndex] | connect api GCP <ip> [apiKey]
      const method = arg1.toLowerCase();
      const provider = arg2;
      const serverIndexOrIp = arg3;
      const apiKey = arg4;

      if (method === 'self-host') {
        await connectHome(config, provider); // provider used as optional name
        return;
      }
      if (method === 'home' || method === 'selfhost') {
        console.log(chalk.red(`Unsupported connection method: ${method}`));
        console.log(chalk.gray('Use standardized method: self-host'));
        return;
      }
      if (!arg2) {
        console.log(chalk.red('Provider required for oauth/api'));
        console.log(
          chalk.gray(
            'Examples: clikdeploy servers connect oauth GCP | connect api GCP <ip> | connect self-host'
          )
        );
        return;
      }
      if (method === 'oauth') {
        await connectOAuth(config, provider, serverIndexOrIp);
      } else if (method === 'api') {
        if (!serverIndexOrIp) {
          console.log(chalk.red('IP address required for API token connection'));
          console.log(chalk.gray('Example: clikdeploy servers connect api GCP 34.174.203.154'));
          return;
        }
        connectAPI(config, provider, serverIndexOrIp, apiKey);
      } else {
        console.log(chalk.red(`Unknown connection method: ${method}`));
        console.log(chalk.gray('Available methods: oauth, api, self-host'));
      }
    } else if (subcommand === 'key' && arg1) {
      getServerKey(config, arg1, options?.save);
    } else if (subcommand === 'reconnect') {
      reconnectServer(config, arg1, options?.key, options?.username);
    } else if (subcommand === 'discover') {
      discoverServer(config, arg1);
    } else if (subcommand === 'lifecycle') {
      testServerLifecycle(config, arg1);
    } else if (subcommand === 'apps-lifecycle') {
      testServerAppLifecycle(config, arg1);
    } else if (subcommand === 'status') {
      showServersStatus(config);
    } else if (subcommand === 'wiring-test') {
      wiringTest(config);
    } else if (!subcommand || subcommand === 'list') {
      listServers(config);
    } else {
      console.log(chalk.red(`Unknown subcommand or missing arguments`));
      console.log(chalk.gray('Available: list, status, wiring-test, discover [server], lifecycle [server], apps-lifecycle [server], reconnect [server], add, delete, provision, inspect, exec, cleanup, key <server> [--save path], providers, methods <provider>, connect <oauth|api|self-host> [provider] [ip] [apiKey]'));
    }
  });

// Marketplace commands
const marketplace = program
  .command('marketplace')
  .description('Deploy apps from marketplace');

marketplace
  .command('deploy <apps...>')
  .description('Deploy marketplace app(s) (e.g., n8n ghost vaultwarden)')
  .option('-s, --server <name>', 'Deploy to specific server')
  .option('-c, --concurrency <n>', 'Max concurrent deploy starts (default: 4)')
  .option('--no-wait', 'Don\'t wait for deployment to complete')
  .action((apps, options) => deployMarketplace(config, apps, options));

marketplace
  .command('delete <appIds...>')
  .description('Delete app(s) (e.g., clikdeploy marketplace delete app1 app2 app3)')
  .action((appIds) => deleteApp(config, appIds));

marketplace
  .command('list')
  .description('List available marketplace apps')
  .action(() => listMarketplace(config));

marketplace
  .command('status <appId>')
  .description('Check app status')
  .action((appId) => checkStatus(config, appId));

// Docker commands (non-marketplace apps)
const docker = program
  .command('docker')
  .description('Deploy any Docker image (non-marketplace)');

docker
  .command('deploy <image> [name]')
  .description('Deploy a Docker image (e.g., redis:latest my-cache)')
  .option('-s, --server <name>', 'Deploy to specific server')
  .option('-p, --port <port>', 'Application port')
  .option('-e, --env <KEY=VALUE>', 'Environment variable (can be specified multiple times)', (val, prev) => [...(prev || []), val], [])
  .option('--no-wait', 'Don\'t wait for deployment to complete')
  .action((image, name, options) => deployDockerImage(config, image, name, options));

docker
  .command('list [search]')
  .description('List deployed Docker apps')
  .action((search) => listDockerImages(config, search));

// Worker commands - simple management
const worker = program
  .command('worker')
  .description('Manage deployment workers');

worker
  .command('status')
  .description('Check worker status')
  .action(() => workerStatus(config));

worker
  .command('start')
  .description('Start the deployment worker (PM2 or background)')
  .action(() => workerStart(config));

worker
  .command('restart')
  .description('Restart worker')
  .action(() => workerRestart(config));

worker
  .command('logs')
  .description('View worker logs')
  .action(() => workerLogs(config));

worker
  .command('clear')
  .description('Clear waiting jobs from the deployment queue')
  .option('--active', 'Also clear active jobs (force-clear all)')
  .action((opts) => workerClear(config, opts));

// GitHub deploy
const github = program
  .command('github')
  .description('Deploy from GitHub repository URL(s)');

github
  .command('deploy <urls...>')
  .description('Deploy one or more GitHub repos (e.g. clikdeploy github deploy https://github.com/owner/repo)')
  .option('-s, --server <id>', 'Deploy to specific server')
  .option('-b, --branch <branch>', 'Branch to deploy', 'main')
  .option('--no-wait', 'Do not wait for each deployment to complete')
  .action((urls, options) => deployFromUrlBatch(config, urls, { server: options.server, branch: options.branch, wait: options.wait !== false }));

// Admin testing framework
program
  .command('test [subcommand]')
  .description('Testing commands (admin mass simulation + local docker simulation)')
  .option('--scale <n>', 'Number of scenarios to run (1-10000)', '1000')
  .option('--concurrency <n>', 'Parallel scenario workers (1-500)', '50')
  .option('--seed <n>', 'Deterministic seed')
  .option('--variants <n>', 'Distinct simulated app variants (1-10000)')
  .option('--runtime <mode>', 'all|docker', 'all')
  .option('--failures <list>', 'Comma-separated failure types')
  .option('--strict', 'Require expected recovery/fix assertions for each scenario')
  .option('--verbose', 'Show detailed simulation logs (default: quiet)')
  .option('--json', 'Output full JSON response')
  .option('--output <path>', 'Write full JSON report to file')
  .action((subcommand, options) => {
    if (subcommand === 'docker-sim' || subcommand === 'docker') {
      runDockerSimulationSuite(config, options);
      return;
    }
    const mode = subcommand === 'run' ? 'run' : 'recovery';
    runTestingFramework(config, mode, options);
  });

// Notifications commands
const notifications = program
  .command('notifications')
  .description('Manage skill/agent notifications');

notifications
  .command('list')
  .description('List latest notifications')
  .option('--json', 'Output results as JSON')
  .option('--limit <n>', 'Number of notifications to show', '20')
  .action((options) => listNotifications({ ...options, limit: parseInt(options.limit) }));

notifications
  .command('clear')
  .description('Clear notification history')
  .option('--json', 'Output results as JSON')
  .action((options) => clearNotifications(options));


// Handle unknown commands
program.on('command:*', () => {
  console.error(chalk.red(`Unknown command: ${program.args.join(' ')}`));
  console.log();
  console.log('Run', chalk.cyan('clikdeploy --help'), 'for available commands');
  process.exit(1);
});

// Show help if no command provided
if (!process.argv.slice(2).length) {
  console.log(banner);
  program.outputHelp();
}

program.parse();
