import ora from 'ora';
import Conf from 'conf';
import path from 'path';
import { spawn } from 'child_process';
import fs from 'fs';
import { getApiClient, requireAuth, getApiUrl } from '../utils/api';
import { ApiClient } from '../api/client';
import { Formatters } from '../ui/formatters';
import chalk from 'chalk';
import { Prompts } from '../ui/prompts';
import { connectToInstance, performServerOAuth } from './server-connect-oauth';

/**
 * Server Connection Commands
 * Supports OAuth, API token, and SSH connections
 */

interface CloudProvider {
  key: string;
  name: string;
  capabilities: {
    oauth: boolean;
    apiToken: boolean;
    ssh: boolean;
  };
}

/**
 * List available cloud providers
 */
export async function listProviders(config: Conf) {
  requireAuth(config);

  const api = getApiClient(config);
  const spinner = ora('Loading providers...').start();

  try {
    // Get providers from API (or use hardcoded list if API doesn't exist)
    const providers: CloudProvider[] = [
      {
        key: 'GCP',
        name: 'Google Cloud Platform',
        capabilities: { oauth: true, apiToken: true, ssh: true },
      },
      {
        key: 'AWS',
        name: 'Amazon Web Services',
        capabilities: { oauth: false, apiToken: true, ssh: true },
      },
      {
        key: 'AZURE',
        name: 'Microsoft Azure',
        capabilities: { oauth: true, apiToken: true, ssh: true },
      },
      {
        key: 'DIGITALOCEAN',
        name: 'DigitalOcean',
        capabilities: { oauth: true, apiToken: true, ssh: true },
      },
      {
        key: 'LINODE',
        name: 'Linode',
        capabilities: { oauth: false, apiToken: true, ssh: true },
      },
      {
        key: 'VULTR',
        name: 'Vultr',
        capabilities: { oauth: false, apiToken: true, ssh: true },
      },
      {
        key: 'HETZNER',
        name: 'Hetzner Cloud',
        capabilities: { oauth: false, apiToken: true, ssh: true },
      },
    ];

    spinner.stop();

    console.log(chalk.bold('\n☁️  Available Cloud Providers\n'));

    for (const provider of providers) {
      const methods: string[] = [];
      if (provider.capabilities.oauth) methods.push('OAuth');
      if (provider.capabilities.apiToken) methods.push('API');
      if (provider.capabilities.ssh) methods.push('SSH');

      console.log(
        chalk.cyan(`  ${provider.key.padEnd(15)}`) +
        provider.name.padEnd(30) +
        chalk.gray(`(${methods.join(', ')})`)
      );
    }

    console.log();
  } catch (error: any) {
    spinner.fail('Failed to load providers');
    Formatters.error(error.response?.data?.error || error.message);
  }
}

/**
 * List connection methods for a provider
 */
export async function listMethods(config: Conf, providerKey: string) {
  requireAuth(config);

  if (!providerKey) {
    Formatters.error('Please specify a provider');
    Formatters.gray('Example: clikdeploy servers methods GCP');
    return;
  }

  const providers: Record<string, CloudProvider> = {
    GCP: {
      key: 'GCP',
      name: 'Google Cloud Platform',
      capabilities: { oauth: true, apiToken: true, ssh: true },
    },
    AWS: {
      key: 'AWS',
      name: 'Amazon Web Services',
      capabilities: { oauth: false, apiToken: true, ssh: true },
    },
    AZURE: {
      key: 'AZURE',
      name: 'Microsoft Azure',
      capabilities: { oauth: true, apiToken: true, ssh: true },
    },
    DIGITALOCEAN: {
      key: 'DIGITALOCEAN',
      name: 'DigitalOcean',
      capabilities: { oauth: true, apiToken: true, ssh: true },
    },
  };

  const provider = providers[providerKey.toUpperCase()];

  if (!provider) {
    Formatters.error(`Unknown provider: ${providerKey}`);
    Formatters.gray('Run "clikdeploy servers providers" to see available providers');
    return;
  }

  console.log(chalk.bold(`\n🔌 Connection Methods for ${provider.name}\n`));

  const methods: Array<{ name: string; available: boolean; description: string }> = [
    {
      name: 'OAuth',
      available: provider.capabilities.oauth,
      description: 'Authenticate via browser (Google, Azure, DigitalOcean)',
    },
    {
      name: 'API Token',
      available: provider.capabilities.apiToken,
      description: 'Use API key/token from provider dashboard',
    },
    {
      name: 'SSH Key',
      available: provider.capabilities.ssh,
      description: 'Direct SSH connection with key file',
    },
  ];

  for (const method of methods) {
    const status = method.available ? chalk.green('✓') : chalk.red('✗');
    console.log(
      `  ${status} ${chalk.cyan(method.name.padEnd(12))} ${chalk.gray(method.description)}`
    );
  }

  console.log();
}

/**
 * Connect server via OAuth
 * Uses existing platform logic to list instances and initiate connection
 * Connection happens asynchronously in the background
 */
export async function connectOAuth(
  config: Conf,
  providerKey: string,
  serverIndex?: string
) {
  requireAuth(config);

  if (!providerKey) {
    Formatters.error('Please specify a provider');
    Formatters.gray('Example: clikdeploy servers connect oauth GCP');
    return;
  }

  // Only GCP is currently supported for OAuth instance listing
  if (providerKey.toUpperCase() !== 'GCP') {
    Formatters.error('OAuth instance listing is currently only supported for GCP');
    Formatters.gray('For other providers, use: clikdeploy servers connect oauth PROVIDER IP_ADDRESS');
    return;
  }

  // Check if CLI is authenticated first
  requireAuth(config);

  const apiClient = new ApiClient(config, 60000);
  const api = apiClient.getClient(); // single client so interceptor sets Bearer on every request
  const baseUrl = apiClient.baseUrl;
  const apiKey = config.get('apiKey') as string;
  const authHeaders = apiKey ? { Authorization: `Bearer ${apiKey}` } : {};
  let spinner = ora('Getting user information...').start();

  try {
    // Get current user (explicit auth header)
    let userId: string | null = null;
    try {
      const { data: userData } = await api.get('/api/auth/me', { headers: authHeaders });
      userId = userData?.user?.id || null;
    } catch (err: any) {
      spinner.fail('Failed to get user information');
      const msg = err.response?.data?.error || err.message || 'Request failed';
      Formatters.error(msg);
      console.log(chalk.gray(`  Tried: ${baseUrl}/api/auth/me`));
      console.log(chalk.gray('  Log in: clikdeploy login'));
      console.log(chalk.gray('  Set API URL: clikdeploy config api-url https://clikdeploy.com'));
      process.exit(1);
    }

    if (!userId) {
      spinner.fail('User not found');
      Formatters.error('Please ensure you are logged in: clikdeploy login');
      console.log(chalk.gray(`  API URL: ${baseUrl}`));
      process.exit(1);
    }

    // Always run OAuth flow first to ensure we have fresh permissions
    spinner.stop();
    const oauthSpinner = ora('Waiting for authentication...').start();

    try {
      // Do OAuth to get server scopes - uses cli-init so API-key users get a one-time auth URL
      await performServerOAuth(config, providerKey, apiClient);
      oauthSpinner.succeed('Authenticated');
    } catch (oauthError: any) {
      oauthSpinner.fail('Authentication failed');
      Formatters.error(oauthError.message || 'OAuth authentication failed');
      process.exit(1); // Exit on failure, just like CLI auth
    }

    // Immediately list instances after OAuth (use ApiClient method so Bearer is always sent)
    spinner = ora('Finding servers...').start();
    let instancesResponse: { data: any };
    try {
      instancesResponse = { data: await apiClient.getOAuthInstances('GCP') };
    } catch (err: any) {
      spinner.fail('Failed to list instances');
      const data = err.response?.data;
      const code = data?.code;
      const msg = data?.error || err.message;
      Formatters.error(msg);
      if (code === 'REAUTH_REQUIRED') {
        console.log(chalk.gray('  Complete the OAuth flow in the browser that opened: sign in with Google and grant all requested permissions (including cloud-platform).'));
        console.log(chalk.gray('  Then run this command again.'));
      } else if (err.response?.status === 401) {
        console.log(chalk.gray('  Ensure you are logged in: clikdeploy login'));
        console.log(chalk.gray('  Check API URL: clikdeploy config api-url'));
      }
      process.exit(1);
    }

    const instancesData = instancesResponse.data;
    if (!instancesData.success || !instancesData.projects) {
      spinner.fail('Failed to list instances');
      const errMsg = instancesData?.error || instancesData?.code || 'Unknown error';
      Formatters.error(errMsg);
      if (instancesData?.code === 'REAUTH_REQUIRED') {
        console.log(chalk.gray('  Run the command again and complete the Google OAuth flow in the browser (grant all permissions).'));
      }
      process.exit(1);
    }

    // Flatten all instances from all projects
    const allInstances: Array<{
      projectId: string;
      projectName: string;
      id: string;
      name: string;
      zone: string;
      status: string;
      ipAddress?: string;
    }> = [];

    for (const project of instancesData.projects) {
      for (const instance of project.instances || []) {
        allInstances.push({
          projectId: project.id,
          projectName: project.name,
          id: instance.id,
          name: instance.name,
          zone: instance.zone,
          status: instance.status,
          ipAddress: instance.ipAddress,
        });
      }
    }

    if (allInstances.length === 0) {
      spinner.fail('No instances found');
      Formatters.gray('Please create a Compute Engine instance in your Google Cloud project');
      process.exit(1);
    }

    // If server index provided as argument, use it directly
    if (serverIndex) {
      const index = parseInt(serverIndex) - 1; // Convert to 0-based
      if (index >= 0 && index < allInstances.length) {
        const selectedInstance = allInstances[index];
        spinner.succeed(`Selected server: ${selectedInstance.name}`);
        console.log();

        await connectToInstance(api, selectedInstance);
        process.exit(0);
      } else {
        spinner.fail('Invalid server index');
        console.log(chalk.red(`Server index must be between 1 and ${allInstances.length}`));
        process.exit(1);
      }
    }

    // If exactly 1 instance, auto-connect and finish
    if (allInstances.length === 1) {
      const instance = allInstances[0];
      spinner.succeed(`Found 1 server: ${instance.name}`);

      await connectToInstance(api, instance);
      process.exit(0); // Command finishes here
    }

    // Multiple instances - show numbered list and get user input
    spinner.stop();
    console.log(chalk.bold(`\n📋 Found ${allInstances.length} servers:\n`));

    allInstances.forEach((inst, idx) => {
      console.log(chalk.cyan(`${idx + 1}.`) + ` ${inst.name} (${inst.ipAddress || 'no IP'}) - ${inst.zone} - ${inst.status}`);
    });
    console.log();

    console.log();
    console.log('To connect to a server, run:');
    console.log('clikdeploy servers connect oauth GCP <number>');
    console.log();
    console.log('Available servers:');
    allInstances.forEach((inst, idx) => {
      console.log(`  ${idx + 1}: ${inst.name}`);
    });
    console.log();
    process.exit(0);

  } catch (error: any) {
    if (!error?.connectionErrorAlreadyShown) {
      spinner.fail('Connection failed');
      Formatters.error(error?.response?.data?.error || error?.message || 'Unknown error');
    }
    process.exit(1);
  }
}

/**
 * Connect server via API token
 */
export async function connectAPI(
  config: Conf,
  providerKey: string,
  ipAddress: string,
  apiKey?: string
) {
  requireAuth(config);

  if (!providerKey || !ipAddress) {
    Formatters.error('Please specify provider and IP address');
    Formatters.gray('Example: clikdeploy servers connect api GCP 34.174.203.154');
    return;
  }

  const api = getApiClient(config);
  const spinner = ora('Connecting server...').start();

  try {
    // Prompt for API key if not provided
    let finalApiKey = apiKey;
    if (!finalApiKey) {
      spinner.stop();
      finalApiKey = await Prompts.askForInput(
        `Enter ${providerKey} API key/token:`,
        ''
      );
      spinner.start('Connecting server...');
    }

    // For GCP, we might need project ID as well
    let projectId: string | undefined;
    if (providerKey.toUpperCase() === 'GCP') {
      spinner.stop();
      // Use inquirer directly for optional input
      const inquirer = (await import('inquirer')).default;
      const { projectIdInput } = await inquirer.prompt([
        {
          type: 'input',
          name: 'projectIdInput',
          message: 'GCP Project ID (optional, press Enter to skip):',
          default: '',
        },
      ]);
      projectId = projectIdInput?.trim() || undefined;
      spinner.start('Connecting server...');
    }

    // Prepare API credentials based on provider
    const apiCredentials: any = {
      type: 'apiToken',
      provider: providerKey.toUpperCase(),
      apiKey: finalApiKey,
    };

    if (projectId) {
      apiCredentials.projectId = projectId;
    }

    // Generate server name
    const serverName = `${providerKey.toLowerCase()}-${ipAddress.replace(/\./g, '-')}`;

    // Call universal connection API
    const { data } = await api.getClient().post('/api/servers/connect', {
      name: serverName,
      cloudProvider: providerKey.toUpperCase(),
      ipAddress,
      apiCredentials,
    });

    spinner.succeed(`Server "${serverName}" connected successfully`);

    console.log(chalk.bold('\n🖥️  Server Details:\n'));
    Formatters.info('Name:   ', data.data.name);
    Formatters.info('IP:     ', data.data.ipAddress);
    Formatters.info('Status: ', data.data.status);
    console.log();
  } catch (error: any) {
    spinner.fail('API connection failed');
    Formatters.error(error.response?.data?.error || error.message);

    if (error.response?.data?.publicKey) {
      console.log(chalk.bold('\n📋 Your SSH Public Key:\n'));
      console.log(error.response.data.publicKey);
      console.log();
      Formatters.gray('You may need to add this key manually to your server');
    }
  }
}

/**
 * Admin: Run wiring test (all connection types × all providers) via platform API.
 * Requires auth. Uses fake credentials; validates response shapes only.
 */
export async function wiringTest(config: Conf) {
  requireAuth(config);

  const api = getApiClient(config, 120_000);
  const spinner = ora('Running wiring test (admin)...').start();

  try {
    const { data } = await api.getClient().get('/api/admin/wiring-test');

    spinner.stop();

    const results: Array<{ provider: string; connectionType: string; ok: boolean; message: string; durationMs: number }> =
      data.results ?? [];
    const passed = data.passed ?? 0;
    const failed = data.failed ?? 0;
    const total = data.total ?? 0;

    console.log(chalk.bold('\n🔌 Wiring test (admin)\n'));
    console.log(
      chalk.gray('Provider'.padEnd(14)) +
      chalk.gray('Type'.padEnd(12)) +
      chalk.gray('Status'.padEnd(10)) +
      chalk.gray('Message')
    );
    console.log(chalk.gray('-'.repeat(60)));

    for (const r of results) {
      const status = r.ok ? chalk.green('ok') : chalk.red('fail');
      const msg = (r.message ?? '').slice(0, 50);
      console.log(
        r.provider.padEnd(14) +
        r.connectionType.padEnd(12) +
        status.padEnd(18) +
        chalk.gray(msg)
      );
    }

    console.log(chalk.gray('-'.repeat(60)));
    console.log(
      chalk.bold(`Total: ${total}  `) +
      chalk.green(`Passed: ${passed}`) +
      (failed > 0 ? chalk.red(`  Failed: ${failed}`) : '')
    );
    console.log();

    if (data.success === false && failed > 0) {
      process.exitCode = 1;
    }
  } catch (error: any) {
    spinner.fail('Wiring test failed');
    Formatters.error(error.response?.data?.error || error.message);
    if (error.response?.status === 401) {
      Formatters.gray('Log in with: clikdeploy login');
    }
    process.exitCode = 1;
  }
}

/**
 * Connect this computer as a Home server via the agent.
 *
 * CLI flow (this function): already authenticated → call /api/gate/connect
 * directly to get a token + serverId, then launch the local agent binary with
 * those credentials. No pairing code is needed or shown.
 *
 * One-liner / unauthenticated flow: user gets a pairing code from the dashboard
 * and runs `curl … | sh -s -- agent --code CODE`.
 */
export async function connectHome(config: Conf, name?: string) {
  requireAuth(config);

  const api = getApiClient(config);
  const baseUrl = api.baseUrl.replace(/\/$/, '');

  // Agent connects FROM this machine TO baseUrl. If baseUrl is localhost, the agent will
  // try to reach the platform on this same machine. If the platform runs elsewhere (e.g.
  // production), the agent will never connect. Require a non-localhost URL so the agent
  // can reach the real platform.
  const isLocalhost =
    /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?\/?$/i.test(baseUrl) ||
    baseUrl === 'localhost' ||
    baseUrl.startsWith('localhost:');
  if (isLocalhost) {
    console.log(chalk.red('Agent cannot connect when API URL is localhost.'));
    console.log(chalk.gray('The agent runs on this machine and will try to connect to "' + baseUrl + '" — that is this computer, not your ClikDeploy platform.'));
    console.log();
    console.log(chalk.gray('Set your platform URL and try again:'));
    console.log(chalk.cyan('  clikdeploy config api-url https://clikdeploy.com'));
    console.log(chalk.gray('  (or your actual platform URL)'));
    console.log();
    process.exitCode = 1;
    return;
  }

  // Resolve path to agent binary: from CLI (apps/cli/dist/commands) → apps/self-host
  const thisDir = __dirname;
  const agentDir = path.join(path.dirname(path.dirname(path.dirname(thisDir))), 'self-host');
  const agentDist = path.join(agentDir, 'dist', 'index.js');
  const agentSrc = path.join(agentDir, 'src', 'index.ts');

  const serverName = name || 'Self Host';

  const spinner = ora('Provisioning self host server…').start();

  const shQuote = (value: string): string => `'${String(value).replace(/'/g, `'"'"'`)}'`;

  try {
    const data = await api.provisionAgent(serverName, { waitForHealthy: false });

    spinner.succeed(`Server "${chalk.bold(serverName)}" created`);
    console.log(chalk.gray(`  Server ID : ${data.serverId}`));
    console.log(chalk.gray(`  Agent  ID : ${data.agentId}`));
    console.log(
      chalk.gray(
        `  Code Update: ${data.shouldUpdateAgentCode ? 'required (will refresh agent binary)' : 'not required (fresh auth only)'}`
      )
    );
    console.log();
    await runAgentInstaller(config, {
      token: data.token,
      serverId: data.serverId,
      agentId: data.agentId,
      shouldUpdateAgentCode: data.shouldUpdateAgentCode,
      baseUrl,
    });
  } catch (error: any) {
    spinner.fail('Failed to provision self host server');
    Formatters.error(error.response?.data?.error || error.message);
    if (error.response?.status === 401) {
      Formatters.gray('Log in with: clikdeploy login');
    }
    process.exitCode = 1;
  }
}

/**
 * Runs the self-host agent installer or starts the local binary.
 * This is the "Download and Execute" logic shared by connectHome and loginExchange.
 */
export async function runAgentInstaller(
  config: Conf,
  data: {
    token: string;
    serverId: string;
    agentId: string;
    shouldUpdateAgentCode: boolean;
    baseUrl: string;
  }
): Promise<void> {
  const shQuote = (value: string): string => `'${String(value).replace(/'/g, `'"'"'`)}'`;
  const { baseUrl } = data;

  // Resolve path to agent binary
  const thisDir = __dirname;
  const agentDir = path.join(path.dirname(path.dirname(path.dirname(thisDir))), 'self-host');
  const agentDist = path.join(agentDir, 'dist', 'index.js');
  const agentSrc = path.join(agentDir, 'src', 'index.ts');

  const oneLiner = `curl -fsSL ${shQuote(`${baseUrl}/install.sh`)} | bash -s -- --token ${shQuote(data.token)} --server-id ${shQuote(data.serverId)} --agent-id ${shQuote(data.agentId)} --server ${shQuote(baseUrl)}`;

  if (!fs.existsSync(agentDir) || data.shouldUpdateAgentCode) {
    console.log(
      chalk.bold(
        !fs.existsSync(agentDir)
          ? 'Agent binary not found locally. Running installer now...'
          : 'Refreshing agent code/auth via installer now...'
      )
    );
    console.log();

    const installer = spawn('bash', ['-lc', oneLiner], {
      stdio: 'inherit',
      env: { ...process.env, FORCE_COLOR: '1' },
    });

    return new Promise((resolve) => {
      installer.on('error', (err) => {
        Formatters.error(err.message);
        process.exitCode = 1;
        resolve();
      });
      installer.on('exit', (code) => {
        if (code !== 0 && code !== null) process.exitCode = code;
        resolve();
      });
    });
  }

  // Launch the local agent binary directly
  const args = ['--token', data.token, '--server-id', data.serverId, '--server', baseUrl];

  console.log(chalk.gray('Agent found in monorepo. Starting agent now…'));
  console.log();

  let child: ReturnType<typeof spawn>;

  if (fs.existsSync(agentDist)) {
    child = spawn(process.execPath, [agentDist, ...args], {
      cwd: agentDir,
      stdio: 'inherit',
      env: { ...process.env, FORCE_COLOR: '1' },
    });
  } else if (fs.existsSync(agentSrc)) {
    child = spawn(process.platform === 'win32' ? 'npx.cmd' : 'npx', ['tsx', agentSrc, ...args], {
      cwd: agentDir,
      stdio: 'inherit',
      shell: true,
      env: { ...process.env, FORCE_COLOR: '1' },
    });
  } else {
    console.log(chalk.yellow('Agent binary not built. Build first: cd apps/self-host && pnpm install && pnpm run build'));
    return;
  }

  child.on('error', (err) => {
    Formatters.error(err.message);
    process.exitCode = 1;
  });
  child.on('exit', (code) => {
    if (code !== 0 && code !== null) process.exitCode = code;
  });
}

/**
 * Interactive 'connect' wizard: the primary way to add hardware.
 * Simplifies choice between Cloud, SSH, or Self-Host.
 */
export async function runConnect(config: Conf, options: { interactive?: boolean } = {}) {
  requireAuth(config);
  const api = getApiClient(config);

  // Default to JSON unless interactive is explicitly requested
  if (!options.interactive) {
    const discovery = await (api as any).getDiscovery().catch(() => ({}));
    console.log(JSON.stringify({
      discovery: discovery.connectivity
    }, null, 2));
    return;
  }

  const inquirer = (await import('inquirer')).default;

  const { type } = await inquirer.prompt([
    {
      type: 'list',
      name: 'type',
      message: 'How would you like to connect your infrastructure?',
      choices: [
        { name: '☁️  Cloud Instance (GCP, AWS, DigitalOcean - OAuth/API)', value: 'CLOUD' },
        { name: '🖥️  Existing SSH Server (Remote IP + Private Key)', value: 'SSH' },
        { name: '🏠 Home/Self-Host Agent (Connect THIS computer)', value: 'HOME' },
        { name: '🚀 Provision NEW Cloud Server (Instant setup)', value: 'PROVISION' },
      ],
    },
  ]);

  switch (type) {
    case 'CLOUD': {
      const { provider } = await inquirer.prompt([
        {
          type: 'list',
          name: 'provider',
          message: 'Choose a provider:',
          choices: [
            { name: 'Google Cloud Platform (GCP)', value: 'GCP' },
            { name: 'DigitalOcean', value: 'DIGITALOCEAN' },
            { name: 'Amazon Web Services (AWS)', value: 'AWS' },
            { name: 'Azure', value: 'AZURE' },
          ],
        },
      ]);
      const { method } = await inquirer.prompt([
        {
          type: 'list',
          name: 'method',
          message: 'Connection method:',
          choices: [
            { name: 'OAuth (Simplest - browser login)', value: 'OAUTH' },
            { name: 'API Token', value: 'API' },
          ],
        },
      ]);

      if (method === 'OAUTH') {
        return connectOAuth(config, provider);
      } else {
        const { ip } = await inquirer.prompt([{ type: 'input', name: 'ip', message: 'Server IP Address:' }]);
        return connectAPI(config, provider, ip);
      }
    }

    case 'SSH': {
      const { name, ip, key } = await inquirer.prompt([
        { type: 'input', name: 'name', message: 'Server label (e.g. My Website):', default: 'Remote Server' },
        { type: 'input', name: 'ip', message: 'IP Address:' },
        { type: 'input', name: 'key', message: 'Path to private key:', default: '~/.ssh/id_rsa' },
      ]);
      const { addServer } = await import('./server');
      return addServer(config, name, ip, key);
    }

    case 'HOME': {
      const { name } = await inquirer.prompt([
        { type: 'input', name: 'name', message: 'Name for this computer:', default: 'My Computer' }
      ]);
      return connectHome(config, name);
    }

    case 'PROVISION': {
      const { runProvision } = await import('./server');
      return runProvision(config);
    }
  }
}
