# ClikDeploy CLI

Deploy apps with one command. The CLI talks to your ClikDeploy platform (hosted or self host) and lets you manage servers, apps, and deployments from the terminal.

**Philosophy:** Dead simple. Autonomous by default. No prompts, no confirmations.

---

## Install

**One-liner (from our site):**

```bash
curl -fsSL https://clikdeploy.com/cli.sh | bash
```

**Or with npm:**

```bash
npm install -g clikdeploy-cli
```

**Requirements:** Node.js 18+.

---

## Quick start

1. **Point the CLI at your platform** (only if not using hosted ClikDeploy):

   ```bash
   clikdeploy config api-url https://your-platform.example.com
   ```

   Default is `https://clikdeploy.com`. Use localhost only for local development.

2. **Log in:**

   ```bash
   clikdeploy login
   ```

   Use email/password, or `--google` / `--github` for OAuth.

3. **Deploy:**

   ```bash
   cd your-repo
   clikdeploy deploy
   ```

   Or deploy from the marketplace, a GitHub URL, or a Docker image (see below).

---

## Commands overview

| Command | Description |
|--------|-------------|
| [Auth](#auth) | `login`, `signup`, `logout`, `whoami` |
| [Config](#config) | `config` – API URL and settings |
| [Project](#project) | `init`, `deploy` – init project, deploy current dir |
| [Status](#status) | `status`, `logs`, `watch` – app status and logs |
| [Apps](#apps) | `apps` – list, show, delete, restart, redeploy, logs, domain, ssl, env |
| [Servers](#servers) | `servers` – list, add, delete, connect, inspect, exec, etc. |
| [Marketplace](#marketplace) | `marketplace` – list, deploy, delete, status |
| [Docker](#docker) | `docker` – deploy any image, list Docker apps |
| [GitHub](#github) | `github deploy` – deploy from repo URL(s) |
| [Worker](#worker) | `worker` – status, start, restart, logs, clear queue |

Use `clikdeploy --help` and `clikdeploy <command> --help` for options.

---

## Auth

| Command | Description |
|--------|-------------|
| `clikdeploy login` | Log in (email/password or OAuth). |
| `clikdeploy login --google` | Log in with Google. |
| `clikdeploy login --github` | Log in with GitHub. |
| `clikdeploy signup` | Create a new account. |
| `clikdeploy logout` | Log out and clear stored credentials. |
| `clikdeploy whoami` | Show current user. |

---

## Config

| Command | Description |
|--------|-------------|
| `clikdeploy config` | Show all config. |
| `clikdeploy config api-url <url>` | Set platform API URL (e.g. `https://clikdeploy.com`). |
| `clikdeploy config <key> [value]` | Get or set a config key. |

---

## Project

| Command | Description |
|--------|-------------|
| `clikdeploy init` | Initialize current directory as a ClikDeploy project (creates `clikdeploy.json`). |
| `clikdeploy deploy` | Deploy current directory (uses git remote and project config). |
| `clikdeploy deploy -s <server>` | Deploy to a specific server (by name or ID). |
| `clikdeploy deploy -b <branch>` | Deploy a specific branch. |
| `clikdeploy deploy --no-wait` | Start deployment and exit without waiting. |

---

## Status

| Command | Description |
|--------|-------------|
| `clikdeploy status [app]` | Show deployment status (optional app name or ID). |
| `clikdeploy logs [app]` | Show app logs (default: last 100 lines). |
| `clikdeploy logs [app] -f` | Follow log output. |
| `clikdeploy logs -n <n>` | Number of lines (e.g. `-n 200`). |
| `clikdeploy watch` | Watch all deployments in real time. |
| `clikdeploy watch -f deploying` | Filter by status (e.g. `deploying`, `error`, `running`). |

---

## Apps

Manage applications (list, show, delete, restart, redeploy, logs, domain, SSL, env).

| Command | Description |
|--------|-------------|
| `clikdeploy apps` | List all apps. |
| `clikdeploy apps list` | Same as above. |
| `clikdeploy apps show <app>` | Show details for one app (by name or ID). |
| `clikdeploy apps delete <app> [app2 ...]` | Delete one or more apps. |
| `clikdeploy apps delete --all` | Delete all apps (use with care). |
| `clikdeploy apps restart <app>` | Restart an app. |
| `clikdeploy apps redeploy <app>` | Redeploy an app (triggers new deployment). |
| `clikdeploy apps redeploy <app> --no-wait` | Redeploy without waiting for completion. |
| `clikdeploy apps logs <app> [app2 ...]` | View container logs for one or more apps. |
| `clikdeploy apps logs <app> -f` | Follow logs. |
| `clikdeploy apps domain <app> <domain>` | Set custom domain (e.g. `myapp.example.com`). |
| `clikdeploy apps ssl <app>` | Toggle SSL for an app. |
| `clikdeploy apps env <app>` | List environment variables. |
| `clikdeploy apps env <app> <KEY>` | Set env var (value can be prompted or piped). |

---

## Servers

Manage infrastructure (list, add, delete, connect via OAuth or API, inspect, exec, etc.).

| Command | Description |
|--------|-------------|
| `clikdeploy servers` | List all servers. |
| `clikdeploy servers list` | Same as above. |
| `clikdeploy servers add <name> <ip> [sshKeyPath]` | Add server (SSH key optional). |
| `clikdeploy servers delete <server>` | Delete a server. |
| `clikdeploy servers providers` | List supported cloud providers. |
| `clikdeploy servers methods <provider>` | List connection methods for a provider (e.g. GCP). |
| `clikdeploy servers connect oauth <provider> [index]` | Connect server via OAuth (e.g. `oauth GCP`; optional instance index). |
| `clikdeploy servers connect api <provider> <ip> [apiKey]` | Connect server with API token (e.g. `api GCP 34.1.2.3`). |
| `clikdeploy servers inspect <server>` | Show server details. |
| `clikdeploy servers exec <server> <command>` | Run a command on the server. |
| `clikdeploy servers cleanup <server>` | Clean up deployment artifacts on the server. |
| `clikdeploy servers key <server>` | Show SSH key for the server. |
| `clikdeploy servers key <server> --save <path>` | Save key to a file. |
| `clikdeploy servers reconnect <server>` | Reconnect a server. |
| `clikdeploy servers provision [name] [provider] [size] [region]` | Provision a new server (if supported). |

---

## Marketplace

Deploy pre-configured apps from the marketplace (e.g. n8n, Ghost, Vaultwarden).

| Command | Description |
|--------|-------------|
| `clikdeploy marketplace list` | List available marketplace apps. |
| `clikdeploy marketplace deploy <app> [app2 ...]` | Deploy one or more apps (e.g. `marketplace deploy n8n ghost`). |
| `clikdeploy marketplace deploy <app> -s <server>` | Deploy to a specific server. |
| `clikdeploy marketplace deploy <app> --no-wait` | Deploy without waiting. |
| `clikdeploy marketplace delete <appId> [appId2 ...]` | Delete app(s) by ID. |
| `clikdeploy marketplace status <appId>` | Check app status. |

---

## Docker

Deploy any Docker image (non-marketplace).

| Command | Description |
|--------|-------------|
| `clikdeploy docker deploy <image> [name]` | Deploy an image (e.g. `redis:latest my-cache`). |
| `clikdeploy docker deploy <image> -s <server>` | Deploy to a specific server. |
| `clikdeploy docker deploy <image> -p <port>` | Set application port (default 80). |
| `clikdeploy docker deploy <image> -e KEY=val -e FOO=bar` | Pass environment variables. |
| `clikdeploy docker deploy <image> --no-wait` | Deploy without waiting. |
| `clikdeploy docker list [search]` | List deployed Docker apps (optional search term). |

---

## GitHub

Deploy from a GitHub repository URL (builds from source on the platform).

| Command | Description |
|--------|-------------|
| `clikdeploy github deploy <url> [url2 ...]` | Deploy one or more repos (e.g. `https://github.com/owner/repo`). |
| `clikdeploy github deploy <url> -s <server>` | Deploy to a specific server. |
| `clikdeploy github deploy <url> -b <branch>` | Deploy a branch (default `main`). |
| `clikdeploy github deploy <url> --no-wait` | Deploy without waiting. |

---

## Worker

Manage the deployment worker (for self host platforms; status, restart, logs, queue).

| Command | Description |
|--------|-------------|
| `clikdeploy worker status` | Check worker status and queue. |
| `clikdeploy worker start` | Start the worker (PM2 or background). |
| `clikdeploy worker restart` | Restart the worker. |
| `clikdeploy worker logs` | View worker logs (requires PM2 in platform dir). |
| `clikdeploy worker clear` | Clear waiting jobs from the deployment queue. |

---

## Examples

```bash
# Log in and deploy current repo
clikdeploy login
clikdeploy deploy

# Deploy from marketplace
clikdeploy marketplace deploy n8n

# Deploy a Docker image
clikdeploy docker deploy redis:alpine my-redis -e MAXMEMORY=256mb

# Deploy from GitHub URL
clikdeploy github deploy https://github.com/heroku/node-js-getting-started

# Add a server and list apps
clikdeploy servers add prod 34.1.2.3
clikdeploy apps list
clikdeploy status my-app
```

---

## Help

- `clikdeploy --help` – list all commands
- `clikdeploy <command> --help` – options for a command (e.g. `clikdeploy deploy --help`)
- `clikdeploy apps --help` – apps subcommands
- `clikdeploy servers --help` – servers subcommands

For more about the platform and dashboard, see [ClikDeploy](https://clikdeploy.com).
