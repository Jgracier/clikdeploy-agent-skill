import Conf from 'conf';
import ora from 'ora';
import chalk from 'chalk';
import { getApiClient, requireAuth } from '../utils/api';
import { resolveApp } from '../utils/app-resolver';
import { Formatters } from '../ui/formatters';

function findServerByIdentifier(servers: any[], identifier: string): any | null {
  const raw = String(identifier || '').trim();
  if (!raw) return null;
  const lower = raw.toLowerCase();
  return (
    servers.find((s) => String(s.id || '').toLowerCase() === lower) ||
    servers.find((s) => String(s.name || '').toLowerCase() === lower) ||
    null
  );
}

export async function transferAppCommand(
  config: Conf,
  appIdentifier: string,
  targetServerIdentifier: string,
  mode: 'clone' | 'move'
) {
  requireAuth(config);

  if (!appIdentifier || !targetServerIdentifier) {
    Formatters.error('Usage: clikdeploy apps <clone|move> <app> <target-server>');
    return;
  }

  const api = getApiClient(config, 30 * 60 * 1000);

  const [resolvedApp, servers] = await Promise.all([
    resolveApp(api, appIdentifier),
    api.getServers(),
  ]);

  if (!resolvedApp?.app) {
    Formatters.error(`App not found: ${appIdentifier}`);
    return;
  }

  const targetServer = findServerByIdentifier(servers, targetServerIdentifier);
  if (!targetServer) {
    Formatters.error(`Target server not found: ${targetServerIdentifier}`);
    return;
  }

  const spinner = ora(
    `${mode === 'move' ? 'Moving' : 'Cloning'} ${resolvedApp.app.name} to ${targetServer.name}...`
  ).start();

  try {
    const { data } = await api
      .getClient()
      .post(`/api/gate/apps/${resolvedApp.app.id}/transfer`, {
        targetServerId: targetServer.id,
        mode,
        deployAfterClone: true,
      });

    const payload = data?.data;
    spinner.succeed(
      `${mode === 'move' ? 'Move complete' : 'Clone started'}: ${chalk.cyan(
        payload?.targetAppId || 'unknown-target-app'
      )}`
    );

    if (payload?.deploymentId) {
      console.log(
        chalk.gray('Deployment:'),
        chalk.cyan(payload.deploymentId),
        chalk.gray(`(${payload.status})`)
      );
    }
    if (payload?.move?.nextStep) {
      console.log(chalk.gray('Next:'), payload.move.nextStep);
    }
  } catch (error: any) {
    spinner.fail(`${mode === 'move' ? 'Move' : 'Clone'} failed`);
    Formatters.error(error?.response?.data?.error || error?.message || 'Unknown error');
  }
}
