/**
 * Deploy from a GitHub repository URL.
 * Creates an app with the given URL and triggers deployment.
 */
import ora from 'ora';
import Conf from 'conf';
import { getApiClient, requireAuth } from '../utils/api';
import chalk from 'chalk';
import { waitForDeployment } from '../services/deploy.service';
import { deriveGithubAppName, resolveDeployServer } from '../utils/deploy-normalizer';
import { displayId } from '../utils/id-format';
import { emitDeployServerResolutionError, emitJson } from '../utils/structured-output';

const DEFAULT_BRANCH = 'main';

export interface DeployFromUrlOptions {
  name?: string;
  server?: string;
  branch?: string;
  wait?: boolean;
}

export async function deployFromUrl(
  config: Conf,
  url: string,
  options: DeployFromUrlOptions = {}
) {
  requireAuth(config);

  const trimmedUrl = url?.trim();
  if (!trimmedUrl) {
    emitJson({
      status: 'invalid_input',
      command: 'clikdeploy github deploy',
      message: 'Please provide a GitHub URL (e.g. https://github.com/owner/repo or owner/repo)',
      usage: 'clikdeploy github deploy <github-url-or-owner/repo> [--server <name-or-id>]',
    });
    return;
  }

  const api = getApiClient(config, 60000);

  try {
    const { server, selectedBy } = await resolveDeployServer(api as any, options.server, {
      preferFirstIfMultiple: false,
    });
    const serverId = server.id;
    if (selectedBy !== 'explicit') {
      console.log(chalk.gray(`Using server: ${chalk.cyan(server.name || server.id)}`));
    }

    const appName = options.name || deriveGithubAppName(trimmedUrl);
    const branch = options.branch || DEFAULT_BRANCH;

    console.log(chalk.bold('\n🚀 Deploy from GitHub\n'));
    console.log(`  ${chalk.gray('URL:')}    ${chalk.cyan(trimmedUrl)}`);
    console.log(`  ${chalk.gray('Name:')}   ${chalk.cyan(appName)}`);
    console.log(`  ${chalk.gray('Branch:')} ${chalk.cyan(branch)}`);
    console.log();

    const spinner = ora('Creating app and starting deployment...').start();

    const result = await api.createAppWithDeployment({
      name: appName,
      serverId,
      githubUrl: trimmedUrl,
      githubBranch: branch,
    });
    const app = result?.app;
    const deployment = result?.deployment;

    if (!app?.id) {
      spinner.fail('Failed to create app');
      console.log(chalk.red('No app returned'));
      return;
    }

    spinner.succeed(`App created: ${chalk.cyan(app.name)} (${displayId(app.id)})`);

    if (deployment?.id) {
      console.log(chalk.gray(`Deployment: ${displayId(deployment.id)}`));
      if (options.wait !== false) {
        const spinner = ora('Deploying...').start();
        const result = await waitForDeployment(api, app.id, deployment.id, (elapsed, status) => {
          if (status === 'SUCCESS') spinner.succeed(`Deployed in ${elapsed}s`);
          else if (status === 'FAILED') spinner.fail(`Deployment failed after ${elapsed}s`);
          else spinner.text = `Deploying... (${elapsed}s)`;
        });
        if (result.success) {
          const deployments = await api.getAppDeployments(app.id);
          const d = deployments?.find((x: any) => x.id === deployment.id);
          if (d?.metadata?.url) console.log(chalk.green('🌐 '), chalk.cyan(d.metadata.url));
        } else if (!result.success) {
          const err = 'error' in result ? result.error : undefined;
          if (err) {
            console.log(chalk.red(err));
            process.exit(1);
          }
        }
      } else {
        console.log(chalk.gray('Run'), chalk.cyan(`clikdeploy status ${app.name}`), chalk.gray('to check progress'));
      }
    } else {
      console.log(chalk.yellow('Deployment may have been queued; check dashboard or run clikdeploy status'));
    }
  } catch (err: any) {
    if (emitDeployServerResolutionError(err, 'clikdeploy github deploy', { url: trimmedUrl })) return;
    const msg = err.response?.data?.error || err.message || 'Unknown error';
    console.log(chalk.red('\nDeploy failed:'), msg);
    if (err.response?.data?.details) {
      console.log(chalk.gray(JSON.stringify(err.response.data.details)));
    }
    process.exit(1);
  }
}

/** Deploy multiple GitHub URLs (creates apps and queues deployments). */
export async function deployFromUrlBatch(
  config: Conf,
  urls: string[],
  options: DeployFromUrlOptions & { wait?: boolean } = {}
) {
  requireAuth(config);
  const trimmed = urls.map(u => u?.trim()).filter(Boolean);
  if (!trimmed.length) {
    emitJson({
      status: 'clarification_required',
      command: 'clikdeploy github deploy',
      reason: 'missing_github_url',
      message: 'Provide at least one GitHub URL.',
      options: {
        usage: 'clikdeploy github deploy <github-url-or-owner/repo> [--server <name-or-id>]',
        example: 'clikdeploy github deploy https://github.com/heroku/node-js-getting-started',
      },
    });
    return;
  }
  const wait = options.wait !== false;
  if (trimmed.length === 1) {
    return deployFromUrl(config, trimmed[0], { ...options, wait });
  }
  console.log(chalk.bold(`\n🚀 Deploying ${trimmed.length} app(s) from GitHub\n`));
  for (let i = 0; i < trimmed.length; i++) {
    console.log(chalk.cyan(`  [${i + 1}/${trimmed.length}] ${deriveGithubAppName(trimmed[i])}`));
  }
  console.log();
  for (const url of trimmed) {
    await deployFromUrl(config, url, { ...options, wait: false });
  }
  if (!wait) {
    console.log(chalk.gray('Run'), chalk.cyan('clikdeploy watch'), chalk.gray('or'), chalk.cyan('clikdeploy apps list'), chalk.gray('to check progress'));
  }
}
