import ora from 'ora';
import Conf from 'conf';
import { getApiClient, requireAuth } from '../utils/api';
import { Formatters } from '../ui/formatters';
import chalk from 'chalk';
import { Prompts } from '../ui/prompts';
import { delay } from '../utils/delay';
import { waitForDeployment as waitForDeploymentService } from '../services/deploy.service';
import {
  deriveDockerAppName,
  parseEnvVarPairs,
  resolveDeployServer,
} from '../utils/deploy-normalizer';
import { displayId } from '../utils/id-format';
import { emitDeployServerResolutionError, emitJson } from '../utils/structured-output';

/**
 * Docker Image Deployment Commands
 * Deploy any Docker image from Docker Hub or other registries
 */

interface DockerDeployOptions {
  server?: string;
  port?: number;
  env?: string[];
  wait?: boolean;
}

export async function deployDockerImage(
  config: Conf, 
  imageName: string, 
  appName?: string,
  options: DockerDeployOptions = {}
) {
  requireAuth(config);

  if (!imageName) {
    emitJson({
      status: 'invalid_input',
      command: 'clikdeploy docker deploy',
      message: 'Please specify a Docker image',
      usage: 'clikdeploy docker deploy <image> [app-name] [--server <name-or-id>]',
    });
    return;
  }

  // If no app name provided, generate from image name
  if (!appName) {
    appName = deriveDockerAppName(imageName);
    console.log(chalk.gray(`Generated app name: ${chalk.cyan(appName)}`));
  }

  const api = getApiClient(config);

  try {
    const { server: selectedServer, selectedBy } = await resolveDeployServer(api as any, options.server, {
      preferFirstIfMultiple: false,
    });
    if (selectedBy === 'single') {
      console.log(chalk.gray(`Using server: ${chalk.cyan(selectedServer.name || selectedServer.id)}`));
    } else if (selectedBy === 'first') {
      console.log(
        chalk.gray(
          `Using server: ${chalk.cyan(selectedServer.name || selectedServer.id)} (first available)`
        )
      );
    }
    const serverId = selectedServer.id as string;

    const environmentVariables = parseEnvVarPairs(options.env);

    // Optional explicit port. If omitted, backend auto/default handling applies.
    const explicitPort =
      options.port !== undefined && options.port !== null && `${options.port}`.trim() !== ''
        ? parseInt(options.port.toString(), 10)
        : undefined;
    if (explicitPort !== undefined && (!Number.isFinite(explicitPort) || explicitPort < 1 || explicitPort > 65535)) {
      Formatters.error(`Invalid port: ${options.port}`);
      return;
    }
    
    console.log(chalk.bold('\n🐳 Deploying Docker Image\n'));
    console.log(`  ${chalk.gray('Image:')}  ${chalk.cyan(imageName)}`);
    console.log(`  ${chalk.gray('Name:')}   ${chalk.cyan(appName)}`);
    console.log(
      `  ${chalk.gray('Port:')}   ${chalk.cyan(
        explicitPort !== undefined ? explicitPort : 'auto'
      )}`
    );
    if (Object.keys(environmentVariables).length > 0) {
      console.log(`  ${chalk.gray('Env:')}    ${chalk.cyan(Object.keys(environmentVariables).length)} variable(s)`);
    }
    console.log();

    const spinner = ora('Creating deployment...').start();

    const appBody: Record<string, unknown> = {
      name: appName,
      dockerImage: imageName,
      serverId,
    };
    if (explicitPort !== undefined) appBody.port = explicitPort;
    if (Object.keys(environmentVariables).length > 0) appBody.environmentVariables = environmentVariables;
    const appData = await api.createAppWithDeployment(appBody);
    const app = appData?.app;
    const deployment = appData?.deployment;

    spinner.succeed('Deployment started!');

    console.log();
    console.log(`   ${chalk.gray('App ID:')}      ${chalk.cyan(displayId(app.id))}`);
    console.log(`   ${chalk.gray('Deployment:')}  ${chalk.cyan(displayId(deployment.id))}`);
    console.log(`   ${chalk.gray('Status:')}      ${chalk.yellow('DEPLOYING')}`);
    console.log();

    // Wait for completion if requested (streams full deployment logs from server)
    if (options.wait !== false && deployment?.id) {
      const spinner = ora('Detecting requirements...').start();
      const result = await waitForDeploymentService(api, app.id, deployment.id, (elapsed, status) => {
        if (status === 'SUCCESS') spinner.succeed(`Deployed in ${elapsed}s`);
        else if (status === 'FAILED') spinner.fail(`Deployment failed after ${elapsed}s`);
        else spinner.text = `Deploying... (${elapsed}s)`;
      });
      if (result.success) {
        const deployments = await api.getAppDeployments(app.id);
        const d = deployments?.find((x: any) => x.id === deployment.id);
        if (d?.metadata?.databaseType) console.log(chalk.green('✓ Detected:'), `${d.metadata.databaseType} database`);
        if (d?.metadata?.needsRedis) console.log(chalk.green('✓ Detected:'), 'Redis cache');
        const appInfo = await api.getApp(app.id);
        if (appInfo?.domain) {
          console.log();
          console.log(chalk.green('🌐 Live at:'), chalk.cyan(`https://${appInfo.domain}`));
        }
        console.log();
        console.log(chalk.gray('Manage app:'), chalk.cyan(`clikdeploy apps show ${appInfo?.name ?? appName}`));
      } else if (!result.success) {
        const err = 'error' in result ? result.error : undefined;
        if (err) {
          console.log(chalk.red(`\nError: ${err}`));
          console.log(chalk.gray('View logs:'), chalk.cyan(`clikdeploy apps logs ${appName}`));
          process.exit(1);
        }
      }
    } else {
      console.log(chalk.gray('Run'), chalk.cyan(`clikdeploy status ${appName}`), chalk.gray('to check progress'));
    }
  } catch (error: any) {
    if (emitDeployServerResolutionError(error, 'clikdeploy docker deploy', { image: imageName })) return;
    Formatters.error('Deployment failed');
    Formatters.gray(error.response?.data?.error || error.message);
    process.exit(1);
  }
}

export async function listDockerImages(config: Conf, searchTerm?: string) {
  requireAuth(config);

  console.log(chalk.bold('\n🐳 Non-Marketplace Apps\n'));

  const api = getApiClient(config);

  try {
    const apps = await api.getApps() || [];

    // Filter for non-marketplace apps (those with dockerImage but no marketplace metadata)
    const dockerApps = apps.filter((app: any) => 
      app.dockerImage && !app.metadata?.marketplaceId
    );

    if (dockerApps.length === 0) {
      console.log(chalk.yellow('No Docker apps deployed yet\n'));
      console.log(chalk.gray('Deploy one:'), chalk.cyan('clikdeploy docker deploy <image>\n'));
      return;
    }

    // Filter by search term if provided
    const filteredApps = searchTerm 
      ? dockerApps.filter((app: any) => 
          app.name.includes(searchTerm) || 
          app.dockerImage.includes(searchTerm)
        )
      : dockerApps;

    if (filteredApps.length === 0) {
      console.log(chalk.yellow(`No apps matching "${searchTerm}"\n`));
      return;
    }

    for (const app of filteredApps) {
      const statusColor = app.status === 'RUNNING' ? chalk.green : 
                         app.status === 'FAILED' ? chalk.red : chalk.yellow;
      
      console.log(`  ${chalk.cyan(app.name.padEnd(25))} ${statusColor(app.status.padEnd(10))} ${chalk.gray(app.dockerImage)}`);
      
      if (app.domain) {
        console.log(`    ${chalk.gray('└─')} ${chalk.cyan(`https://${app.domain}`)}`);
      }
    }

    console.log();
    console.log(chalk.gray(`Total: ${filteredApps.length} app(s)\n`));
  } catch (error: any) {
    Formatters.error('Failed to list apps');
    Formatters.gray(error.response?.data?.error || error.message);
  }
}
