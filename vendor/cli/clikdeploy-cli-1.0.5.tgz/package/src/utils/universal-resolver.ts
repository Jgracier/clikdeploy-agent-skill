import { resolveApp } from './app-resolver';
import { resolveServer } from './server-resolver';

export type ResolvedTarget =
    | { type: 'app'; app: any; server: any }
    | { type: 'server'; server: any };

/**
 * Universal Resolver
 * Tries to find a target by name/ID, checking apps first, then servers.
 */
export async function resolveTarget(api: any, identifier: string): Promise<ResolvedTarget | null> {
    if (!identifier) return null;

    // 1. Try resolving as app (and handle "server app" pattern)
    try {
        const appResolved = await resolveApp(api, identifier);
        if (appResolved) {
            return { type: 'app', app: appResolved.app, server: appResolved.server };
        }
    } catch {
        // Fall through
    }

    // 2. Try resolving as server
    try {
        const serverResolved = await resolveServer(api, identifier);
        if (serverResolved) {
            return { type: 'server', server: serverResolved };
        }
    } catch {
        // Fall through
    }

    return null;
}
