import chalk from 'chalk';
import { Formatters } from '../ui/formatters';

/**
 * App Resolver Utility
 * 
 * Resolves apps by name/ID with optional server filtering.
 * Supports two patterns:
 * 1. <server> <app> - Find app by server and name/ID
 * 2. <app> - Find app by name/ID (backwards compatible)
 */

export interface ResolvedApp {
  app: any;
  server: any;
}

interface ResolutionData {
  allApps: any[];
  allServers: any[];
  serversByKey: Map<string, any>;
  appsByServerId: Map<string, any[]>;
  appsById: Map<string, any>;
  appsByName: Map<string, any[]>;
}

function findByIdOrName(data: ResolutionData, identifierRaw: string): any | null {
  const identifier = normalize(identifierRaw);
  if (!identifier) return null;

  const exactId = data.appsById.get(identifier);
  if (exactId) return exactId;

  const exactName = data.appsByName.get(identifier)?.[0];
  if (exactName) return exactName;

  const idPrefixMatches = data.allApps.filter((app) => normalize(app.id).startsWith(identifier));
  if (idPrefixMatches.length === 1) return idPrefixMatches[0];

  return null;
}

/**
 * Parse app identifier into server and app components.
 * Supports:
 * - "appName" -> { server: null, app: "appName" }
 * - "serverName appName" -> { server: "serverName", app: "appName" }
 * - "app-id" -> { server: null, app: "app-id" }
 */
export function parseAppIdentifier(identifier: string): { server: string | null; app: string } {
  const parts = identifier.trim().split(/\s+/);
  
  if (parts.length === 1) {
    // Just app name/ID
    return { server: null, app: parts[0] };
  }
  
  if (parts.length === 2) {
    // Server and app
    return { server: parts[0], app: parts[1] };
  }
  
  // More than 2 parts - treat as app name with spaces (edge case)
  return { server: null, app: identifier };
}

function normalize(value: string | null | undefined): string {
  return (value ?? '').trim().toLowerCase();
}

function buildResolutionData(allApps: any[], allServers: any[] = []): ResolutionData {
  const serversByKey = new Map<string, any>();
  for (const server of allServers) {
    const keys = [server.id, server.name, server.ipAddress].map((v) => normalize(v));
    for (const key of keys) {
      if (key) serversByKey.set(key, server);
    }
  }

  const appsByServerId = new Map<string, any[]>();
  const appsById = new Map<string, any>();
  const appsByName = new Map<string, any[]>();
  for (const app of allApps) {
    const serverId = normalize(app.serverId || app.server?.id);
    if (serverId) {
      const arr = appsByServerId.get(serverId) ?? [];
      arr.push(app);
      appsByServerId.set(serverId, arr);
    }
    const appId = normalize(app.id);
    if (appId) appsById.set(appId, app);
    const appName = normalize(app.name);
    if (appName) {
      const arr = appsByName.get(appName) ?? [];
      arr.push(app);
      appsByName.set(appName, arr);
    }
  }

  return { allApps, allServers, serversByKey, appsByServerId, appsById, appsByName };
}

function resolveAppFromData(
  data: ResolutionData,
  appIdentifier: string,
  showErrors: boolean
): ResolvedApp | null {
  const { server: serverNameOrIdRaw, app: appNameOrIdRaw } = parseAppIdentifier(appIdentifier);
  const serverNameOrId = normalize(serverNameOrIdRaw);
  const appNameOrId = normalize(appNameOrIdRaw);

  if (!serverNameOrId) {
    const app = findByIdOrName(data, appNameOrIdRaw);
    if (!app) return null;
    return { app, server: app.server };
  }

  const targetServer = data.serversByKey.get(serverNameOrId);
  if (!targetServer) {
    // If "<word> <word>" was actually a multi-word app name, resolve it directly.
    const fallback = findByIdOrName(data, appIdentifier);
    if (fallback) return { app: fallback, server: fallback.server };
    if (showErrors) Formatters.error(`Server "${serverNameOrId}" not found`);
    return null;
  }

  const serverApps = data.appsByServerId.get(targetServer.id) ?? [];
  const app = serverApps.find((a: any) => {
    const appId = normalize(a.id);
    return normalize(a.name) === appNameOrId || appId === appNameOrId || appId.startsWith(appNameOrId);
  });
  if (!app) {
    if (showErrors) {
      Formatters.error(`App "${appNameOrId}" not found on server "${targetServer.name}"`);
    }
    return null;
  }

  return { app, server: targetServer };
}

/**
 * Find app by name/ID with optional server filtering.
 * 
 * @param api - API client
 * @param appIdentifier - App name/ID or "server app" string
 * @returns Resolved app object with server info
 */
export async function resolveApp(api: any, appIdentifier: string): Promise<ResolvedApp | null> {
  const parsed = parseAppIdentifier(appIdentifier);
  const allApps = await api.getApps();
  const allServers = parsed.server ? await api.getServers() : [];
  const data = buildResolutionData(allApps, allServers);
  return resolveAppFromData(data, appIdentifier, true);
}

/**
 * Resolve multiple apps with optional server filtering.
 * Supports mixed input:
 * - ["app1", "app2"] -> find both apps
 * - ["server1 app1", "server2 app2"] -> find apps on specific servers
 * 
 * @param api - API client
 * @param identifiers - Array of app identifiers
 * @param options - Options for resolution
 * @returns Array of resolved apps
 */
export async function resolveApps(
  api: any, 
  identifiers: string[],
  options: { allowPartial?: boolean } = {}
): Promise<ResolvedApp[]> {
  const allApps = await api.getApps();
  const needsServers = identifiers.some((identifier) => parseAppIdentifier(identifier).server);
  const allServers = needsServers ? await api.getServers() : [];
  const data = buildResolutionData(allApps, allServers);

  const results: ResolvedApp[] = [];
  const failed: string[] = [];
  
  for (const identifier of identifiers) {
    const resolved = resolveAppFromData(data, identifier, true);
    if (resolved) {
      results.push(resolved);
    } else {
      failed.push(identifier);
    }
  }
  
  if (failed.length > 0 && !options.allowPartial) {
    Formatters.error(`Failed to resolve: ${failed.join(', ')}`);
    if (results.length === 0) {
      return [];
    }
  }
  
  return results;
}

/**
 * Show disambiguation hint when multiple apps with the same name exist.
 */
export function showDisambiguationHint(appName: string, apps: any[]) {
  const serversWithApp = apps
    .filter((a: any) => a.name === appName)
    .map((a: any) => a.server?.name || 'unknown');
  
  if (serversWithApp.length > 1) {
    console.log(chalk.yellow(`\n⚠️  Multiple apps named "${appName}" found on different servers:`));
    serversWithApp.forEach((serverName: string) => {
      console.log(chalk.gray(`   - ${serverName} ${appName}`));
    });
    console.log(chalk.gray(`\nUse: ${chalk.cyan(`clikdeploy apps <command> <server> <app>`)}`));
    console.log(chalk.gray(`Example: ${chalk.cyan(`clikdeploy apps logs ${serversWithApp[0]} ${appName}`)}\n`));
  }
}
