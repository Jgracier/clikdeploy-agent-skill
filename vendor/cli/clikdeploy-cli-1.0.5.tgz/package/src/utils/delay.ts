/**
 * Promise-based delay. Use instead of duplicating sleep() across commands.
 */
export function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
