/**
 * Single API access: re-export ApiClient and return it from getApiClient.
 * All commands use ApiClient (or api.getClient() for one-off endpoints).
 */
export { ApiClient } from '../api/client';
import { ApiClient as ApiClientClass } from '../api/client';
import Conf from 'conf';

export function getApiUrl(config: Conf): string {
  return ApiClientClass.getApiUrl(config);
}

export function getApiClient(config: Conf, timeout?: number): ApiClientClass {
  return new ApiClientClass(config, timeout);
}

export function requireAuth(config: Conf): void {
  return ApiClientClass.requireAuth(config);
}

export function setApiUrl(config: Conf, url: string): void {
  return ApiClientClass.setApiUrl(config, url);
}

