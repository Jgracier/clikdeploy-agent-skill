const SUPPRESSED_CONTAINER_LOG_PATTERNS: RegExp[] = [
  /Error response from daemon: No such container:/i,
  /cp: overwrite ['"].+['"]\?/i,
  /"GET \/ HTTP\/1\.1" 200 .*"curl\//i,
];

export type DeployLogShapeState = {
  lastContainerLineCount: number;
  lastEmittedContainerLine: string;
};

export function createDeployLogShapeState(): DeployLogShapeState {
  return {
    lastContainerLineCount: 0,
    lastEmittedContainerLine: '',
  };
}

export function shouldSuppressContainerLine(line: string): boolean {
  const trimmed = line.trim();
  if (!trimmed) return true;
  return SUPPRESSED_CONTAINER_LOG_PATTERNS.some((pattern) => pattern.test(trimmed));
}

export function shapeContainerLogChunk(
  raw: string,
  state: DeployLogShapeState
): { lines: string[]; nextLineCount: number } {
  const sourceLines = raw ? raw.split('\n') : [];
  const emitted: string[] = [];

  if (sourceLines.length <= state.lastContainerLineCount) {
    return { lines: emitted, nextLineCount: sourceLines.length };
  }

  for (let i = state.lastContainerLineCount; i < sourceLines.length; i++) {
    const line = sourceLines[i] ?? '';
    const trimmed = line.trim();
    if (shouldSuppressContainerLine(line)) continue;
    if (trimmed === state.lastEmittedContainerLine) continue;
    emitted.push(line);
    state.lastEmittedContainerLine = trimmed;
  }

  return {
    lines: emitted,
    nextLineCount: sourceLines.length,
  };
}
