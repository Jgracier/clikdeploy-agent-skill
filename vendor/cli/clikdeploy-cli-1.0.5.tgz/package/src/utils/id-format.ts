export function displayId(id: string | undefined | null, length = 12): string {
  const value = String(id || '');
  return value.length > length ? value.slice(0, length) : value;
}

export function buildUniqueDisplayIds(
  ids: Array<string | undefined | null>,
  minLength = 12,
  maxLength = 24
): Map<string, string> {
  const source = ids
    .map((id) => String(id || ''))
    .filter(Boolean);
  const unique = Array.from(new Set(source));
  const result = new Map<string, string>();
  if (unique.length === 0) return result;

  let length = minLength;
  while (length <= maxLength) {
    const buckets = new Map<string, string[]>();
    for (const id of unique) {
      const key = displayId(id, length);
      const bucket = buckets.get(key) || [];
      bucket.push(id);
      buckets.set(key, bucket);
    }
    const hasCollision = Array.from(buckets.values()).some((bucket) => bucket.length > 1);
    if (!hasCollision || length === maxLength) {
      for (const id of unique) {
        result.set(id, displayId(id, length));
      }
      return result;
    }
    length += 2;
  }

  for (const id of unique) {
    result.set(id, displayId(id, maxLength));
  }
  return result;
}
