import { createServer, Server } from 'net';

/**
 * Find an available port starting from a base port
 * Automatically tries next ports if the base port is in use
 * Uses dynamic/private port range (49152-65535) to avoid conflicts
 */
export async function findAvailablePort(basePort: number = 49152): Promise<number> {
  return new Promise((resolve, reject) => {
    let currentPort = basePort;
    const maxPort = 65535;
    const maxAttempts = 100; // Try up to 100 ports
    let attempts = 0;

    const tryPort = (port: number): void => {
      if (attempts >= maxAttempts) {
        reject(new Error(`Could not find an available port after ${maxAttempts} attempts`));
        return;
      }

      const server: Server = createServer();
      
      server.listen(port, () => {
        // Port is available
        server.close(() => {
          resolve(port);
        });
      });

      server.on('error', (err: NodeJS.ErrnoException) => {
        if (err.code === 'EADDRINUSE') {
          // Port is in use, try next one
          attempts++;
          currentPort++;
          if (currentPort > maxPort) {
            // Wrap around to start of dynamic range
            currentPort = 49152;
          }
          tryPort(currentPort);
        } else {
          reject(err);
        }
      });
    };

    tryPort(currentPort);
  });
}

