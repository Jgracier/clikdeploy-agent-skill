#!/usr/bin/env node

/**
 * ClikDeploy CLI
 * Philosophy: Dead simple. Autonomous by default. No prompts, no confirmations.
 * 
 * Commands:
 *   login              - Authenticate with ClikDeploy
 *   deploy [target]    - Universal Deploy (Folder, GitHub URL, Image, or App Name)
 *   apps list/delete   - Manage your deployed applications
 *   servers list/add   - Manage your server infrastructure
 */

import { Command } from 'commander';
import chalk from 'chalk';
import Conf from 'conf';
import { login, loginUrl, logout, whoami, signup } from './commands/auth';
import { listNotifications, clearNotifications } from './commands/notifications';
import { init } from './commands/init';
import { deploy } from './commands/deploy';
import { status, logs } from './commands/status';
import { watchDeployments } from './commands/watch';
import { deployMarketplace, deleteApp, listMarketplace, checkStatus } from './commands/marketplace';
import { runConnect } from './commands/server-connect';
import { deployDockerImage, listDockerImages } from './commands/docker';
import { deployFromUrlBatch } from './commands/github';
import { workerStatus, workerStart, workerRestart, workerLogs, workerClear } from './commands/worker';
import { configCommand } from './commands/config';
import { runTestingFramework, runDockerSimulationSuite } from './commands/test';
import { restart, stop, start, deleteCommand } from './commands/ops';
import { CLI_API_URL_OVERRIDE_ENV, normalizeApiUrl } from './constants';
import { registerAppsTool } from './tools/apps-tool';
import { registerServersTool } from './tools/servers-tool';

const config = new Conf({ projectName: 'clikdeploy' });
const program = new Command();
const CLI_VERSION = (() => {
  try {
    return String(require('../package.json')?.version || '0.0.0');
  } catch {
    return '0.0.0';
  }
})();

function describeCliError(error: any): string {
  return (
    error?.response?.data?.error ||
    error?.response?.data?.message ||
    error?.message ||
    'Unknown error'
  );
}

function handleCommandError(error: any): void {
  console.error(chalk.red(describeCliError(error)));
  process.exitCode = 1;
}

// ASCII Art Banner
const banner = `
${chalk.cyan('╔═══════════════════════════════════════╗')}
${chalk.cyan('║')}  ${chalk.bold.white('⚡ ClikDeploy CLI')}               ${chalk.cyan('║')}
${chalk.cyan('║')}  ${chalk.gray('Deploy First, Configure Later')}      ${chalk.cyan('║')}
${chalk.cyan('╚═══════════════════════════════════════╝')}
`;

program
  .name('clikdeploy')
  .description('Deploy apps with one command - autonomous by default, simple by design')
  .version(CLI_VERSION)
  .option('--api-url <url>', 'Use API URL for this command only (does not save config)')
  .hook('preAction', () => {
    // Show banner on first use
    if (!config.get('seenBanner')) {
      console.log(banner);
      config.set('seenBanner', true);
    }

    const runtimeApiUrl = program.opts().apiUrl as string | undefined;
    if (runtimeApiUrl) {
      process.env[CLI_API_URL_OVERRIDE_ENV] = normalizeApiUrl(runtimeApiUrl);
    } else {
      delete process.env[CLI_API_URL_OVERRIDE_ENV];
    }
  });

// Auth commands
program
  .command('login')
  .description('Authenticate with ClikDeploy')
  .option('--google', 'Use Google OAuth')
  .option('--github', 'Use GitHub OAuth')
  .option('--return-url', 'Print auth URL instead of opening browser (device flow for agents/skills)')
  .option('--exchange <code\>', 'Exchange one-time code for API key')
  .action((options) => login(config, options));

program
  .command('login-url')
  .description('Return OAuth URL JSON for Google or GitHub (no browser launch)')
  .option('--google', 'Use Google OAuth (default)')
  .option('--github', 'Use GitHub OAuth')
  .action((options) => loginUrl(config, options));

program
  .command('signup')
  .description('Create a new account')
  .action(() => signup(config));

program
  .command('logout')
  .description('Log out of ClikDeploy')
  .action(() => logout(config));

program
  .command('whoami')
  .description('Show current authenticated user')
  .option('--json', 'Output results as JSON')
  .action((options) => whoami(config, options));

program
  .command('config [key] [value]')
  .description(
    'Get or set config (e.g. config api-url https://clikdeploy.com, config assistant-mode auto)'
  )
  .action((key, value) => configCommand(config, key, value));

// Init command
program
  .command('init')
  .description('Initialize a new project in current directory')
  .action(() => init(config));

// Deploy command (the star of the show)
program
  .command('deploy [appName]')
  .description('Deploy from GitHub URL, Docker image, or Docker Hub app-name lookup (or current directory if no name given)')
  .option('-s, --server <id>', 'Deploy to specific server')
  .option('-b, --branch <branch>', 'Deploy specific branch')
  .option('-m, --message <msg>', 'Deployment message')
  .option('--no-wait', 'Don\'t wait for deployment to complete')
  .action((appName, options) => deploy(config, appName, options));

program
  .command('list')
  .description('Return a structured JSON list of all apps and servers')
  .action(() => status(config).catch(handleCommandError));

// Status commands
program
  .command('status')
  .description('Check status of an app or server')
  .argument('[target]', 'App or server name/ID')
  .action((target) => status(config, target).catch(handleCommandError));

program
  .command('logs')
  .description('View app logs')
  .argument('[app]', 'App name or ID')
  .option('-f, --follow', 'Follow log output')
  .option('-n, --lines <n>', 'Number of lines to show', '100')
  .action((app, options) => logs(config, app, options));

program
  .command('restart')
  .description('Restart an app')
  .argument('<app>', 'App name or ID')
  .action((app) => restart(config, app));

program
  .command('stop')
  .description('Stop an app')
  .argument('<app>', 'App name or ID')
  .action((app) => stop(config, app));

program
  .command('start')
  .description('Start an app')
  .argument('<app>', 'App name or ID')
  .action((app) => start(config, app));

program
  .command('delete')
  .description('Delete an app or server')
  .argument('<target>', 'Name or ID to delete')
  .option('--yes', 'Skip confirmation')
  .action((target, options) => deleteCommand(config, target, options));

program
  .command('connect')
  .description('Connect a new server or device (returns available methods as JSON by default)')
  .option('-i, --interactive', 'Run the interactive connection wizard')
  .action((options) => runConnect(config, options));

program
  .command('watch')
  .description('Watch deployments in real-time')
  .option('-i, --interval <ms>', 'Refresh interval in milliseconds', '3000')
  .option('-f, --filter <status>', 'Filter by status (deploying, error, running)')
  .action((options) => watchDeployments(config, {
    interval: options.interval ? parseInt(options.interval) : undefined,
    filter: options.filter
  }));

registerAppsTool(program, config);
registerServersTool(program, config);

// Marketplace commands
const marketplace = program
  .command('marketplace')
  .description('Deploy apps from marketplace');

marketplace
  .command('deploy <apps...>')
  .description('Deploy marketplace app(s) (e.g., n8n ghost vaultwarden)')
  .option('-s, --server <name>', 'Deploy to specific server')
  .option('-c, --concurrency <n>', 'Max concurrent deploy starts (default: 4)')
  .option('--no-wait', 'Don\'t wait for deployment to complete')
  .action((apps, options) => deployMarketplace(config, apps, options));

marketplace
  .command('delete <appIds...>')
  .description('Delete app(s) (e.g., clikdeploy marketplace delete app1 app2 app3)')
  .action((appIds) => deleteApp(config, appIds));

marketplace
  .command('list')
  .description('List available marketplace apps')
  .action(() => listMarketplace(config));

marketplace
  .command('status <appId>')
  .description('Check app status')
  .action((appId) => checkStatus(config, appId));

// Docker commands (non-marketplace apps)
const docker = program
  .command('docker')
  .description('Deploy any Docker image (non-marketplace)');

docker
  .command('deploy <image> [name]')
  .description('Deploy a Docker image (e.g., redis:latest my-cache)')
  .option('-s, --server <name>', 'Deploy to specific server')
  .option('-p, --port <port>', 'Application port')
  .option('-e, --env <KEY=VALUE>', 'Environment variable (can be specified multiple times)', (val, prev) => [...(prev || []), val], [])
  .option('--no-wait', 'Don\'t wait for deployment to complete')
  .action((image, name, options) => deployDockerImage(config, image, name, options));

docker
  .command('list [search]')
  .description('List deployed Docker apps')
  .action((search) => listDockerImages(config, search));

// Worker commands - simple management
const worker = program
  .command('worker')
  .description('Manage deployment workers');

worker
  .command('status')
  .description('Check worker status')
  .action(() => workerStatus(config));

worker
  .command('start')
  .description('Start the deployment worker (PM2 or background)')
  .action(() => workerStart(config));

worker
  .command('restart')
  .description('Restart worker')
  .action(() => workerRestart(config));

worker
  .command('logs')
  .description('View worker logs')
  .action(() => workerLogs(config));

worker
  .command('clear')
  .description('Clear waiting jobs from the deployment queue')
  .option('--active', 'Also clear active jobs (force-clear all)')
  .action((opts) => workerClear(config, opts));

// GitHub deploy
const github = program
  .command('github')
  .description('Deploy from GitHub repository URL(s)');

github
  .command('deploy <urls...>')
  .description('Deploy one or more GitHub repos (e.g. clikdeploy github deploy https://github.com/owner/repo)')
  .option('-s, --server <id>', 'Deploy to specific server')
  .option('-b, --branch <branch>', 'Branch to deploy', 'main')
  .option('--no-wait', 'Do not wait for each deployment to complete')
  .action((urls, options) => deployFromUrlBatch(config, urls, { server: options.server, branch: options.branch, wait: options.wait !== false }));

// Admin testing framework
program
  .command('test [subcommand]')
  .description('Testing commands (admin mass simulation + local docker simulation)')
  .option('--scale <n>', 'Number of scenarios to run (1-10000)', '1000')
  .option('--concurrency <n>', 'Parallel scenario workers (1-500)', '50')
  .option('--seed <n>', 'Deterministic seed')
  .option('--variants <n>', 'Distinct simulated app variants (1-10000)')
  .option('--runtime <mode>', 'all|docker', 'all')
  .option('--failures <list>', 'Comma-separated failure types')
  .option('--strict', 'Require expected recovery/fix assertions for each scenario')
  .option('--verbose', 'Show detailed simulation logs (default: quiet)')
  .option('--json', 'Output full JSON response')
  .option('--output <path>', 'Write full JSON report to file')
  .action((subcommand, options) => {
    if (subcommand === 'docker-sim' || subcommand === 'docker') {
      runDockerSimulationSuite(config, options);
      return;
    }
    const mode = subcommand === 'run' ? 'run' : 'recovery';
    runTestingFramework(config, mode, options);
  });

// Notifications commands
const notifications = program
  .command('notifications')
  .description('Manage skill/agent notifications');

notifications
  .command('list')
  .description('List latest notifications')
  .option('--json', 'Output results as JSON')
  .option('--limit <n>', 'Number of notifications to show', '20')
  .action((options) => listNotifications({ ...options, limit: parseInt(options.limit) }));

notifications
  .command('clear')
  .description('Clear notification history')
  .option('--json', 'Output results as JSON')
  .action((options) => clearNotifications(options));


// Handle unknown commands
program.on('command:*', () => {
  console.error(chalk.red(`Unknown command: ${program.args.join(' ')}`));
  console.log();
  console.log('Run', chalk.cyan('clikdeploy --help'), 'for available commands');
  process.exit(1);
});

// Show help if no command provided
if (!process.argv.slice(2).length) {
  console.log(banner);
  program.outputHelp();
}

program.parse();
