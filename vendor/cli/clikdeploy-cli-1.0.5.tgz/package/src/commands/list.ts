import chalk from 'chalk';
import ora from 'ora';
import Conf from 'conf';
import { getApiClient, requireAuth } from '../utils/api';
import { DEFAULT_API_URL, normalizeApiUrl } from '../constants';
import { Formatters } from '../ui/formatters';
import { resolveApp, showDisambiguationHint } from '../utils/app-resolver';
import { buildUniqueDisplayIds } from '../utils/id-format';

export async function listApps(config: Conf) {
  requireAuth(config);

  const api = getApiClient(config);
  const spinner = ora('Loading apps...').start();

  try {
    const apps = await (api as any).getControlPlaneApps();

    spinner.stop();

    if (!apps || apps.length === 0) {
      console.log(chalk.yellow('\nNo apps found'));
      console.log(chalk.gray('Create your first app:'), chalk.cyan('clikdeploy init'));
      return;
    }

    console.log(chalk.bold(`\n📦 Your Apps (${apps.length})\n`));
    const idMap = buildUniqueDisplayIds(apps.map((app: any) => app.id), 12, 24);

    // Table header
    console.log(
      chalk.gray('  ') +
      'Name'.padEnd(22) +
      'ID'.padEnd(10) +
      'Status'.padEnd(12) +
      'Server'.padEnd(20) +
      'Last Deploy'
    );
    console.log(chalk.gray('  ' + '─'.repeat(82)));

    for (const app of apps) {
      const statusColor = {
        RUNNING: chalk.green,
        STOPPED: chalk.gray,
        DEPLOYING: chalk.yellow,
        ERROR: chalk.red,
      }[app.status] || chalk.gray;

      const deployDate = chalk.gray('n/a');

      console.log(
        chalk.cyan('  ') +
        app.name.slice(0, 21).padEnd(22) +
        chalk.gray((idMap.get(String(app.id)) || String(app.id || '')).padEnd(10)) +
        statusColor(app.status.padEnd(12)) +
        (app.serverName || 'Unknown').slice(0, 18).padEnd(20) +
        deployDate
      );
    }

    console.log();
  } catch (error: any) {
    spinner.fail('Failed to load apps');
    console.log(chalk.red(error.response?.data?.error || error.message));
  }
}

export async function listServers(config: Conf) {
  requireAuth(config);

  const api = getApiClient(config);
  const spinner = ora('Loading servers...').start();

  try {
    const servers = await (api as any).getControlPlaneServers() || [];

    spinner.stop();

    if (!servers || servers.length === 0) {
      const platformUrl = normalizeApiUrl((config.get('apiUrl') as string) || DEFAULT_API_URL);
      console.log(chalk.yellow('\nNo servers connected'));
      console.log(chalk.gray('Add a server at:'), chalk.cyan(`${platformUrl}/servers/new`));
      return;
    }

    console.log(chalk.bold(`\n🖥️  Your Servers (${servers.length})\n`));

    // Table header
    console.log(
      chalk.gray('  ') +
      'Name'.padEnd(25) +
      'Status'.padEnd(14) +
      'Provider'.padEnd(15) +
      'IP Address'
    );
    console.log(chalk.gray('  ' + '─'.repeat(75)));

    for (const server of servers) {
      const statusColor = {
        CONNECTED: chalk.green,
        SCANNING: chalk.yellow,
        DISCONNECTED: chalk.gray,
        CONNECTING: chalk.yellow,
        ERROR: chalk.red,
      }[server.status] || chalk.gray;

      console.log(
        chalk.cyan('  ') +
        server.name.slice(0, 23).padEnd(25) +
        statusColor(server.status.padEnd(14)) +
        (server.cloudProvider || 'SSH').padEnd(15) +
        server.ipAddress
      );
    }

    console.log();
  } catch (error: any) {
    spinner.fail('Failed to load servers');
    console.log(chalk.red(error.response?.data?.error || error.message));
  }
}

/** List all servers with status and health error (why disconnected). Use CLI to debug disconnects. */
export async function showServersStatus(config: Conf) {
  requireAuth(config);

  const api = getApiClient(config);
  const spinner = ora('Loading servers...').start();

  try {
    const servers = (await (api as any).getControlPlaneServers()) || [];
    spinner.stop();

    if (!servers.length) {
      console.log(chalk.yellow('\nNo servers'));
      return;
    }

    console.log(chalk.bold('\n🖥️  Server status (use this to see why a server is disconnected)\n'));

    const statusColor: Record<string, typeof chalk.green> = {
      CONNECTED: chalk.green,
      SCANNING: chalk.yellow,
      ERROR: chalk.red,
      DISCONNECTED: chalk.gray,
      CONNECTING: chalk.yellow,
    };

    for (const server of servers) {
      const color = statusColor[server.status] || chalk.gray;
      console.log(chalk.cyan(`  ${server.name}`));
      console.log(`    Status: ${color(server.status)}  IP: ${server.ipAddress}`);
      if (server.healthError) {
        console.log(chalk.red(`    Error:  ${server.healthError}`));
      }
      console.log();
    }

    console.log(chalk.gray('  Reconnect: clikdeploy servers reconnect <name>'));
    console.log(chalk.gray('  Details:   clikdeploy servers inspect <name>\n'));
  } catch (error: any) {
    spinner.fail('Failed to load servers');
    console.log(chalk.red(error.response?.data?.error || error.message));
  }
}

export async function showApp(config: Conf, appIdentifier: string) {
  requireAuth(config);

  if (!appIdentifier) {
    Formatters.error('Please specify an app name or ID');
    Formatters.gray('Example: clikdeploy apps show n8n');
    Formatters.gray('Example: clikdeploy apps show gcp-server n8n');
    return;
  }

  const api = getApiClient(config);
  const spinner = ora('Loading app details...').start();

  try {
    const resolved = await resolveApp(api, appIdentifier);
    
    if (!resolved) {
      spinner.fail(`App "${appIdentifier}" not found`);
      const allApps = await api.getApps();
      showDisambiguationHint(appIdentifier, allApps);
      return;
    }

    const { app } = resolved;
    spinner.stop();

    console.log(chalk.bold(`\n📦 ${app.name}\n`));
    Formatters.info('Status:  ', app.status);
    Formatters.info('Image:   ', app.dockerImage);
    Formatters.info('Port:    ', app.port.toString());
    Formatters.info('Domain:  ', app.domain || 'Not set');
    Formatters.info('SSL:     ', app.sslEnabled ? 'Enabled' : 'Disabled');
    Formatters.info('Server:  ', app.server?.name || 'Unknown');
    
    if (app.domain) {
      console.log(chalk.bold('\n🌐 URL:\n'));
      const protocol = app.sslEnabled ? 'https' : 'http';
      console.log(`  ${chalk.cyan(`${protocol}://${app.domain}`)}`);
    }

    console.log();
  } catch (error: any) {
    spinner.fail('Failed to load app details');
    Formatters.error(error.response?.data?.error || error.message);
  }
}
