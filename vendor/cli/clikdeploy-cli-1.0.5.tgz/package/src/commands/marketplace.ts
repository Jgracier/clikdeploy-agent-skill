import ora from 'ora';
import Conf from 'conf';
import chalk from 'chalk';
import { ApiClient } from '../api/client';
import { MarketplaceService } from '../services/marketplace.service';
import { Formatters } from '../ui/formatters';
import { requireAuth } from '../utils/api';
import { delay } from '../utils/delay';
import {
  createDeployLogShapeState,
  shapeContainerLogChunk,
} from '../utils/deploy-log-shaper';
import { resolveDeployServer } from '../utils/deploy-normalizer';
import { displayId } from '../utils/id-format';
import { emitDeployServerResolutionError, emitJson } from '../utils/structured-output';

interface DeployOptions {
  server?: string;
  wait?: boolean;
  concurrency?: number | string;
}

async function runWithConcurrency<T>(
  items: string[],
  concurrency: number,
  worker: (_item: string, _index: number) => Promise<T>
): Promise<T[]> {
  const results: T[] = new Array(items.length);
  let nextIndex = 0;

  const runners = Array.from({ length: Math.max(1, concurrency) }, async () => {
    while (true) {
      const current = nextIndex++;
      if (current >= items.length) return;
      results[current] = await worker(items[current], current);
    }
  });

  await Promise.all(runners);
  return results;
}

/**
 * Marketplace Commands
 * Thin handlers - delegate to services
 */

export async function deployMarketplace(config: Conf, appNames: string | string[], options: DeployOptions = {}) {
  requireAuth(config);

  const apps = Array.isArray(appNames) ? appNames : [appNames];

  if (!apps.length) {
    emitJson({
      status: 'invalid_input',
      command: 'clikdeploy marketplace deploy',
      message: 'Please specify at least one app name',
      usage: 'clikdeploy marketplace deploy <app-name> [more-apps...] [--server <name-or-id>]',
    });
    return;
  }

  const api = new ApiClient(config);
  const marketplace = new MarketplaceService(api);
  let server: { id: string; name?: string };
  try {
    ({ server } = await resolveDeployServer(api as any, options.server, {
      preferFirstIfMultiple: false,
    }));
  } catch (error: any) {
    if (emitDeployServerResolutionError(error, 'clikdeploy marketplace deploy')) return;
    Formatters.error(error.message || 'Failed to resolve server');
    return;
  }

  console.log();
  Formatters.header(`🚀 Deploying ${apps.length} app(s) to ${server.name || server.id}`);
  console.log();

  const results: Array<{ name: string; success: boolean; appId?: string; error?: string }> = [];
  const parsedConcurrency = Number(options.concurrency ?? process.env.CLIKDEPLOY_DEPLOY_CONCURRENCY ?? 4);
  const maxConcurrency = Number.isFinite(parsedConcurrency)
    ? Math.max(1, Math.min(20, Math.floor(parsedConcurrency)))
    : 4;

  console.log();
  Formatters.gray(`📦 Processing ${apps.length} app(s) with concurrency ${maxConcurrency}...`);
  console.log();

  const deployResults = await runWithConcurrency(
    apps,
    Math.min(maxConcurrency, apps.length),
    async (appName) => {
      const spinner = ora(`Deploying ${appName}...`).start();

      try {
        let isDiscovery = false;
        let app;

        try {
          app = await marketplace.deploy(appName, server.id);
        } catch (err: any) {
          // This is where smartDeploy logic is now hidden in the service, but let's make it explicit here for better UI
          throw err;
        }

        spinner.succeed(`${appName} deployment started: ${displayId(app.id)}`);
        if (app.dockerImage && app.dockerImage !== appName) {
          Formatters.gray(`  Matched Discovery: ${app.dockerImage} 🔍`);
        }
        Formatters.gray(`  Server: ${server.name || server.id}`);
        Formatters.gray(`  ID:     ${app.id}`);
        console.log();

        // If waiting, stream all deployment + container logs and block until done so you see exactly what happened.
        // Failures should be per-app only, not process-wide.
        if (options.wait !== false) {
          try {
            await waitForDeployment(api, app.id, appName);
          } catch (waitError: any) {
            return {
              name: appName,
              success: false as const,
              appId: app.id,
              error: waitError?.message || 'Deployment failed',
            };
          }
        }

        return { name: appName, success: true as const, appId: app.id };
      } catch (error: any) {
        spinner.fail(`${appName} deployment failed`);
        Formatters.error(`  ${error.message}`);
        console.log();
        return { name: appName, success: false as const, error: error.message };
      }
    }
  );
  results.push(...deployResults);

  // Summary
  console.log();
  Formatters.header('📊 Deployment Summary');
  const succeeded = results.filter(r => r.success).length;
  const failed = results.filter(r => !r.success).length;

  Formatters.info('Total:    ', apps.length.toString());
  Formatters.info('Succeeded:', `${succeeded} ✅`);
  if (failed > 0) {
    Formatters.info('Failed:   ', `${failed} ❌`);
    console.log();
    Formatters.gray('Failed apps:');
    results.filter(r => !r.success).forEach(r => {
      Formatters.error(`  - ${r.name}: ${r.error}`);
    });
  }
  console.log();
}

// SIMPLIFIED: Support multiple apps, autonomous by default
export async function deleteApp(config: Conf, appIds: string | string[]) {
  requireAuth(config);

  const apps = Array.isArray(appIds) ? appIds : [appIds];

  if (!apps.length) {
    Formatters.error('Please specify at least one app ID or name');
    Formatters.gray('Example: clikdeploy marketplace delete app1 app2 app3');
    return;
  }

  // Delete now awaits server-side cleanup; allow 3 min per request so cleanup can complete
  const api = new ApiClient(config, 180000);
  const marketplace = new MarketplaceService(api);
  const spinner = ora(`Deleting ${apps.length} app(s)...`).start();

  try {
    // Delete all apps in parallel
    const results = await Promise.allSettled(
      apps.map(async (appId) => {
        const result = await marketplace.delete(appId);
        return { appId, result };
      })
    );

    const succeeded = results.filter(r => r.status === 'fulfilled').length;
    const failed = results.filter(r => r.status === 'rejected').length;

    // Show cleanup details
    const successfulDeletes = results
      .filter(r => r.status === 'fulfilled')
      .map(r => (r as PromiseFulfilledResult<any>).value);

    if (successfulDeletes.length > 0) {
      const totalCleaned = successfulDeletes.reduce((acc, { result }) => {
        if (result?.cleaned) {
          acc.containers += result.cleaned.containers || 0;
          acc.volumes += result.cleaned.volumes || 0;
          acc.networks += result.cleaned.networks || 0;
        }
        return acc;
      }, { containers: 0, volumes: 0, networks: 0 });

      spinner.succeed(`Deleted ${succeeded} app(s)`);
      if (totalCleaned.containers > 0 || totalCleaned.volumes > 0 || totalCleaned.networks > 0) {
        Formatters.gray(`  Cleaned: ${totalCleaned.containers} container(s), ${totalCleaned.volumes} volume(s), ${totalCleaned.networks} network(s)`);
      }
    } else {
      spinner.warn(`Deleted ${succeeded}, failed ${failed}`);
    }

    if (failed > 0) {
      results.forEach((result, i) => {
        if (result.status === 'rejected') {
          Formatters.error(`Failed to delete ${apps[i]}: ${result.reason?.message || 'Unknown error'}`);
        }
      });
    }

    // CRITICAL: Verify apps are actually deleted by polling - MUST COMPLETE BEFORE RETURNING
    if (succeeded > 0) {
      let verifySpinner = ora('Verifying deletion...').start();
      let allDeleted = false;
      let attempts = 0;
      const maxAttempts = Math.max(
        1,
        parseInt(process.env.CLIKDEPLOY_VERIFY_DELETE_MAX_ATTEMPTS || '45', 10) || 45
      );

      while (!allDeleted && attempts < maxAttempts) {
        await delay(1000);
        attempts++;

        try {
          const allApps = await api.getApps();
          const remainingApps = apps.filter(appId =>
            allApps.some((app: any) => app.id === appId || app.name === appId)
          );

          if (remainingApps.length === 0) {
            allDeleted = true;
            verifySpinner.succeed('All apps deleted and verified');
          } else {
            verifySpinner.text = `Verifying deletion... (${remainingApps.length} remaining, ${attempts}s)`;
          }
        } catch (err) {
          // If we can't check, continue polling - don't assume it's done
          verifySpinner.text = `Verifying deletion... (checking, ${attempts}s)`;
        }
      }

      // Do not hard-fail by default when verification times out; requests were sent and
      // server-side cleanup may still be converging. Strict mode remains opt-in.
      if (!allDeleted) {
        verifySpinner.fail('Deletion verification timeout');
        Formatters.warning(`Some apps may still be converging deletion after ${maxAttempts}s`);
        const strict = String(process.env.CLIKDEPLOY_STRICT_DELETE_VERIFY || '').toLowerCase();
        if (strict === '1' || strict === 'true' || strict === 'yes') {
          throw new Error(`Deletion verification failed - ${apps.length} apps may still exist`);
        }
      }
    }
  } catch (error: any) {
    spinner.fail('Delete failed');
    Formatters.error(error.message);
    process.exit(1);
  }
}

export async function listMarketplace(config: Conf) {
  requireAuth(config);

  const api = new ApiClient(config);
  const marketplace = new MarketplaceService(api);
  const spinner = ora('Loading marketplace...').start();

  try {
    const apps = await marketplace.list();
    spinner.stop();

    Formatters.header('Available Apps');
    apps.forEach((app: any) => {
      console.log(`  ${app.name.padEnd(20)} ${Formatters.statusBadge(app.category)}`);
      Formatters.gray(`  ${app.description}`);
      console.log();
    });
  } catch (error: any) {
    spinner.fail('Failed to load marketplace');
    Formatters.error(error.message);
    process.exit(1);
  }
}

export async function checkStatus(config: Conf, appId: string) {
  requireAuth(config);

  if (!appId) {
    Formatters.error('Please specify an app ID');
    return;
  }

  const api = new ApiClient(config);
  const marketplace = new MarketplaceService(api);
  const spinner = ora('Checking status...').start();

  try {
    const app = await marketplace.getStatus(appId);
    spinner.stop();

    Formatters.header('App Status');
    Formatters.info('Name:  ', app.name);
    Formatters.info('Status:', Formatters.statusBadge(app.status));
    if (app.url) Formatters.info('URL:   ', app.url);
    console.log();
  } catch (error: any) {
    spinner.fail('Failed to get status');
    Formatters.error(error.message);
    process.exit(1);
  }
}

function formatDeployLogEntry(entry: { timestamp?: string | Date; level?: string; message?: string }): string {
  const ts = entry.timestamp
    ? new Date(entry.timestamp).toISOString().replace('T', ' ').slice(0, 19)
    : '';
  const level = (entry.level || 'info').toUpperCase().padEnd(5);
  const msg = entry.message ?? '';
  return ts ? `${ts} ${level} ${msg}` : `${level} ${msg}`;
}

async function waitForDeployment(api: ApiClient, appId: string, appName?: string) {
  const spinner = ora(`Deploying${appName ? ` ${appName}` : ''}...`).start();
  const startTime = Date.now();
  const timeout = 10 * 60 * 1000;
  let lastLogCount = 0;
  const deployLogShapeState = createDeployLogShapeState();

  while (Date.now() - startTime < timeout) {
    try {
      const app = await api.getApp(appId);
      const elapsed = Math.round((Date.now() - startTime) / 1000);
      const status = app.status?.toUpperCase();

      // 1) Deployment progress logs from server
      const deployments = await api.getAppDeployments(appId);
      const latest = deployments?.[0];
      if (latest?.id) {
        try {
          const { logs } = await api.getDeploymentLogs(latest.id);
          if (Array.isArray(logs) && logs.length > lastLogCount) {
            for (let i = lastLogCount; i < logs.length; i++) {
              process.stdout.write(formatDeployLogEntry(logs[i]) + '\n');
            }
            lastLogCount = logs.length;
          }
        } catch {
          // Non-fatal
        }
      }
      // 2) Container (Docker) logs – actual process output
      try {
        const raw = await api.getAppContainerLogs(appId, 500);
        const shaped = shapeContainerLogChunk(raw, deployLogShapeState);
        if (shaped.lines.length > 0) {
          for (const line of shaped.lines) {
            process.stdout.write(line + '\n');
          }
        }
        deployLogShapeState.lastContainerLineCount = shaped.nextLineCount;
      } catch {
        // Non-fatal (container may not exist yet)
      }

      if (status === 'RUNNING') {
        // Final dump: any container logs from the end so you see everything that happened
        try {
          const raw = await api.getAppContainerLogs(appId, 500);
          const shaped = shapeContainerLogChunk(raw, deployLogShapeState);
          for (const line of shaped.lines) {
            process.stdout.write(line + '\n');
          }
          deployLogShapeState.lastContainerLineCount = shaped.nextLineCount;
        } catch {
          // Non-fatal
        }
        spinner.succeed(`Deployed in ${elapsed}s`);
        console.log();
        const url = app.domain ? `https://${app.domain}` : null;
        if (url) Formatters.info('Live at:', url);
        return;
      }

      if (status === 'FAILED' || status === 'ERROR') {
        try {
          const raw = await api.getAppContainerLogs(appId, 500);
          const shaped = shapeContainerLogChunk(raw, deployLogShapeState);
          for (const line of shaped.lines) {
            process.stdout.write(line + '\n');
          }
          deployLogShapeState.lastContainerLineCount = shaped.nextLineCount;
        } catch {
          // Non-fatal
        }
        spinner.fail(`Deployment failed after ${elapsed}s`);
        const errorMessage = app.healthError || `Deployment failed with status ${status}`;
        if (app.healthError) Formatters.error(`Error: ${app.healthError}`);
        const deploymentError = new Error(errorMessage);
        (deploymentError as any).code = 'DEPLOYMENT_FAILED';
        throw deploymentError;
      }

      spinner.text = `Deploying... (${elapsed}s, status: ${status || 'unknown'})`;
      await delay(3000);
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error || '');
      const code = (error as any)?.code;
      if (
        code === 'DEPLOYMENT_FAILED' ||
        code === 'DEPLOYMENT_TIMEOUT' ||
        msg.includes('Deployment failed') ||
        msg.includes('Deployment timed out')
      ) {
        throw error;
      }
      spinner.fail('Failed to check status');
      throw error;
    }
  }

  spinner.fail('Deployment timed out');
  const timeoutError = new Error('Deployment timed out');
  (timeoutError as any).code = 'DEPLOYMENT_TIMEOUT';
  throw timeoutError;
}
