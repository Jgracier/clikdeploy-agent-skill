import ora from 'ora';
import Conf from 'conf';
import { getApiClient, requireAuth } from '../utils/api';
import { Formatters } from '../ui/formatters';
import chalk from 'chalk';

/**
 * Watch deployments - simple monitoring
 */
export async function watchDeployments(config: Conf, options: { interval?: number; filter?: string } = {}) {
  requireAuth(config);
  
  const api = getApiClient(config);
  const interval = options.interval || 3000; // Default 3 seconds
  const filter = options.filter; // Optional: 'deploying', 'error', 'running'

  console.log(chalk.gray(`Watching deployments (refresh every ${interval/1000}s)...`));
  console.log(chalk.gray('Press Ctrl+C to stop\n'));

  const spinner = ora('Loading apps...').start();
  let inFlight = false;

  const watch = async () => {
    if (inFlight) return;
    inFlight = true;
    try {
      const apps = await api.getApps() || [];

      // Filter if specified
      let filteredApps = apps;
      if (filter) {
        filteredApps = apps.filter((app: any) => 
          app.status?.toLowerCase().includes(filter.toLowerCase())
        );
      }

      spinner.stop();

      // Clear screen and show status
      console.clear();
      console.log(chalk.cyan('╔═══════════════════════════════════════╗'));
      console.log(chalk.cyan('║') + '  ' + chalk.bold.white('📊 Deployment Monitor') + '              ' + chalk.cyan('║'));
      console.log(chalk.cyan('╚═══════════════════════════════════════╝'));
      console.log();

      if (filteredApps.length === 0) {
        console.log(chalk.gray('No apps found' + (filter ? ` with filter: ${filter}` : '')));
      } else {
        // Group by status
        const byStatus: Record<string, any[]> = {};
        filteredApps.forEach((app: any) => {
          const status = app.status || 'UNKNOWN';
          if (!byStatus[status]) byStatus[status] = [];
          byStatus[status].push(app);
        });

        // Show summary
        const deploying = byStatus.DEPLOYING?.length || 0;
        const running = byStatus.RUNNING?.length || 0;
        const error = byStatus.ERROR?.length || 0;
        
        console.log(chalk.bold('Summary:'));
        if (deploying > 0) console.log(`  ${chalk.yellow('●')} Deploying: ${chalk.yellow(deploying.toString())}`);
        if (running > 0) console.log(`  ${chalk.green('●')} Running: ${chalk.green(running.toString())}`);
        if (error > 0) console.log(`  ${chalk.red('●')} Error: ${chalk.red(error.toString())}`);
        console.log();

        // Show apps by status
        if (byStatus.DEPLOYING?.length > 0) {
          console.log(chalk.yellow.bold('Deploying:'));
          byStatus.DEPLOYING.forEach((app: any) => {
            console.log(`  ${chalk.yellow('●')} ${chalk.cyan(app.name)} - ${chalk.gray(app.server?.name || 'Unknown server')}`);
          });
          console.log();
        }

        if (byStatus.ERROR?.length > 0) {
          console.log(chalk.red.bold('Errors:'));
          byStatus.ERROR.forEach((app: any) => {
            const errorMsg = app.healthError || 'Unknown error';
            console.log(`  ${chalk.red('●')} ${chalk.cyan(app.name)} - ${chalk.red(errorMsg)}`);
          });
          console.log();
        }

        if (byStatus.RUNNING?.length > 0 && !filter) {
          console.log(chalk.green.bold('Running:'));
          byStatus.RUNNING.slice(0, 5).forEach((app: any) => {
            console.log(`  ${chalk.green('●')} ${chalk.cyan(app.name)}`);
          });
          if (byStatus.RUNNING.length > 5) {
            console.log(chalk.gray(`  ... and ${byStatus.RUNNING.length - 5} more`));
          }
          console.log();
        }
      }

      console.log(chalk.gray(`Last updated: ${new Date().toLocaleTimeString()}`));
      console.log(chalk.gray('Press Ctrl+C to stop'));

      spinner.start('Refreshing...');
    } catch (error: any) {
      spinner.fail('Failed to fetch apps');
      Formatters.error(error.response?.data?.error || error.message);
      process.exit(1);
    } finally {
      inFlight = false;
    }
  };

  // Initial load
  await watch();

  // Set up interval
  const intervalId = setInterval(watch, interval);

  // Handle Ctrl+C
  process.on('SIGINT', () => {
    clearInterval(intervalId);
    spinner.stop();
    console.log('\n' + chalk.gray('Stopped watching'));
    process.exit(0);
  });
}
