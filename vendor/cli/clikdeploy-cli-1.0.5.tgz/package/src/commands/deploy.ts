/**
 * Deploy command: thin CLI entry — load config, call DeployService and ApiClient.
 */

import fs from 'fs';
import path from 'path';
import chalk from 'chalk';
import ora from 'ora';
import Conf from 'conf';
import { getApiClient, requireAuth } from '../utils/api';
import { findOrCreateApp, waitForDeployment } from '../services/deploy.service';
import { emitJson } from '../utils/structured-output';

interface DeployOptions {
  server?: string;
  branch?: string;
  message?: string;
  wait?: boolean;
}

function isGithubUrl(input: string): boolean {
  const value = String(input || '').trim();
  if (!value) return false;
  return (
    /^https?:\/\/(?:www\.)?github\.com\/[^/]+\/[^/]+(?:\.git)?(?:[?#].*)?$/i.test(value) ||
    /^git@github\.com:[^/]+\/[^/]+(?:\.git)?$/i.test(value) ||
    /^ssh:\/\/git@github\.com\/[^/]+\/[^/]+(?:\.git)?$/i.test(value)
  );
}

function isExplicitImageRef(input: string): boolean {
  const value = String(input || '').trim();
  if (!value) return false;
  // Registry/image or image:tag (e.g. ghcr.io/org/app:latest, redis:7, org/app)
  return value.includes('/') || value.includes(':');
}

function normalizeExplicitImageTarget(input: string): string {
  const raw = String(input || '').trim();
  if (!raw) return '';

  try {
    const url = new URL(raw);
    const host = url.hostname.toLowerCase();
    const path = url.pathname.replace(/^\/+/, '').replace(/\/+$/, '');

    if (host === 'ghcr.io') {
      return path ? `ghcr.io/${path}` : raw;
    }

    if (host === 'docker.io' || host === 'index.docker.io' || host === 'registry-1.docker.io') {
      return path || raw;
    }

    if (host === 'hub.docker.com') {
      const parts = path.split('/').filter(Boolean);
      // hub.docker.com/r/<namespace>/<repo>...
      if (parts[0] === 'r' && parts.length >= 3) {
        return `${parts[1]}/${parts[2]}`;
      }
      return path || raw;
    }
  } catch {
    // Not a URL - already an image ref or app name.
  }

  return raw;
}

function normalizeImageName(name: string): string {
  const cleaned = String(name || '')
    .trim()
    .replace(/^docker\.io\//i, '')
    .replace(/^index\.docker\.io\//i, '');
  if (!cleaned) return '';
  return cleaned.includes('/') ? cleaned : `library/${cleaned}`;
}

function normalizeRepoName(name: string): string {
  return normalizeImageName(name).replace(/^library\//, '');
}

function credibilityScore(image: any): number {
  const official = image?.official ? 1 : 0;
  const trusted = image?.is_trusted ? 1 : 0;
  const automated = image?.automated ? 1 : 0;
  const stars = Number(image?.star_count || 0);
  const pulls = Number(image?.pull_count || 0);
  return (
    official * 1_000_000_000 +
    trusted * 100_000_000 +
    automated * 10_000_000 +
    stars * 10_000 +
    Math.floor(Math.log10(Math.max(1, pulls))) * 100
  );
}

function selectDockerImage(queryName: string, images: any[]): string | null {
  const target = normalizeImageName(queryName).toLowerCase();
  const targetRepo = normalizeRepoName(queryName).toLowerCase();
  const rows = Array.isArray(images) ? images : [];
  if (rows.length === 0) return null;

  const exactMatches = rows.filter(
    (img) => normalizeImageName(String(img?.name || '')).toLowerCase() === target
  );
  const shortExactMatches = rows.filter(
    (img) => normalizeRepoName(String(img?.name || '')).toLowerCase() === targetRepo
  );
  const relevantMatches = rows.filter((img) =>
    normalizeRepoName(String(img?.name || '')).toLowerCase().includes(targetRepo)
  );

  const bucket =
    exactMatches.length > 0
      ? exactMatches
      : shortExactMatches.length > 0
        ? shortExactMatches
        : relevantMatches.length > 0
          ? relevantMatches
          : rows;

  const ranked = bucket.slice().sort((a, b) => credibilityScore(b) - credibilityScore(a));
  const selected = normalizeImageName(String(ranked[0]?.name || ''));
  return selected || null;
}

async function resolveDockerImageFromName(api: ReturnType<typeof getApiClient>, name: string): Promise<string | null> {
  const res = await api.getClient().get('/api/gate/docker-hub/search', {
    params: { q: name, page: 1, limit: 25 },
  });
  const images = res?.data?.data?.data?.images || [];
  return selectDockerImage(name, images);
}

export async function deploy(config: Conf, target: string | undefined, options: DeployOptions) {
  requireAuth(config);
  const api = getApiClient(config);

  // 1. Determine Deployment Mode
  if (target) {
    const isGithub = isGithubUrl(target);
    const normalizedTarget = normalizeExplicitImageTarget(target);
    const isExplicitImage = !isGithub && isExplicitImageRef(normalizedTarget);

    if (isGithub) {
      console.log(chalk.bold(`\n🚀 Deploying from GitHub: ${target}\n`));
      const { deployFromUrlBatch } = await import('./github');
      return deployFromUrlBatch(config, [target], {
        server: options.server,
        branch: options.branch || 'main',
        wait: options.wait !== false
      });
    }

    if (isExplicitImage) {
      console.log(chalk.bold(`\n🚀 Deploying Docker Image: ${normalizedTarget}\n`));
      const { deployDockerImage } = await import('./docker');
      return deployDockerImage(config, normalizedTarget, undefined, options);
    }

    // Plain app name: resolve against Docker Hub, then deploy image.
    try {
      const resolvedImage = await resolveDockerImageFromName(api, target);
      if (!resolvedImage) {
        emitJson({
          status: 'not_found',
          command: 'clikdeploy deploy',
          reason: 'dockerhub_image_not_found',
          message: `No Docker Hub image match found for "${target}"`,
          options: {
            usage: 'clikdeploy deploy <docker-image-or-github-url>',
            suggestion: `clikdeploy docker deploy ${target}:latest`,
          },
        });
        return;
      }
      console.log(chalk.bold(`\n🚀 Deploying from Docker Hub lookup: ${target} → ${resolvedImage}\n`));
      const { deployDockerImage } = await import('./docker');
      return deployDockerImage(config, resolvedImage, target, options);
    } catch (error: any) {
      emitJson({
        status: 'error',
        command: 'clikdeploy deploy',
        reason: 'dockerhub_lookup_failed',
        message: error?.response?.data?.error || error?.message || 'Failed to query Docker Hub',
      });
      return;
    }
  }

  // MODE B: Local Project Deploy
  const configPath = path.join(process.cwd(), 'clikdeploy.json');

  if (!target && !fs.existsSync(configPath)) {
    // Return structured deployment options as JSON
    const discovery = await api.getDiscovery().catch(() => ({}));
    console.log(JSON.stringify({
      discovery: discovery.deployment
    }, null, 2));
    return;
  }

  console.log(chalk.bold('\n🚀 Deploying current project...\n'));

  const projectConfig = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  const spinner = ora('Creating deployment...').start();

  try {
    const { app, created } = await findOrCreateApp(api, projectConfig, options);
    if (created) console.log(chalk.green(`✓ Created app: ${app.name}`));

    const deployment = await api.deployApp(app.id, {
      gitBranch: options.branch || projectConfig.branch,
      message: options.message,
    });

    const deploymentId = deployment?.id ?? deployment?.data?.id ?? '';
    spinner.succeed('Deployment started!');

    console.log();
    console.log(`   ${chalk.gray('App:')}        ${chalk.cyan(app.name)}`);
    console.log(`   ${chalk.gray('Status:')}     ${chalk.yellow('DEPLOYING')}`);
    console.log();
    if (options.wait !== false && deploymentId) {
      const result = await waitForDeployment(api, app.id, deploymentId, (elapsed, status) => {
        if (status === 'SUCCESS') spinner.succeed(`Deployed in ${elapsed}s`);
        else if (status === 'FAILED') spinner.fail(`Deployment failed after ${elapsed}s`);
        else spinner.text = `Deploying... (${elapsed}s)`;
      });

      if (result.success) {
        console.log();
        const deployments = await api.getAppDeployments(app.id);
        const d = deployments.find((x: any) => x.id === deploymentId);
        if (d?.metadata?.url) {
          console.log(chalk.green('🌐 Live at:'), chalk.cyan(d.metadata.url));
        }
      } else if (!result.success && 'error' in result && result.error) {
        console.log(chalk.red(`\nError: ${result.error}`));
        process.exit(1);
      }
    } else if (options.wait === false) {
      console.log(chalk.gray('Run'), chalk.cyan('clikdeploy status'), chalk.gray('to check progress'));
    }
  } catch (error: any) {
    const message = String(error?.response?.data?.error ?? error?.message ?? 'Deployment failed');
    const isServerClarification =
      message.includes('There are more than 1 server') ||
      message.includes('Multiple servers connected') ||
      message.includes('specify --server');

    if (isServerClarification) {
      const servers = await api.getServers().catch(() => []);
      emitJson({
        status: 'clarification_required',
        command: 'clikdeploy deploy',
        reason: 'multiple_servers_connected',
        message: 'Multiple servers connected. Specify --server <name-or-id>.',
        options: {
          servers: (servers || []).map((server: any) => ({
            id: String(server?.id || ''),
            name: String(server?.name || server?.id || ''),
            option: `--server \"${String(server?.name || server?.id || '')}\"`,
            ...(server?.ipAddress ? { ipAddress: String(server.ipAddress) } : {}),
            ...(server?.status ? { status: String(server.status) } : {}),
          })),
          usage: 'clikdeploy deploy <app-name> --server <name-or-id>',
        },
      });
      return;
    }

    spinner.fail('Deployment failed');
    console.log(chalk.red(message));
    process.exit(1);
  }
}
