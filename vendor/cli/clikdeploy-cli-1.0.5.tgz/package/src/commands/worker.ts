import ora from 'ora';
import Conf from 'conf';
import { getApiClient, requireAuth } from '../utils/api';
import { Formatters } from '../ui/formatters';
import chalk from 'chalk';
import { execSync } from 'child_process';
import path from 'path';
import fs from 'fs';

/**
 * Worker Management Commands
 * Worker runs in Docker only. Use: docker compose up -d worker (from repo root).
 */

function getRepoRoot(): string {
  const envPath = process.env.CLIKDEPLOY_PLATFORM_PATH;
  if (envPath && fs.existsSync(envPath)) {
    const resolved = path.resolve(envPath);
    return path.dirname(resolved); // platform is apps/web, repo root is parent of apps
  }
  const cliPath = __dirname;
  const candidates = [
    path.resolve(cliPath, '../../..'),       // apps/cli -> clikdeploy
    path.resolve(cliPath, '../../../../..'), // dist
  ];
  for (const dir of candidates) {
    const compose = path.join(dir, 'docker-compose.yml');
    if (fs.existsSync(compose)) return dir;
  }
  return path.resolve(cliPath, '../../..');
}

export async function workerStatus(config: Conf) {
  requireAuth(config);
  const api = getApiClient(config);
  const spinner = ora('Checking worker status...').start();

  try {
    const queueData = await api.getWorkerStatus().catch(() => ({
      status: 'unknown',
      queue: {},
      worker: {},
    }));

    spinner.stop();
    console.log(chalk.bold('\n🔧 Worker Status\n'));

    if (queueData.worker && 'connected' in queueData.worker) {
      const connected = queueData.worker.connected === true;
      console.log(`  Worker connected: ${connected ? chalk.green('yes') : chalk.red('no')}`);
      if (queueData.hint) {
        console.log();
        console.log(chalk.yellow('  ⚠ ' + queueData.hint));
      }
    }

    if (queueData.queue) {
      console.log();
      console.log(chalk.bold('  Queue Status:'));
      console.log(`    Waiting: ${chalk.cyan(queueData.queue.waiting || 0)}`);
      console.log(`    Active: ${chalk.yellow(queueData.queue.active || 0)}`);
      console.log(`    Completed: ${chalk.green(queueData.queue.completed || 0)}`);
      console.log(`    Failed: ${chalk.red(queueData.queue.failed || 0)}`);
    }

    if (queueData.worker) {
      const isActive = queueData.worker.processing || queueData.worker.hasRecentActivity;
      console.log();
      console.log(`  Worker Activity: ${isActive ? chalk.green('Active') : chalk.gray('Idle')}`);
    }

    console.log();
    Formatters.gray('Worker runs in Docker. From repo root: docker compose ps worker');
    console.log();
  } catch (error: any) {
    spinner.fail('Failed to check worker status');
    Formatters.error(error.response?.data?.error || error.message);
  }
}

/** Start the deployment worker via Docker. */
export async function workerStart(config: Conf) {
  const spinner = ora('Starting worker (Docker)...').start();
  const repoRoot = getRepoRoot();
  const compose = path.join(repoRoot, 'docker-compose.yml');

  try {
    if (!fs.existsSync(compose)) {
      spinner.fail('docker-compose.yml not found');
      Formatters.error('Run from clikdeploy repo root or set CLIKDEPLOY_PLATFORM_PATH to apps/web.');
      Formatters.gray('Then: docker compose up -d worker');
      return;
    }
    execSync('docker compose up -d worker', { cwd: repoRoot, stdio: 'pipe', encoding: 'utf-8' });
    spinner.succeed('Worker started (Docker)');
    Formatters.gray('Run clikdeploy worker status to verify.');
    console.log();
  } catch (error: any) {
    spinner.fail('Failed to start worker');
    Formatters.error(error.message);
    Formatters.gray('From repo root: docker compose up -d worker');
  }
}

/** Restart the deployment worker via Docker. */
export async function workerRestart(config: Conf) {
  requireAuth(config);
  const spinner = ora('Restarting worker (Docker)...').start();
  const repoRoot = getRepoRoot();
  const compose = path.join(repoRoot, 'docker-compose.yml');

  try {
    if (!fs.existsSync(compose)) {
      spinner.fail('docker-compose.yml not found');
      Formatters.error('From repo root: docker compose restart worker');
      return;
    }
    execSync('docker compose restart worker', { cwd: repoRoot, stdio: 'pipe', encoding: 'utf-8' });
    spinner.succeed('Worker restarted');
    Formatters.gray('Worker is now processing jobs');
  } catch (error: any) {
    spinner.fail('Failed to restart worker');
    Formatters.error(error.message);
  }
}

/** Show worker logs from Docker. */
export async function workerLogs(config: Conf) {
  requireAuth(config);
  const repoRoot = getRepoRoot();
  const compose = path.join(repoRoot, 'docker-compose.yml');

  try {
    if (!fs.existsSync(compose)) {
      Formatters.error('docker-compose.yml not found. From repo root: docker compose logs -f worker');
      return;
    }
    console.log(chalk.bold('\n📋 Worker Logs (Docker)\n'));
    execSync('docker compose logs worker --tail 50', {
      cwd: repoRoot,
      stdio: 'inherit',
      encoding: 'utf-8',
    });
    console.log();
    Formatters.gray('Live: docker compose logs -f worker (from repo root)');
    console.log();
  } catch (error: any) {
    Formatters.error(error.message);
  }
}

/** Clear waiting jobs from the deployment queue; optional --active to also clear active jobs. */
export async function workerClear(config: Conf, options: { active?: boolean } = {}) {
  requireAuth(config);
  const api = getApiClient(config);
  const includeActive = options.active === true;
  const spinner = ora(includeActive ? 'Clearing queue (waiting + active)...' : 'Clearing deployment queue...').start();
  try {
    const data = await api.clearWorkerQueue(includeActive);
    spinner.stop();
    console.log(chalk.bold('\n🧹 Queue cleared\n'));
    console.log(`  Removed ${chalk.cyan((data as any)?.cleared ?? 0)} job(s).`);
    console.log(`  ${chalk.gray((data as any)?.message || '')}`);
    console.log();
  } catch (error: any) {
    spinner.fail('Failed to clear queue');
    Formatters.error(error.response?.data?.error || error.message);
  }
}
