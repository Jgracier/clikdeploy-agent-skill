import ora from 'ora';
import Conf from 'conf';
import { spawn } from 'child_process';
import chalk from 'chalk';
import { ApiClient } from '../api/client';
import { Formatters } from '../ui/formatters';
import { delay } from '../utils/delay';
import { resolveServerFromList } from '../utils/server-resolver';

const CONNECT_POLL_INTERVAL_MS = 3000;
const CONNECT_TIMEOUT_MS = 300000; // 5 min

export async function performServerOAuth(
  config: Conf,
  providerKey: string,
  apiClient: ApiClient
): Promise<void> {
  return new Promise(async (resolve, reject) => {
    const { findAvailablePort } = await import('../utils/port-finder');
    let port: number;
    try {
      port = await findAvailablePort(49152);
    } catch {
      reject(new Error('Could not find an available port for OAuth callback server'));
      return;
    }

    const provider = providerKey.toUpperCase() === 'GCP' ? 'GCP' :
                    providerKey.toUpperCase() === 'AZURE' ? 'AZURE' :
                    providerKey.toUpperCase() === 'DIGITALOCEAN' ? 'DIGITALOCEAN' : providerKey;
    const callbackUrl = `http://localhost:${port}/callback`;

    let authUrl: string;
    const apiKeyForOAuth = config.get('apiKey') as string;
    const oauthAuthHeaders = apiKeyForOAuth ? { Authorization: `Bearer ${apiKeyForOAuth}` } : {};
    try {
      const { data } = await apiClient.getClient().post('/api/gate/servers/oauth/cli-init', {
        provider,
        cliPort: port,
        callbackUrl,
      }, { headers: oauthAuthHeaders });
      authUrl = data?.data?.authUrl || data?.authUrl;
      if (!authUrl) {
        reject(new Error('Server did not return an auth URL'));
        return;
      }
    } catch (err: any) {
      reject(new Error(err.response?.data?.error || err.message || 'Failed to start server OAuth'));
      return;
    }

    const server = require('http').createServer((req: any, res: any) => {
      const { parse } = require('url');
      const { pathname, query } = parse(req.url || '', true);

      if (pathname === '/callback') {
        const { success, error: callbackError } = query;

        if (callbackError) {
          res.writeHead(200, { 'Content-Type': 'text/html' });
          res.end(`
            <!DOCTYPE html>
            <html>
              <head><meta charset="utf-8"><title>Error</title></head>
              <body style="margin: 0; font-family: system-ui; background: #f8fafc; display: flex; align-items: center; justify-content: center; min-height: 100vh;">
                <div style="background: white; padding: 48px 40px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); max-width: 400px; text-align: center;">
                  <h1 style="color: #ef4444;">Authentication Failed</h1>
                  <p>${callbackError}</p>
                </div>
              </body>
            </html>
          `);
          server.close();
          reject(new Error(callbackError as string));
          return;
        }

        if (success === 'true') {
          res.writeHead(200, { 'Content-Type': 'text/html' });
          res.end(`
            <!DOCTYPE html>
            <html>
              <head><meta charset="utf-8"><title>Success</title></head>
              <body style="margin: 0; font-family: system-ui; background: #f8fafc; display: flex; align-items: center; justify-content: center; min-height: 100vh;">
                <div style="background: white; padding: 48px 40px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); max-width: 400px; text-align: center;">
                  <svg style="width: 64px; height: 64px; margin: 0 auto 24px;" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                  <h1 style="color: #22c55e;">Account Linked</h1>
                  <p>You can close this window and return to your terminal.</p>
                </div>
              </body>
            </html>
          `);
          server.close();
          resolve();
        }
      }
    });

    server.listen(port, () => {
      let cmd: string;
      let args: string[];
      if (process.platform === 'darwin') {
        cmd = 'open';
        args = [authUrl];
      } else if (process.platform === 'win32') {
        cmd = 'cmd';
        args = ['/c', 'start', '', authUrl];
      } else {
        cmd = 'xdg-open';
        args = [authUrl];
      }
      const child = spawn(cmd, args, { stdio: 'ignore', detached: true });
      child.on('error', () => {
        console.log(chalk.gray('\nPlease open this URL in your browser:'));
        console.log(chalk.cyan(`${authUrl}\n`));
      });
      child.unref();
    });
  });
}

export async function connectToInstance(
  api: any,
  instance: {
    projectId: string;
    id: string;
    name: string;
    zone: string;
    ipAddress?: string;
  }
): Promise<void> {
  if (!instance.ipAddress) {
    throw new Error(`Instance ${instance.name} has no IP address`);
  }

  const spinner = ora('Initiating connection...').start();

  try {
    const { data } = await api.getClient().post('/api/gate/servers/oauth/gcp/connect', {
      projectId: instance.projectId,
      instanceId: instance.id,
      zone: instance.zone,
      ipAddress: instance.ipAddress,
    });

    const server = data?.data?.server ?? data?.data ?? {};
    const serverId = server?.id;
    const serverName = server?.name ?? instance.name;

    spinner.text = 'Connecting to server...';

    const startedAt = Date.now();
    while (true) {
      await delay(CONNECT_POLL_INTERVAL_MS);

      const servers = (await api.getServers()) || [];
      const server = resolveServerFromList<any>(servers, serverId || serverName, { includeIpAddress: true })
        || (instance.ipAddress ? resolveServerFromList<any>(servers, instance.ipAddress, { includeIpAddress: true }) : undefined);

      if (server) {
        if (server.status === 'CONNECTED') {
          spinner.succeed(`Server ${serverName} connected successfully!`);
          console.log();
          return;
        }
        if (server.status === 'ERROR') {
          spinner.fail('Connection failed');
          const msg = server.healthError || server.message || 'Connection failed';
          Formatters.error(msg);
          console.log();
          const err = new Error(msg) as Error & { connectionErrorAlreadyShown?: boolean };
          err.connectionErrorAlreadyShown = true;
          throw err;
        }
      }

      const elapsed = Date.now() - startedAt;
      if (elapsed >= CONNECT_TIMEOUT_MS) {
        spinner.fail('Connection timed out');
        Formatters.error(`Server did not reach CONNECTED or ERROR within ${CONNECT_TIMEOUT_MS / 1000}s.`);
        Formatters.gray('Check status with: clikdeploy servers list');
        console.log();
        const err = new Error('Connection timed out') as Error & { connectionErrorAlreadyShown?: boolean };
        err.connectionErrorAlreadyShown = true;
        throw err;
      }

      const elapsedSeconds = Math.floor(elapsed / 1000);
      spinner.text = elapsedSeconds > 5 ? `Connecting to server... (${elapsedSeconds}s)` : 'Connecting to server...';
    }
  } catch (error: any) {
    if (error?.connectionErrorAlreadyShown) {
      throw error;
    }
    spinner.fail('Failed to initiate connection');
    Formatters.error(error?.response?.data?.error || error?.message || 'Unknown error');
    console.log();
    throw error;
  }
}
