import fs from 'fs';
import path from 'path';
import os from 'os';
import chalk from 'chalk';
import { Formatters } from '../ui/formatters';

const NOTIFICATIONS_PATH = path.join(os.homedir(), '.clikdeploy', 'skill-notifications.jsonl');

function emitJson(obj: unknown): void {
    process.stdout.write(JSON.stringify(obj) + '\n');
}

export function listNotifications(options: { json?: boolean; limit?: number }) {
    if (!fs.existsSync(NOTIFICATIONS_PATH)) {
        if (options.json) {
            emitJson({ status: 'notifications', count: 0, notifications: [] });
        } else {
            Formatters.info('Status:', 'No notifications found.');
        }
        return;
    }

    try {
        const content = fs.readFileSync(NOTIFICATIONS_PATH, 'utf8');
        const lines = content.split('\n').filter(l => l.trim().length > 0);
        const notifications = lines
            .map(l => JSON.parse(l))
            .reverse()
            .slice(0, options.limit || 20);

        if (options.json) {
            emitJson({ status: 'notifications', count: notifications.length, notifications });
        } else {
            Formatters.header(`Last ${notifications.length} Notifications`);
            notifications.forEach((n: any) => {
                const date = new Date(n.at).toLocaleString();
                console.log(`${chalk.gray(date)} - ${n.message || JSON.stringify(n)}`);
            });
        }
    } catch (error: any) {
        if (options.json) {
            emitJson({ status: 'error', message: 'Failed to read notifications', error: error.message });
        } else {
            Formatters.error('Failed to read notifications: ' + error.message);
        }
    }
}

export function clearNotifications(options: { json?: boolean }) {
    try {
        if (fs.existsSync(NOTIFICATIONS_PATH)) {
            fs.unlinkSync(NOTIFICATIONS_PATH);
        }
        if (options.json) {
            emitJson({ status: 'notifications_cleared' });
        } else {
            Formatters.success('Notifications cleared.');
        }
    } catch (error: any) {
        if (options.json) {
            emitJson({ status: 'error', message: 'Failed to clear notifications', error: error.message });
        } else {
            Formatters.error('Failed to clear notifications: ' + error.message);
        }
    }
}
