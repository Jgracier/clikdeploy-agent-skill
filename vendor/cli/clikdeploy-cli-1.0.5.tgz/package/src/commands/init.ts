import fs from 'fs';
import path from 'path';
import chalk from 'chalk';
import inquirer from 'inquirer';
import ora from 'ora';
import Conf from 'conf';
import { getApiClient, requireAuth } from '../utils/api';
import { DEFAULT_API_URL, normalizeApiUrl } from '../constants';

interface ClikDeployConfig {
  name: string;
  server?: string;
  branch?: string;
  autoDeploy?: boolean;
  buildCommand?: string;
  startCommand?: string;
}

export async function init(config: Conf) {
  requireAuth(config);

  console.log(chalk.bold('\n🚀 Initialize ClikDeploy Project\n'));

  // Check for existing config
  const configPath = path.join(process.cwd(), 'clikdeploy.json');
  if (fs.existsSync(configPath)) {
    const { overwrite } = await inquirer.prompt([
      {
        type: 'confirm',
        name: 'overwrite',
        message: 'clikdeploy.json already exists. Overwrite?',
        default: false,
      },
    ]);
    if (!overwrite) {
      console.log(chalk.gray('Cancelled.'));
      return;
    }
  }

  // Detect project type
  const projectInfo = detectProject();
  console.log(chalk.gray(`Detected: ${projectInfo.type || 'Unknown project type'}`));

  // Get servers
  const api = getApiClient(config);
  const spinner = ora('Loading servers...').start();

  let servers: any[] = [];
  try {
    servers = await api.getServers();
    spinner.stop();
  } catch (error) {
    spinner.fail('Failed to load servers');
    return;
  }

  if (servers.length === 0) {
    const platformUrl = normalizeApiUrl((config.get('apiUrl') as string) || DEFAULT_API_URL);
    console.log(chalk.yellow('\nNo servers connected!'));
    console.log(chalk.gray('Add a server at:'), chalk.cyan(`${platformUrl}/servers/new`));
    return;
  }

  // Ask questions
  const answers = await inquirer.prompt([
    {
      type: 'input',
      name: 'name',
      message: 'App name:',
      default: path.basename(process.cwd()),
      validate: (input) => input.length > 0 || 'Name is required',
    },
    {
      type: 'list',
      name: 'server',
      message: 'Deploy to server:',
      choices: servers.map(s => ({
        name: `${s.name} (${s.ipAddress})`,
        value: s.id,
      })),
    },
    {
      type: 'confirm',
      name: 'autoDeploy',
      message: 'Auto-deploy on push?',
      default: true,
    },
  ]);

  // Create config
  const deployConfig: ClikDeployConfig = {
    name: answers.name,
    server: answers.server,
    autoDeploy: answers.autoDeploy,
    ...projectInfo.config,
  };

  // Write config file
  fs.writeFileSync(configPath, JSON.stringify(deployConfig, null, 2));

  // Add to .gitignore if not present
  const gitignorePath = path.join(process.cwd(), '.gitignore');
  const gitignoreEntry = '\n# ClikDeploy\n.clikdeploy/\n';
  
  if (fs.existsSync(gitignorePath)) {
    const gitignore = fs.readFileSync(gitignorePath, 'utf8');
    if (!gitignore.includes('.clikdeploy/')) {
      fs.appendFileSync(gitignorePath, gitignoreEntry);
    }
  }

  console.log(chalk.green('\n✓ Project initialized!\n'));
  console.log(chalk.gray('Config saved to'), chalk.cyan('clikdeploy.json'));
  console.log();
  console.log('Next steps:');
  console.log(chalk.cyan('  clikdeploy deploy'), chalk.gray('- Deploy your app'));
  console.log(chalk.cyan('  clikdeploy status'), chalk.gray('- Check deployment status'));
}

function detectProject(): { type: string | null; config: Partial<ClikDeployConfig> } {
  const cwd = process.cwd();

  // Check for Dockerfile
  if (fs.existsSync(path.join(cwd, 'Dockerfile'))) {
    return { type: 'Docker', config: {} };
  }

  // Check package.json
  if (fs.existsSync(path.join(cwd, 'package.json'))) {
    const pkg = JSON.parse(fs.readFileSync(path.join(cwd, 'package.json'), 'utf8'));
    
    // Next.js
    if (pkg.dependencies?.next) {
      return { 
        type: 'Next.js', 
        config: { 
          buildCommand: 'npm run build',
          startCommand: 'npm start',
        },
      };
    }
    
    // React/Vite
    if (pkg.dependencies?.vite || pkg.devDependencies?.vite) {
      return {
        type: 'Vite',
        config: {
          buildCommand: 'npm run build',
        },
      };
    }

    // Express/Node
    if (pkg.dependencies?.express) {
      return {
        type: 'Express.js',
        config: {
          startCommand: pkg.scripts?.start ? 'npm start' : 'node index.js',
        },
      };
    }

    return { type: 'Node.js', config: {} };
  }

  // Python
  if (fs.existsSync(path.join(cwd, 'requirements.txt')) || 
      fs.existsSync(path.join(cwd, 'pyproject.toml'))) {
    return { type: 'Python', config: {} };
  }

  // Go
  if (fs.existsSync(path.join(cwd, 'go.mod'))) {
    return { type: 'Go', config: {} };
  }

  // Ruby/Rails
  if (fs.existsSync(path.join(cwd, 'Gemfile'))) {
    return { type: 'Ruby', config: {} };
  }

  return { type: null, config: {} };
}
