/**
 * Open an interactive terminal to an app's container via the same WebSocket
 * path the UI uses. Typing in the CLI is sent over the wire like the UI terminal.
 */

import Conf from 'conf';
import chalk from 'chalk';
import WebSocket from 'ws';
import { getApiClient, requireAuth } from '../utils/api';
import { ApiClient, getApiKeyForUrl } from '../api/client';
import { Formatters } from '../ui/formatters';
import { resolveApp, showDisambiguationHint } from '../utils/app-resolver';

const TERMINAL_WS_READY = '{"type":"terminal-ws-ready"}';

function slugForContainer(name: string): string {
  return (name ?? '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');
}

function getContainerName(app: { name: string; id: string; metadata?: { containerName?: string } }): string {
  const fromMetadata = app.metadata?.containerName?.trim();
  if (fromMetadata) return fromMetadata;
  return `${slugForContainer(app.name)}-${app.id.slice(0, 12)}`;
}

function buildTerminalWsUrl(
  apiUrl: string,
  serverId: string,
  appId: string,
  containerName: string
): string {
  const base = apiUrl.replace(/^http/, 'ws');
  const u = new URL('/api/terminal-ws', base);
  u.searchParams.set('serverId', serverId);
  u.searchParams.set('appId', appId);
  u.searchParams.set('containerName', containerName);
  return u.toString();
}

export async function openAppTerminal(config: Conf, appIdentifier: string, debug = false): Promise<void> {
  requireAuth(config);

  const apiUrl = ApiClient.getApiUrl(config);
  const apiKey = getApiKeyForUrl(config, apiUrl);
  const api = getApiClient(config);

  if (!apiKey) {
    Formatters.error('No API key found for current API URL');
    Formatters.gray('Run: clikdeploy --api-url https://clikdeploy.com login');
    process.exit(1);
  }

  const resolved = await resolveApp(api, appIdentifier);

  if (!resolved) {
    Formatters.error(`App "${appIdentifier}" not found`);
    const allApps = await api.getApps();
    showDisambiguationHint(appIdentifier, allApps);
    Formatters.gray('Use "clikdeploy apps list" to see your apps.');
    Formatters.gray('Example: clikdeploy apps terminal n8n');
    Formatters.gray('Example: clikdeploy apps terminal gcp-server n8n');
    process.exit(1);
  }

  const { app } = resolved;

  if (!app.serverId) {
    Formatters.error(`App "${app.name}" has no server. Deploy it first.`);
    process.exit(1);
  }

  const containerName = getContainerName(app);
  const url = buildTerminalWsUrl(apiUrl, app.serverId, app.id, containerName);

  const ws = new WebSocket(url, {
    headers: { Authorization: `Bearer ${apiKey}` },
  });

  let stdinRaw = false;

  const cleanup = () => {
    if (process.stdin.isTTY && stdinRaw) {
      process.stdin.setRawMode?.(false);
      process.stdin.pause();
    }
    try {
      if (ws.readyState === WebSocket.OPEN) ws.close();
    } catch {}
  };

  const exit = (code: number) => {
    cleanup();
    process.exit(code);
  };

  ws.on('open', () => {
    // Wait for TERMINAL_WS_READY; then enable stdin
  });

  let msgIndex = 0;
  ws.on('message', (data: Buffer | ArrayBuffer | Buffer[]) => {
    msgIndex++;
    const buf = Buffer.isBuffer(data) ? data : Buffer.from(data as ArrayBuffer);
    const str = buf.toString();
    const isReady = str === TERMINAL_WS_READY;
    if (debug) {
      const preview = isReady ? '<READY>' : JSON.stringify(str.length > 50 ? str.slice(0, 50) + '…' : str);
      process.stderr.write(`[debug] msg#${msgIndex} len=${buf.length} isReady=${isReady} data=${preview}\n`);
    }
    if (str === TERMINAL_WS_READY) {
      if (process.stdin.isTTY) {
        process.stdin.setRawMode?.(true);
        process.stdin.resume();
        stdinRaw = true;
        process.stdin.setEncoding('utf8');
        process.stdin.on('data', (chunk: string | Buffer) => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(Buffer.from(chunk as Buffer));
          }
        });
      }
      process.stderr.write(chalk.gray('Connected to app terminal. Type as in the UI. Exit with Ctrl+D or Ctrl+C.\n'));
      return;
    }
    process.stdout.write(buf);
  });

  ws.on('close', (code, reason) => {
    if (code !== 1000 && code !== 1005) {
      process.stderr.write(chalk.red(`\nTerminal closed (${code}) ${reason?.toString() || ''}\n`));
    }
    exit(0);
  });

  ws.on('error', (err) => {
    process.stderr.write(chalk.red(`\nTerminal error: ${err.message}\n`));
    Formatters.gray('Ensure the app server is CONNECTED and you use "pnpm dev" for the platform.');
    exit(1);
  });

  process.on('SIGINT', () => exit(0));
  process.on('SIGTERM', () => exit(0));
}
