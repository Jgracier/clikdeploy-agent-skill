import type { Command } from 'commander';
import type Conf from 'conf';
import {
  deleteAppCommand,
  restartApp,
  deployApp,
  updateDomain,
  toggleSSL,
  setEnvVar,
  listEnvVars,
  viewContainerLogs,
  execInApp,
} from '../commands/app';
import { transferAppCommand } from '../commands/app-transfer';
import { showApp, listApps } from '../commands/list';
import { openAppTerminal } from '../commands/terminal';
import { emitJson } from '../utils/structured-output';

export function registerAppsTool(program: Command, config: Conf): void {
  program
    .command('apps [subcommand] [args...]')
    .description(
      'Manage apps (list, show <app>, redeploy <app>, clone <app> <server>, move <app> <server>, delete <apps...>, restart <app>, logs <apps...>, exec <app> <command>, terminal <app>, domain <app> <domain>, ssl <app>, env <app> [key] [value])'
    )
    .option('--confirm', 'Require confirmation for destructive operations')
    .option('--all', 'Delete all apps (use with delete subcommand)')
    .option('--no-wait', "Do not wait for deployment to complete (for redeploy command)")
    .option('-n, --lines <n>', 'Number of log lines to show (for logs command)', '100')
    .option('-f, --follow', 'Follow log output (for logs command)')
    .option('--debug', 'Log each terminal WS message (for terminal command)')
    .action(async (...cmdArgs: any[]) => {
      const options = (cmdArgs[cmdArgs.length - 1] ?? {}) as any;
      const subcommand = cmdArgs[0] as string | undefined;
      const positionalArgs: string[] = cmdArgs
        .slice(1, -1)
        .flatMap((value) => (Array.isArray(value) ? value : [value]))
        .filter((value) => typeof value === 'string' && value.trim().length > 0)
        .map((value) => String(value));
      const joinedIdentifier = positionalArgs.join(' ').trim();

      if (subcommand === 'show' && joinedIdentifier) {
        await showApp(config, joinedIdentifier);
      } else if (subcommand === 'delete') {
        const deleteAll = options?.all === true;
        const appsToDelete = positionalArgs;
        await deleteAppCommand(config, appsToDelete, options?.confirm || false, deleteAll);
      } else if (subcommand === 'restart' && joinedIdentifier) {
        await restartApp(config, joinedIdentifier);
      } else if (subcommand === 'redeploy' && positionalArgs[0]) {
        const appsToRedeploy = positionalArgs;
        await deployApp(config, appsToRedeploy, { wait: options?.wait !== false });
      } else if (subcommand === 'clone' && positionalArgs[0] && positionalArgs[1]) {
        await transferAppCommand(config, positionalArgs[0], positionalArgs[1], 'clone');
      } else if (subcommand === 'move' && positionalArgs[0] && positionalArgs[1]) {
        await transferAppCommand(config, positionalArgs[0], positionalArgs[1], 'move');
      } else if (subcommand === 'logs') {
        const appsToView = positionalArgs;
        await viewContainerLogs(config, appsToView, {
          lines: parseInt(options?.lines || '100'),
          follow: options?.follow || false,
        });
      } else if (subcommand === 'domain' && positionalArgs[0]) {
        await updateDomain(config, positionalArgs[0], positionalArgs[1]);
      } else if (subcommand === 'ssl' && joinedIdentifier) {
        await toggleSSL(config, joinedIdentifier);
      } else if (subcommand === 'env' && positionalArgs[0]) {
        const appName = positionalArgs[0];
        const key = positionalArgs[1];
        if (key) {
          const value = positionalArgs.slice(2).join(' ');
          await setEnvVar(config, appName, key, value);
        } else {
          await listEnvVars(config, appName);
        }
      } else if (subcommand === 'exec' && positionalArgs[0] && positionalArgs[1]) {
        const appName = positionalArgs[0];
        const command = positionalArgs.slice(1).join(' ');
        await execInApp(config, appName, command);
      } else if (subcommand === 'terminal' && joinedIdentifier) {
        await openAppTerminal(config, joinedIdentifier, options?.debug === true);
      } else if (!subcommand || subcommand === 'list') {
        await listApps(config);
      } else {
        emitJson({
          status: 'clarification_required',
          command: 'clikdeploy apps',
          reason: 'invalid_or_missing_subcommand',
          message: 'Unknown apps subcommand or missing required arguments.',
          options: {
            available_subcommands: [
              'list',
              'show <app>',
              'redeploy <app>',
              'clone <app> <server>',
              'move <app> <server>',
              'delete <apps...>',
              'restart <app>',
              'logs <apps...>',
              'exec <app> <command>',
              'terminal <app>',
              'domain <app> <domain>',
              'ssl <app>',
              'env <app> [key] [value]',
            ],
          },
        });
      }
    });
}

