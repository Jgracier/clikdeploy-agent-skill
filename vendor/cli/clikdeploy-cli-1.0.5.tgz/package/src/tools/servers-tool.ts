import type { Command } from 'commander';
import type Conf from 'conf';
import { emitJson } from '../utils/structured-output';
import {
  listProviders,
  listMethods,
  connectOAuth,
  connectAPI,
  connectHome,
  wiringTest,
} from '../commands/server-connect';
import {
  inspectServer,
  execOnServer,
  cleanupServer,
  addServer,
  deleteServer,
  getServerKey,
  reconnectServer,
  discoverServer,
  runProvision,
  testServerLifecycle,
  testServerAppLifecycle,
} from '../commands/server';
import { showServersStatus, listServers } from '../commands/list';

export function registerServersTool(program: Command, config: Conf): void {
  program
    .command('servers [subcommand] [arg1] [arg2] [arg3] [arg4]')
    .description(
      'Manage servers (list, status, add, delete, inspect, exec, cleanup, key, reconnect, provision, providers, methods, connect, wiring-test [admin], ...)'
    )
    .option('--confirm', 'Require confirmation for destructive operations')
    .option('--save <path>', 'Save output to path (e.g. key --save /tmp/key)')
    .option('--key <path>', 'SSH key path for reconnect (non-GCP only); updates server credentials then tests')
    .option('--username <user>', 'SSH username when using --key (default: ubuntu, e.g. for Multipass)')
    .action(async (subcommand, arg1, arg2, arg3, arg4, options) => {
      if (subcommand === 'add' && arg1 && arg2) {
        addServer(config, arg1, arg2, arg3, options?.username);
      } else if (subcommand === 'delete' && arg1) {
        deleteServer(config, arg1, options?.confirm || false);
      } else if (subcommand === 'provision') {
        await runProvision(config, arg1, arg2, arg3, arg4);
      } else if (subcommand === 'inspect' && arg1) {
        inspectServer(config, arg1);
      } else if (subcommand === 'exec' && arg1 && arg2) {
        execOnServer(config, arg1, arg2);
      } else if (subcommand === 'cleanup' && arg1) {
        cleanupServer(config, arg1);
      } else if (subcommand === 'providers') {
        listProviders(config);
      } else if (subcommand === 'methods' && arg1) {
        listMethods(config, arg1);
      } else if (subcommand === 'connect' && arg1) {
        const method = arg1.toLowerCase();
        const provider = arg2;
        const serverIndexOrIp = arg3;
        const apiKey = arg4;

        if (method === 'self-host') {
          await connectHome(config, provider);
          return;
        }
        if (method === 'home' || method === 'selfhost') {
          emitJson({
            status: 'clarification_required',
            command: 'clikdeploy servers connect',
            reason: 'unsupported_connection_method',
            message: `Unsupported connection method: ${method}`,
            options: {
              standardized_method: 'self-host',
              usage: 'clikdeploy servers connect self-host [name]',
            },
          });
          return;
        }
        if (!arg2) {
          emitJson({
            status: 'clarification_required',
            command: 'clikdeploy servers connect',
            reason: 'provider_required',
            message: 'Provider is required for oauth/api connect methods.',
            options: {
              usage: [
                'clikdeploy servers connect oauth GCP',
                'clikdeploy servers connect api GCP <ip>',
                'clikdeploy servers connect self-host [name]',
              ],
            },
          });
          return;
        }
        if (method === 'oauth') {
          await connectOAuth(config, provider, serverIndexOrIp);
        } else if (method === 'api') {
          if (!serverIndexOrIp) {
            emitJson({
              status: 'clarification_required',
              command: 'clikdeploy servers connect',
              reason: 'ip_required_for_api_connect',
              message: 'IP address is required for API token connection.',
              options: {
                usage: 'clikdeploy servers connect api GCP <ip>',
                example: 'clikdeploy servers connect api GCP 34.174.203.154',
              },
            });
            return;
          }
          connectAPI(config, provider, serverIndexOrIp, apiKey);
        } else {
          emitJson({
            status: 'clarification_required',
            command: 'clikdeploy servers connect',
            reason: 'unknown_connection_method',
            message: `Unknown connection method: ${method}`,
            options: {
              available_methods: ['oauth', 'api', 'self-host'],
              usage: 'clikdeploy servers connect <oauth|api|self-host> [provider] [ip]',
            },
          });
        }
      } else if (subcommand === 'key' && arg1) {
        getServerKey(config, arg1, options?.save);
      } else if (subcommand === 'reconnect') {
        reconnectServer(config, arg1, options?.key, options?.username);
      } else if (subcommand === 'discover') {
        discoverServer(config, arg1);
      } else if (subcommand === 'lifecycle') {
        testServerLifecycle(config, arg1);
      } else if (subcommand === 'apps-lifecycle') {
        testServerAppLifecycle(config, arg1);
      } else if (subcommand === 'status') {
        showServersStatus(config);
      } else if (subcommand === 'wiring-test') {
        wiringTest(config);
      } else if (!subcommand || subcommand === 'list') {
        listServers(config);
      } else {
        emitJson({
          status: 'clarification_required',
          command: 'clikdeploy servers',
          reason: 'invalid_or_missing_subcommand',
          message: 'Unknown servers subcommand or missing required arguments.',
          options: {
            available_subcommands: [
              'list',
              'status',
              'wiring-test',
              'discover [server]',
              'lifecycle [server]',
              'apps-lifecycle [server]',
              'reconnect [server]',
              'add <name> <ip> [key]',
              'delete <server>',
              'provision',
              'inspect <server>',
              'exec <server> <command>',
              'cleanup <server>',
              'key <server> [--save path]',
              'providers',
              'methods <provider>',
              'connect <oauth|api|self-host> [provider] [ip] [apiKey]',
            ],
          },
        });
      }
    });
}

