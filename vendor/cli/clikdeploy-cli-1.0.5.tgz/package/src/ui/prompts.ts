import inquirer from 'inquirer';

/**
 * Reusable UI Prompts
 */
export class Prompts {
  static async selectAuthMethod(): Promise<'google' | 'github' | 'email' | 'apikey'> {
    const { method } = await inquirer.prompt([
      {
        type: 'list',
        name: 'method',
        message: 'How would you like to authenticate?',
        choices: [
          { name: '🌐 Google', value: 'google' },
          { name: '🐙 GitHub', value: 'github' },
          { name: '📧 Email/Password', value: 'email' },
          { name: '🔑 API Key', value: 'apikey' },
        ],
      },
    ]);
    return method;
  }

  static async askForEmailPassword(): Promise<{ email: string; password: string }> {
    return await inquirer.prompt([
      {
        type: 'input',
        name: 'email',
        message: 'Email:',
        validate: (input) => {
          if (!input.includes('@')) return 'Please enter a valid email';
          return true;
        },
      },
      {
        type: 'password',
        name: 'password',
        message: 'Password:',
        mask: '*',
        validate: (input) => input.length > 0 || 'Password is required',
      },
    ]);
  }

  static async askForSignup(): Promise<{ email: string; password: string; name: string }> {
    return await inquirer.prompt([
      {
        type: 'input',
        name: 'email',
        message: 'Email:',
        validate: (input) => {
          if (!input.includes('@')) return 'Please enter a valid email';
          return true;
        },
      },
      {
        type: 'password',
        name: 'password',
        message: 'Password:',
        mask: '*',
        validate: (input) => {
          if (input.length < 8) return 'Password must be at least 8 characters';
          return true;
        },
      },
      {
        type: 'input',
        name: 'name',
        message: 'Full Name (optional):',
      },
    ]);
  }

  static async askForApiKey(): Promise<string> {
    const { apiKey } = await inquirer.prompt([
      {
        type: 'password',
        name: 'apiKey',
        message: 'Enter your API key:',
        mask: '*',
        validate: (input) => input.length > 0 || 'API key is required',
      },
    ]);
    return apiKey;
  }

  static async selectServer(servers: any[]): Promise<string> {
    if (servers.length === 0) {
      throw new Error('No servers found');
    }
    
    if (servers.length === 1) {
      return servers[0].id;
    }

    const { serverId } = await inquirer.prompt([
      {
        type: 'list',
        name: 'serverId',
        message: 'Select a server:',
        choices: servers.map(s => ({
          name: `${s.name} (${s.ipAddress})`,
          value: s.id,
        })),
      },
    ]);
    return serverId;
  }

  static async confirm(message: string): Promise<boolean> {
    const { confirmed } = await inquirer.prompt([
      {
        type: 'confirm',
        name: 'confirmed',
        message,
        default: false,
      },
    ]);
    return confirmed;
  }

  static async askForInput(message: string, defaultValue?: string): Promise<string> {
    const { value } = await inquirer.prompt([
      {
        type: 'input',
        name: 'value',
        message,
        default: defaultValue,
        validate: (input) => input.length > 0 || 'Value is required',
      },
    ]);
    return value;
  }

  static async askForEmail(): Promise<string> {
    const { email } = await inquirer.prompt([
      {
        type: 'input',
        name: 'email',
        message: 'Enter your email:',
        validate: (input) => input.length > 0 || 'Email is required',
      },
    ]);
    return email;
  }

  static async askForPassword(): Promise<string> {
    const { password } = await inquirer.prompt([
      {
        type: 'password',
        name: 'password',
        message: 'Enter your password:',
        mask: '*',
        validate: (input) => input.length > 0 || 'Password is required',
      },
    ]);
    return password;
  }

  static async askForName(): Promise<string | undefined> {
    const { name } = await inquirer.prompt([
      {
        type: 'input',
        name: 'name',
        message: 'Enter your name (optional):',
      },
    ]);
    return name || undefined;
  }
}

