import chalk from 'chalk';

/**
 * Output Formatters
 */
export class Formatters {
  static header(text: string): void {
    console.log(chalk.bold(`\n${text}\n`));
  }

  static success(text: string): void {
    console.log(chalk.green(`✓ ${text}`));
  }

  static error(text: string): void {
    console.log(chalk.red(`✗ ${text}`));
  }

  static info(label: string, value: string): void {
    console.log(`   ${chalk.gray(label)} ${chalk.cyan(value)}`);
  }

  static warning(text: string): void {
    console.log(chalk.yellow(text));
  }

  static gray(text: string): void {
    console.log(chalk.gray(text));
  }

  static statusBadge(status: string | null | undefined): string {
    const value = String(status || '').trim();
    if (!value) return chalk.gray('unknown');
    switch (value.toLowerCase()) {
      case 'running':
        return chalk.green(value);
      case 'deploying':
        return chalk.yellow(value);
      case 'error':
      case 'failed':
        return chalk.red(value);
      default:
        return chalk.gray(value);
    }
  }
}
