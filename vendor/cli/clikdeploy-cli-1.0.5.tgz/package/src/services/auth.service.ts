import Conf from 'conf';
import { ApiClient } from '../api/client';
import { OAuthServer } from '../server/oauth-server';
import { CONFIG_KEYS, normalizeApiUrl } from '../constants';
import type { AuthByUrl } from '../constants';
import { clearCanonicalAuth, readCanonicalAuth, writeCanonicalAuth } from '../utils/local-auth';
import { delay } from '../utils/delay';

/**
 * Authentication Service
 * Pure business logic - no UI, no HTTP server details.
 * Auth is stored per API URL so localhost and clikdeploy.com can each have a session.
 */
export class AuthService {
  constructor(
    private config: Conf,
    private api: ApiClient
  ) { }

  private saveAuthForCurrentUrl(apiKey: string, user: unknown): void {
    const apiUrl = ApiClient.getApiUrl(this.config);
    const normalized = normalizeApiUrl(apiUrl);
    const authByUrl = (this.config.get(CONFIG_KEYS.AUTH_BY_URL) as AuthByUrl) || {};
    authByUrl[normalized] = { apiKey, user };
    this.config.set(CONFIG_KEYS.AUTH_BY_URL, authByUrl);
    this.config.set('apiKey', apiKey);
    this.config.set('user', user);
    writeCanonicalAuth({
      apiUrl: normalized,
      apiKey,
      updatedAt: new Date().toISOString(),
      user,
    });
  }

  private shouldRetryVerify(error: any): boolean {
    const status = Number(error?.response?.status || 0);
    if (status >= 500) return true;
    if (!status && (error?.code || error?.message)) return true;
    return false;
  }

  private async verifyTokenWithRetry(token: string): Promise<{ email: string }> {
    const maxAttempts = 8;
    let attempt = 0;
    for (;;) {
      attempt += 1;
      try {
        return await this.api.verifyToken(token);
      } catch (error: any) {
        if (!this.shouldRetryVerify(error) || attempt >= maxAttempts) {
          throw error;
        }
        await delay(Math.min(1500 * attempt, 6000));
      }
    }
  }

  async loginWithOAuth(provider: 'google' | 'github'): Promise<{ email: string }> {
    const server = new OAuthServer(this.api.baseUrl);
    const token = await server.authenticate(provider);

    const user = await this.verifyTokenWithRetry(token);

    this.saveAuthForCurrentUrl(token, user);

    return user;
  }

  async loginWithEmail(email: string, password: string): Promise<{ email: string }> {
    const { apiKey } = await this.api.loginWithEmail(email, password);

    const user = await this.api.verifyToken(apiKey);

    this.saveAuthForCurrentUrl(apiKey, user);

    return user;
  }

  async signup(email: string, password: string, name?: string): Promise<{ email: string }> {
    const { apiKey } = await this.api.signup(email, password, name);

    const user = await this.api.verifyToken(apiKey);

    this.saveAuthForCurrentUrl(apiKey, user);

    return user;
  }

  async loginWithApiKey(apiKey: string): Promise<{ email: string }> {
    const user = await this.api.verifyApiKey(apiKey);

    this.saveAuthForCurrentUrl(apiKey, user);

    return user;
  }

  /** Device flow step 1: returns the URL the user must open — no browser is launched. */
  async deviceFlowInit(provider: 'google' | 'github'): Promise<{ authUrl: string }> {
    return this.api.deviceFlowInit(provider);
  }

  /** Device flow step 2: exchange one-time code → save apiKey; returns the user record + optional server info. */
  async deviceFlowExchange(
    code: string
  ): Promise<{ email: string; authMethod: string; serverId?: string; agentId?: string; agentToken?: string }> {
    const { apiKey, auth_method, serverId, agentId, agentToken } = await this.api.deviceFlowExchange(code);
    const user = await this.api.verifyToken(apiKey);
    this.saveAuthForCurrentUrl(apiKey, user);
    return { email: user.email, authMethod: auth_method, serverId, agentId, agentToken };
  }

  logout(): { email?: string } {
    const canonical = readCanonicalAuth();
    const user = (canonical?.user as any) || (this.config.get('user') as any);
    const apiUrl = ApiClient.getApiUrl(this.config);
    const normalized = normalizeApiUrl(apiUrl);
    const authByUrl = (this.config.get(CONFIG_KEYS.AUTH_BY_URL) as AuthByUrl) || {};
    delete authByUrl[normalized];
    this.config.set(CONFIG_KEYS.AUTH_BY_URL, authByUrl);
    this.config.delete('apiKey');
    this.config.delete('user');
    clearCanonicalAuth();

    return user;
  }

  getCurrentUser(): any {
    const canonical = readCanonicalAuth();
    if (canonical?.user) return canonical.user;
    return this.config.get('user');
  }
}
