import { ApiClient } from '../api/client';

/**
 * Marketplace Service  
 * Pure business logic for marketplace operations
 */
export class MarketplaceService {
  constructor(private api: ApiClient) { }

  async deploy(appName: string, serverId: string): Promise<any> {
    return this.api.deployMarketplaceApp(appName, serverId);
  }

  async delete(appId: string): Promise<any> {
    return await this.api.deleteApp(appId);
  }

  async getStatus(appId: string): Promise<any> {
    return await this.api.getApp(appId);
  }

  async list(): Promise<any[]> {
    return await this.api.getMarketplaceApps();
  }
}
