/**
 * Deploy service: find-or-create app, wait for deployment, disk-full detection.
 * When waiting, streams full deployment logs from server (build, pull, health, etc.).
 */

import { ApiClient } from '../api/client';
import { delay } from '../utils/delay';
import {
  createDeployLogShapeState,
  shapeContainerLogChunk,
} from '../utils/deploy-log-shaper';

export interface WaitForDeploymentOptions {
  /** Callback each tick with elapsed seconds and status */
  onTick?: (elapsed: number, status: string) => void;
  /** If true, fetch and print deployment logs from server each tick (default true when deploymentId present) */
  streamLogs?: boolean;
  /** Called with each new log line when streamLogs is true; default prints to stdout */
  onLogLine?: (line: string) => void;
}

export interface DeployOptions {
  server?: string;
  branch?: string;
  message?: string;
  wait?: boolean;
}

export type WaitResult =
  | { success: true }
  | { success: false; error?: string; diskFull?: boolean };

function isDiskFullError(error?: string | null): boolean {
  if (!error || typeof error !== 'string') return false;
  const lower = error.toLowerCase();
  return (
    lower.includes('disk space') ||
    lower.includes('disk usage') ||
    lower.includes('no space left') ||
    lower.includes('enospc') ||
    lower.includes('disk full') ||
    lower.includes('insufficient disk') ||
    lower.includes('free up space')
  );
}

async function getGitRemote(): Promise<string | undefined> {
  try {
    const { execSync } = await import('child_process');
    const remote = execSync('git remote get-url origin', {
      encoding: 'utf8',
      stdio: ['pipe', 'pipe', 'ignore'],
    }).trim();
    return remote;
  } catch {
    return undefined;
  }
}

/** Find app by name or create one. Returns app and whether it was just created. */
export async function findOrCreateApp(
  api: ApiClient,
  projectConfig: { name: string; server?: string; branch?: string; autoDeploy?: boolean },
  options: DeployOptions
): Promise<{ app: { id: string; name: string }; created: boolean }> {
  const serverId = options.server || projectConfig.server;
  const apps = await api.getApps();
  const existing = apps.find((a: any) => a.name === projectConfig.name);
  if (existing) return { app: existing, created: false };

  const newApp = await api.createApp({
    name: projectConfig.name,
    serverId,
    githubUrl: await getGitRemote(),
    githubBranch: projectConfig.branch || 'main',
    autoDeploy: projectConfig.autoDeploy ?? true,
    port: 3000,
  });
  return { app: newApp, created: true };
}

function formatLogEntry(entry: { timestamp?: string | Date; level?: string; message?: string }): string {
  const ts = entry.timestamp
    ? new Date(entry.timestamp).toISOString().replace('T', ' ').slice(0, 19)
    : '';
  const level = (entry.level || 'info').toUpperCase().padEnd(5);
  const msg = entry.message ?? '';
  return ts ? `${ts} ${level} ${msg}` : `${level} ${msg}`;
}

/** Poll until deployment completes or times out; when streamLogs, prints full deployment logs from server. */
export async function waitForDeployment(
  api: ApiClient,
  appId: string,
  deploymentId: string,
  onTick?: (elapsed: number, status: string) => void,
  options?: WaitForDeploymentOptions
): Promise<WaitResult> {
  const startTime = Date.now();
  const timeout = 10 * 60 * 1000; // 10 minutes
  const streamLogs = options?.streamLogs !== false;
  const onLogLine = options?.onLogLine ?? ((line: string) => process.stdout.write(line + '\n'));
  let lastLogCount = 0;
  const deployLogShapeState = createDeployLogShapeState();

  while (Date.now() - startTime < timeout) {
    const deployments = await api.getAppDeployments(appId);
    const deployment = deployments.find((d: any) => d.id === deploymentId);
    if (!deployment) throw new Error('Deployment not found');

    const elapsed = Math.round((Date.now() - startTime) / 1000);

    if (streamLogs) {
      // 1) Deployment progress logs (our steps: build, pull, health, etc.)
      try {
        const { logs } = await api.getDeploymentLogs(deploymentId);
        if (Array.isArray(logs) && logs.length > lastLogCount) {
          for (let i = lastLogCount; i < logs.length; i++) {
            onLogLine(formatLogEntry(logs[i]));
          }
          lastLogCount = logs.length;
        }
      } catch {
        // Non-fatal
      }
      // 2) Container (Docker) logs from the server – actual process stdout/stderr
      try {
        const raw = await api.getAppContainerLogs(appId, 500);
        const shaped = shapeContainerLogChunk(raw, deployLogShapeState);
        if (shaped.lines.length > 0) {
          for (const line of shaped.lines) {
            onLogLine(line);
          }
        }
        deployLogShapeState.lastContainerLineCount = shaped.nextLineCount;
      } catch {
        // Non-fatal (container may not exist yet)
      }
    }

    switch (deployment.status) {
      case 'SUCCESS': {
        onTick?.(elapsed, 'SUCCESS');
        // Final dump: get any container logs that appeared at the end so you see everything that happened
        if (streamLogs) {
          try {
            const raw = await api.getAppContainerLogs(appId, 500);
            const shaped = shapeContainerLogChunk(raw, deployLogShapeState);
            for (const line of shaped.lines) {
              onLogLine(line);
            }
            deployLogShapeState.lastContainerLineCount = shaped.nextLineCount;
          } catch {
            // Non-fatal
          }
        }
        return { success: true };
      }
      case 'FAILED': {
        onTick?.(elapsed, 'FAILED');
        if (streamLogs) {
          try {
            const raw = await api.getAppContainerLogs(appId, 500);
            const shaped = shapeContainerLogChunk(raw, deployLogShapeState);
            for (const line of shaped.lines) {
              onLogLine(line);
            }
            deployLogShapeState.lastContainerLineCount = shaped.nextLineCount;
          } catch {
            // Non-fatal
          }
        }
        return {
          success: false,
          error: deployment.error,
          diskFull: isDiskFullError(deployment.error),
        };
      }
      case 'RUNNING':
      case 'QUEUED':
        onTick?.(elapsed, deployment.status);
        break;
    }

    await delay(2000);
  }

  return { success: false, error: 'Deployment timed out' };
}
