import Conf from 'conf';
import { ApiClient } from './src/api/client';
import { CONFIG_KEYS } from './src/constants';

(async () => {
  const cfg = new Conf({ projectName: 'clikdeploy' });
  cfg.set(CONFIG_KEYS.API_URL, 'https://clikdeploy.com');
  const api = new ApiClient(cfg as any, 60000);
  const apps = await api.getApps();
  const targets = apps.filter((a: any) => ['ERROR', 'DEPLOYING'].includes(String(a?.status || '')));
  console.log(`TARGETS=${targets.length}`);
  for (const a of targets) {
    console.log('---');
    console.log(`app=${a.name} id=${a.id} status=${a.status} server=${a.server?.name || ''}`);
    try {
      const details: any = await api.getApp(a.id);
      const dep = Array.isArray(details?.deployments) ? details.deployments[0] : null;
      if (dep) {
        console.log(
          `deployment=${dep.id} depStatus=${dep.status || ''} phase=${dep.phase || ''} result=${dep.result || ''} reason=${dep.failureReason || ''}`
        );
      }
    } catch (e: any) {
      console.log(`detail_err=${e?.message || String(e)}`);
    }

    try {
      const logs = await api.getAppContainerLogs(a.id, 120);
      const tail = String(logs || '')
        .split('\n')
        .slice(-25)
        .join('\n');
      console.log('log_tail_start');
      console.log(tail);
      console.log('log_tail_end');
    } catch (e: any) {
      console.log(`log_err=${e?.message || String(e)}`);
    }
  }
})();
