/**
 * Connect to app terminal WebSocket and log every message to stderr (sequence, length, content repr).
 * Shell output goes to stdout. Run: npx tsx scripts/terminal-debug.ts claude-code
 * Requires: server running (pnpm dev), CLI logged in (clikdeploy login).
 */
import Conf from 'conf';
import WebSocket from 'ws';
import { ApiClient } from '../src/api/client';
import { getApiClient } from '../src/utils/api';
import { resolveApp } from '../src/utils/app-resolver';

const TERMINAL_WS_READY = '{"type":"terminal-ws-ready"}';

function slugForContainer(name: string): string {
  return (name ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

function getContainerName(app: { name: string; id: string; metadata?: { containerName?: string } }): string {
  if (app.metadata?.containerName) return app.metadata.containerName;
  return `${slugForContainer(app.name)}-${app.id.slice(0, 12)}`;
}

function repr(s: string): string {
  return JSON.stringify(s.replace(/\r/g, '\\r').replace(/\n/g, '\\n'));
}

async function main() {
  const appId = process.argv[2] || 'claude-code';
  const config = new Conf({ projectName: 'clikdeploy-cli' });
  const apiUrl = ApiClient.getApiUrl(config) as string;
  const apiKey = config.get('apiKey') as string;
  if (!apiKey) {
    console.error('Not logged in. Run: clikdeploy login');
    process.exit(1);
  }
  const api = getApiClient(config);
  const resolved = await resolveApp(api, appId);
  if (!resolved) {
    console.error(`App "${appId}" not found`);
    process.exit(1);
  }
  const { app } = resolved;
  if (!app.serverId) {
    console.error('App has no server');
    process.exit(1);
  }
  const containerName = getContainerName(app);
  const base = apiUrl.replace(/^http/, 'ws');
  const url = `${base}/api/terminal-ws?serverId=${app.serverId}&appId=${encodeURIComponent(app.id)}&containerName=${encodeURIComponent(containerName)}`;
  console.error(`[debug] Connecting to ${url}`);
  const ws = new WebSocket(url, { headers: { Authorization: `Bearer ${apiKey}` } });
  let msgIndex = 0;
  ws.on('open', () => console.error('[debug] WebSocket open'));
  ws.on('message', (data: Buffer | ArrayBuffer | Buffer[]) => {
    msgIndex++;
    const buf = Buffer.isBuffer(data) ? data : Buffer.from(data as ArrayBuffer);
    const str = buf.toString();
    const isReady = str === TERMINAL_WS_READY;
    const preview = isReady ? '<READY>' : repr(str.length > 60 ? str.slice(0, 60) + '...' : str);
    console.error(`[debug] msg#${msgIndex} len=${buf.length} isReady=${isReady} data=${preview}`);
    if (isReady) {
      console.error('[debug] READY received - shell output follows on stdout');
      return;
    }
    process.stdout.write(buf);
  });
  ws.on('close', (code, reason) => console.error('[debug] close', code, reason?.toString()));
  ws.on('error', (err) => console.error('[debug] error', err.message));
  setTimeout(() => {
    console.error('[debug] timeout - closing');
    ws.close();
    process.exit(0);
  }, 8000);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
