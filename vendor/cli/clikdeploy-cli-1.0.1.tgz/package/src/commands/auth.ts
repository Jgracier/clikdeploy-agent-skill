import ora from 'ora';
import path from 'path';
import Conf from 'conf';
import { ApiClient } from '../api/client';
import { AuthService } from '../services/auth.service';
import { Prompts } from '../ui/prompts';
import { Formatters } from '../ui/formatters';

/**
 * Auth Commands
 * Thin command handlers - delegate to services
 */

/** Emit structured JSON for machine consumers (--return-url / --exchange flows). */
function emitJson(obj: unknown): void {
  process.stdout.write(JSON.stringify(obj) + '\n');
}

export async function login(
  config: Conf,
  options?: {
    google?: boolean;
    github?: boolean;
    returnUrl?: boolean;
    exchange?: string;
  }
) {
  const api = new ApiClient(config);
  const authService = new AuthService(config, api);

  // --return-url: device flow init — print authUrl as JSON and exit (no browser)
  if (options?.returnUrl) {
    const provider: 'google' | 'github' = options.github ? 'github' : 'google';
    await loginReturnUrl(authService, provider);
    return;
  }

  // --exchange <CODE>: device flow exchange
  if (options?.exchange) {
    await loginExchange(config, api, authService, options.exchange);
    return;
  }

  // --- Standard interactive flow ---
  Formatters.header('🔐 Login to ClikDeploy');

  let method: 'google' | 'github' | 'email' | 'apikey';
  if (options?.google) {
    method = 'google';
  } else if (options?.github) {
    method = 'github';
  } else {
    method = await Prompts.selectAuthMethod();
  }

  try {
    if (method === 'apikey') {
      await loginWithApiKey(authService, config);
    } else if (method === 'email') {
      await loginWithEmail(authService);
    } else {
      await loginWithOAuth(authService, method);
    }
  } catch (error: any) {
    Formatters.error('Authentication failed');
    Formatters.gray(error.message);
    if (error.response?.status === 401 && (method === 'google' || method === 'github')) {
      Formatters.gray('Tip: Ensure api-url points to the same platform you logged into (clikdeploy config api-url <url>).');
    }
    process.exit(1);
  }
}

export async function loginUrl(
  config: Conf,
  options?: {
    google?: boolean;
    github?: boolean;
  }
): Promise<void> {
  const api = new ApiClient(config);
  const authService = new AuthService(config, api);
  const provider: 'google' | 'github' = options?.github ? 'github' : 'google';
  await loginReturnUrl(authService, provider);
}

async function loginWithOAuth(authService: AuthService, provider: 'google' | 'github') {
  Formatters.gray('\n🌐 Opening browser for authentication...\n');
  const spinner = ora('Waiting for authentication...').start();

  try {
    const user = await authService.loginWithOAuth(provider);
    spinner.succeed(`Logged in as ${user.email}`);
    Formatters.gray('\n✅ Authentication saved securely.\n');
    process.exit(0);
  } catch (error: any) {
    spinner.fail('Authentication failed');
    throw error;
  }
}

async function loginWithEmail(authService: AuthService) {
  const { email, password } = await Prompts.askForEmailPassword();
  const spinner = ora('Authenticating...').start();

  try {
    const user = await authService.loginWithEmail(email, password);
    spinner.succeed(`Logged in as ${user.email}`);
    Formatters.gray('\n✅ Authentication saved securely.\n');
    process.exit(0);
  } catch (error: any) {
    spinner.fail('Authentication failed');
    throw error;
  }
}

async function loginWithApiKey(authService: AuthService, config: Conf) {
  const apiKey = await Prompts.askForApiKey();
  const spinner = ora('Verifying API key...').start();

  try {
    const user = await authService.loginWithApiKey(apiKey);
    spinner.succeed(`Logged in as ${user.email}`);
    Formatters.gray('\nYour API key has been saved securely.\n');
  } catch (error: any) {
    spinner.fail('Invalid API key');
    const apiUrl = ApiClient.getApiUrl(config);
    Formatters.gray(`\nGet your API key at: ${apiUrl}/settings/api`);
    throw error;
  }
}

export function logout(config: Conf) {
  const authService = new AuthService(config, new ApiClient(config));
  const user = authService.logout();

  if (user?.email) {
    Formatters.success(`Logged out from ${user.email}`);
  } else {
    Formatters.warning('Not logged in');
  }
}

export async function signup(config: Conf) {
  Formatters.header('📝 Create Account');

  const { email, password, name } = await Prompts.askForSignup();
  const api = new ApiClient(config);
  const authService = new AuthService(config, api);
  const spinner = ora('Creating account...').start();

  try {
    const user = await authService.signup(email, password, name || undefined);
    spinner.succeed(`Account created for ${user.email}`);
    Formatters.gray('\n✅ You are now logged in!\n');
    process.exit(0);
  } catch (error: any) {
    spinner.fail('Signup failed');
    Formatters.error(error.message);
    process.exit(1);
  }
}

export function whoami(config: Conf, options?: { json?: boolean }) {
  const authService = new AuthService(config, new ApiClient(config));
  const user = authService.getCurrentUser();

  if (options?.json) {
    if (!user) {
      emitJson({ status: 'auth_required', is_authenticated: false });
    } else {
      emitJson({
        status: 'auth_valid',
        is_authenticated: true,
        email: user.email,
        name: user.name || null,
        tier: user.tier || 'FREE',
      });
    }
    return;
  }

  if (!user) {
    Formatters.warning('Not logged in');
    Formatters.gray('Run clikdeploy login to authenticate');
    return;
  }

  Formatters.header('👤 Current User');
  Formatters.info('Email:', user.email);
  Formatters.info('Name: ', user.name || 'Not set');
  Formatters.info('Tier: ', user.tier || 'FREE');
}


// ============================================================
// Device flow (non-browser / agent / skill mode)
// ============================================================

/**
 * --return-url
 * Step 1 of device flow: get the one-time auth URL and print it as JSON.
 * Callers (agent, skill) display the URL to the user; no browser is opened.
 * Output: { status: 'auth_required', provider, authUrl }
 */
export async function loginReturnUrl(
  authService: AuthService,
  provider: 'google' | 'github'
): Promise<void> {
  try {
    const { authUrl, flowId } = await authService.deviceFlowInit(provider);
    emitJson({
      status: 'auth_required',
      provider,
      is_authenticated: false,
      authUrl,
      flowId,
    });
  } catch (error: any) {
    emitJson({
      status: 'auth_failed',
      error: error.response?.data?.error || error.message || 'Failed to initialize auth flow',
    });
    process.exitCode = 1;
  }
}

/**
 * --exchange <CODE>
 * Step 2 of device flow: trade the one-time code for a saved API key.
 * Output: { status: 'auth_valid', email, authMethod }
 */
export async function loginExchange(
  config: Conf,
  api: ApiClient,
  authService: AuthService,
  code: string
): Promise<void> {
  const normalizedCode = String(code || '').trim().toUpperCase();
  if (!/^[A-F0-9]{10}$/.test(normalizedCode)) {
    emitJson({ status: 'auth_failed', error: 'Invalid code format — must be 10 hex characters' });
    process.exitCode = 1;
    return;
  }

  try {
    // Exchange code via Gate. Gate defaults autoConnect to true.
    const { email, authMethod, serverId, agentId, agentToken } = await authService.deviceFlowExchange(
      normalizedCode
    );

    // If the Gate provisioned a server (default behavior), run the local installer
    if (serverId && agentToken) {
      const { runAgentInstaller } = await import('./server-connect');
      const baseUrl = api.baseUrl.replace(/\/$/, '');

      await runAgentInstaller(config, {
        token: agentToken,
        serverId,
        agentId: agentId || serverId,
        shouldUpdateAgentCode: true,
        baseUrl,
      });

      emitJson({
        status: 'auth_valid',
        is_authenticated: true,
        email,
        authMethod,
        server_id: serverId,
        server_status: 'server_connecting',
        server_connected: false,
      });
    } else {
      // Identity-only success (Gate had autoConnect disabled or failed provision)
      emitJson({ status: 'auth_valid', is_authenticated: true, email, authMethod });
    }
  } catch (error: any) {
    emitJson({
      status: 'auth_failed',
      error: error.response?.data?.error || error.message || 'Code exchange failed',
    });
    process.exitCode = 1;
  }
}
